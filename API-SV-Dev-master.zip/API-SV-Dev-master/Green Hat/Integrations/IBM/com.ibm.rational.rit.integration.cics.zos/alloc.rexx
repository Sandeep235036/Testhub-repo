/* rexx */
/* Usage:                                                                          */
/*       alloc.rexx HLQ CLEAN                                                      */
/*  HLQ  high qualifier of dataset. default is #USERID#.RIT.CICS.#VERSION#         */   
/*                                  where #USERID# is current user id              */
/*                                  and #VERSION# is the version number.           */
/*  CLEAN delete dataset first before create new ones. only take effective         */
/*                                  when TRUE is specified                         */
/*  e.g.    alloc.rexx --use default hlq and clean is not performed.               */
/*          alloc.rexx SXFAN.RIT.CICS.V8710 --use SXFAN.RIT.CICS.V8710 as hlq      */
/*          alloc.rexx sxfan.rit.cics.v870 true -- perform clean before creating ds*/



/* define constants */
const.MLQ.CICS="RIT.CICS"
const.MLQ.VERSION="V9000"
/* handle input parameters */
parse upper arg hlq override
if hlq == '' then
do
  say 'hlq is not specified,use default instead'
  hlq = USERID()||"."||const.MLQ.CICS||"."||const.MLQ.VERSION
end
if override == "TRUE" then
do
  say 'override is specified, will delete the original dataset'
end
say 'HLQ is' hlq

rc=alloc(hlq||".ADATA","ADATA",override);
rc=alloc(hlq||".ASM","ASM",override);
rc=alloc(hlq||".ASM.LIST","LIST",override);
rc=alloc(hlq||".CPP","CPP",override);
rc=alloc(hlq||".C80","C",override);
rc=alloc(hlq||".EQALANGX","EQALANGX",override);
rc=alloc(hlq||".H","HEADER",override);
rc=alloc(hlq||".JCL","JCL",override);
rc=alloc(hlq||".C80.LIST","LIST",override);
rc=alloc(hlq||".LOAD","LOAD",override);
rc=alloc(hlq||".LOADLIB","LOADLIB",override);
rc=alloc(hlq||".OBJ","OBJ",override);
rc=alloc(hlq||".PROC","JCL",override);
rc=alloc(hlq||".MAC","MAC",override);
rc=alloc(hlq||".SLDLOGIC","SLDLOGIC",override);
rc=alloc(hlq||".SYSDEBUG","SYSDEBUG",override);
rc=alloc(hlq||".SYSDEFSD","SYSDEFSD",override);
exit 0


alloc: PROCEDURE
PARSE UPPER ARG dsn,type,override
rec = 0
say "Check if" dsn "exists"
address tso "listds '"dsn"'"
say rc
if rc == 0 then
do
   if override == "TRUE" then
   do
      say "override is specified and dataset will be deleted"
      address tso "delete '"dsn"' SCRATCH "
   end
   else
   do
      say "dataset is already defined."
      return 4
   end
end


say "Allocate "dsn
select
 when type == "" then
   do
     say "type cannot be null"
     return 8;
   end
 when type == "ADATA"    then return allocdsn(dsn,"v,b",8188,8192,20,20,0,"LIBRARY","PO")
 when type == "ASM"      then return allocdsn(dsn,"f,b",80,3120,10,10,0,"LIBRARY","PO")
 when type == "CPP"      then return allocdsn(dsn,"v,b",256,5120,10,10,0,"LIBRARY","PO")
 when type == "C"        then return allocdsn(dsn,"f,b",80,3120,10,10,0,"LIBRARY","PO")
 when type == "EQALANGX" then return allocdsn(dsn,"v,b",1562,32760,30,50,0,"LIBRARY","PO")
 when type == "HEADER"   then return allocdsn(dsn,"v,b",256,2560,1,1,0,"LIBRARY","PO")
 when type == "JCL"      then return allocdsn(dsn,"f,b",80,3120,10,10,0,"LIBRARY","PO")
 when type == "LIST"     then return allocdsn(dsn,"v,b,a",137,32760,30,10,0,"LIBRARY","PO")
 when type == "LOAD"     then return allocdsn(dsn,"u",0,32760,1,1,2,"PDS","PO")
 when type == "LOADLIB"  then return allocdsn(dsn,"u",0,32760,20,20,0,"LIBRARY","PO")
 when type == "OBJ"      then return allocdsn(dsn,"f,b",80,3200,30,50,0,"LIBRARY","PO")
 when type == "SLDLOGIC" then return allocdsn(dsn,"v,b",8188,8192,2,2,0,"LIBRARY","PO")
 when type == "SYSDEBUG" then return allocdsn(dsn,"f,b",80,3200,2,2,0,"LIBRARY","PO")
 when type == "SYSDEFSD" then return allocdsn(dsn,"f,b",80,3200,2,2,0,"LIBRARY","PO")
 when type == "MAC"      then return allocdsn(dsn,"f,b",80,3200,2,2,0,"LIBRARY","PO")
 otherwise
   do
     say type "is not a known type"
     return 8
   end
end
return rec

allocdsn: PROCEDURE
parse upper arg dsn,recfm,lrecl,blksize,fext,sext,dir,dsntype,dsorg
rec=0

rec=bpxwdyn("alloc da('"dsn"') new recfm("recfm")  lrecl("lrecl") blksize("blksize") space("fext","sext") dir("dir") dsntype("dsntype") dsorg("dsorg") CATALOG CYL")
if rec <> 0 then
do
  say dsn" allocation error,dataset not allocated"
end
rec=bpxwdyn("free dsn('"dsn"')")
return rec
