/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*********************************************************************
 * ritutil.h
 *********************************************************************/
#ifndef _RITUTIL_H
#define _RITUTIL_H

#ifndef RESOLVE_VIA_LOOKUP
#define RESOLVE_VIA_LOOKUP
#endif

#ifndef _OPEN_SYS_SOCK_IPV6
#define _OPEN_SYS_SOCK_IPV6
#endif

#ifndef  RIT_MAX_FILTER_NUM
#define  RIT_PROGRAM_FILTER_LEN    9
#define  RIT_DPL_FILTER_LEN        13
#define  RIT_TRANSACTION_ID_LEN    4
#define  RIT_MAX_FILTER_NUM        39
#define  RIT_MAX_FILTER_LEN        (13 * 39)
#endif /* RIT_PROGRAM_FILTER_LEN */

#ifndef UUID_LENGTH
#define UUID_LENGTH 36
#endif

#ifndef RIT_COMMAND_MAX_SIZE
#define RIT_COMMAND_MAX_SIZE  32
#define RIT_MAX_BIND_ADDR_LEN 48
#define RIT_MAX_WTO_MSG_LEN   256
#endif /* RIT_COMMAND_MAX_SIZE */


#ifndef STRCUT_WTO_
#define STRCUT_WTO_
struct WTO{
    short lWTO;
    char buffer[RIT_MAX_WTO_MSG_LEN];
};
typedef struct WTO Wto;
/* ecb is format wp...code */
/* to see if posted check 4.... */
/* to extract the post code ignore 2 bits */
const int POSTED   = 0x40000000;
const int POSTCODE = 0x3FFFFFFF;


/* This struct need to keep consistent with USERPARM in SETUPMOD */
/*      and USERPARM in CHECKMOD                                 */
struct USERPARM {
    int COMADDR;
    int IOERRECB;
    int CANCLECB;
    int * AMODECB;
    int * AIOERECB;
    int * ACANCECB;
    int FLAG;
    char COMMAND[RIT_COMMAND_MAX_SIZE];
};
typedef struct USERPARM UserParm;

#endif /* STRCUT_WTO_ */


typedef struct ExciCommarea{
    int ruleNum;
    char filters[RIT_MAX_FILTER_LEN];
} EXCICOMMAREA;

typedef struct CommStatus{
    int status;
} COMMSTATUS;

#define RIT_DISABLE_CMD 0
#define RIT_ENABLE_CMD  1
#define RIT_TESTCONN_CMD  2

typedef struct RitmComm{
    char bindaddr[RIT_MAX_BIND_ADDR_LEN];
    int  port;
    int  command;
    int  status;
    char sysid[4];
    char jobname[8];
} RITMCOMM;

#ifndef _RITDLL_
#ifdef __cplusplus
/* Note: extern "C" must be used here to allow the binder set the correct
 * linkage for the below functions which imported from DLL RITUTILM.
 */
extern "C" {
    extern int execcall(EXCICOMMAREA* pcomm, const char* applid);
    extern int enabcrit(RITMCOMM* pcomm, const char* applid);
    extern int heartbtc(COMMSTATUS* pcomm, const char* system);
}
extern "OS_DOWNSTACK" {
    int checkmod(UserParm* userparm, int* flag, char* buffer);
    int setupmod(UserParm* userparm);
    int ritwait(int* ECBLIST);
    int ritpost(int* ECBLIST);
    int wtovlen(const Wto& wto);
}
#else /* __cplusplus */
    extern int  heartbtc(COMMSTATUS* pcomm, const char* system);
    extern int  execcall(EXCICOMMAREA* pcomm, const char* applid);
    extern int  enabcrit(RITMCOMM* pcomm, const char* applid);
    #pragma linkage(checkmod, OS_DOWNSTACK)
    #pragma linkage(setupmod, OS_DOWNSTACK)
    #pragma linkage(ritwait, OS_DOWNSTACK)
    #pragma linkage(ritpost, OS_DOWNSTACK)
    #pragma linkage(wtovlen, OS_DOWNSTACK)
    int checkmod(UserParm* userparm, int* flag, char* buffer);
    int setupmod(UserParm* userparm);
    int ritwait(int* ECBLIST);
    int ritpost(int* ECBLIST);
    int wtovlen(const Wto& wto);

#endif /* __cplusplus */
#else
    #pragma export(execcall)
    #pragma export(heartbtc)
    #pragma export(enabcrit)
#endif /* _RITDLL_ */
#endif /* RITUTIL_H_ */
