#ifndef RTCPSET_H_
#define RTCPSET_H_
#include <string>
//CHANGE
// Global flag (shared across all files)
extern int transno;
extern bool rtcp_server;
// Function to update flag based on URL
void updateRtcpFlag(const std::string& url);
#endif
