/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/**********************************************************************
 * socksvr.h
 * ********************************************************************/
#ifndef SOCKSVR_H_
#define SOCKSVR_H_

#ifndef _OPEN_MSGQ_EXT
#define _OPEN_MSGQ_EXT    1
#endif

#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>
#include <netdb.h>
#include <signal.h>
#include <pthread.h>
#include "sockthmg.h"
#include "protocl.h"
#define LISTENQ                   1024

#define INT_BeforeLink      4
#define INT_AfterLink       8
#define INT_OK              4
#define INT_Bypass          8

#define RIT_SOCK_MAX        25


extern "C" void * invokeHdr(int connfd);
extern "C" void * socksvr(void* arg);

class Logger;
class CICSRegistration;
class SockServer {
private:
    SockServer( const SockServer &);
    void operator=(const SockServer&);
    static SockServer* s_instance;
    SockServer(CICSRegistration* reg);

private:
    Logger*        log_;
    CICSRegistration* pReg_;
    pthread_attr_t thrattr_;
    pthread_t thread_;
    int stop_;
    pthread_rwlockattr_t rwlattr_;
    pthread_rwlock_t statuslock_;
    //SockThreadManager taskManager;

public:
    static SockServer* instance(CICSRegistration* reg);
    ~SockServer();

    void start();
    void stop(int status);

    int getStop();

    pthread_attr_t* getAttr(){return &thrattr_;}
    CICSRegistration* registration() {return pReg_;}

    //SockThreadManager& getTaskManager();

};

#endif
