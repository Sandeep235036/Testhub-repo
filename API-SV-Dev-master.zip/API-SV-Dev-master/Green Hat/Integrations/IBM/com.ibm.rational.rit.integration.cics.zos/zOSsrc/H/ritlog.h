/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*
 * ritlog.h
 */
#ifndef RITLOG_H_
#define RITLOG_H_

#include "ritcomm.h"
#include <string>
#include <list>
#include <map>

#define  RIT_LogEvent_Level_DEBUG   "DEBUG"  //$NON-NLS-1$
#define  RIT_LogEvent_Level_INFO    "INFO"   //$NON-NLS-1$
#define  RIT_LogEvent_Level_WARN    "WARN"  //$NON-NLS-1$
#define  RIT_LogEvent_Level_ERROR   "ERROR"  //$NON-NLS-1$
// 60 seconds for minimum time slot
#define RITLOG_CHECK_INTERVAL  (60)
// 50,000 lines to exchange log file when starting RIT
#define RITLOG_CHECK_POSITION  (500 * 1000)
#define RITLOG_TEST_POSITION   18000
// The maximum length for Logger name
#define RITLOG_LOGGERNAME_MAX_LEN 32
#define RITLOG_TIME_LEN 24



#define RITLOG_FILE_NAME1 "DD:RITLOG01"  //$NON-NLS-1$
#define RITLOG_FILE_NAME2 "DD:RITLOG02"  //$NON-NLS-1$

using namespace std;

struct LOGEVENT {
    ::greenhat::vie::comms::proxy::LogEvent_Level level_;
    string message_;
    string name_;
    map<string, string> context_;
    long timestamp_;
    long timeOffset_;
    int sequence_;
    string sourceId_;
    string trace_;

    LOGEVENT(const string& name,
            ::greenhat::vie::comms::proxy::LogEvent_Level level,
            const string& logMessage,
            const map<string, string> & context,
            long timestamp);
};

class LogAppender {
protected:
    LogAppender(){};

public:
    virtual ~LogAppender(){};
    virtual int log(const LOGEVENT & event) = 0;
    virtual int flush()=0;
    virtual void getNextAvailableFile() {};
};

class ThreadScopeMutexGuard{
private:
    pthread_mutex_t* mutex_ptr_;
public:
    ThreadScopeMutexGuard(pthread_mutex_t* ptr);
    ~ThreadScopeMutexGuard();
};

class FileLogAppender: public LogAppender {
private:

    void closeCurrentFile();
    int logWrite(string);

    vector<string> fileNameList_;
    int currentFileIndex_;
    FILE* currentLogFile_;

    int clearFlag_;
    int errorFlag_;
    pthread_mutexattr_t mutexattr_;
    pthread_mutex_t mutex_;

public:
    FileLogAppender(const vector<string> fileNames, int clearFlag=0);
    virtual ~FileLogAppender();
    int flush();
    int log(const LOGEVENT & event);
    void getNextAvailableFile();
};

class LogRouter {
private:

    ::greenhat::vie::comms::proxy::LogEvent_Level maxLevel_;
    list<LogAppender*>& appenders_;
public:
    LogRouter(list<LogAppender*> & appenders,
        ::greenhat::vie::comms::proxy::LogEvent_Level level
         =::greenhat::vie::comms::proxy::LogEvent_Level_INFO);
    ~LogRouter();
    void setMaxLogLevel(::greenhat::vie::comms::proxy::LogEvent_Level level);
    int logEvent(const LOGEVENT & event);


    /**
     * Tests whether the router will accept events at the
     * given log level
     *
     * @param level
     * @return boolean
     */
    bool accepts(::greenhat::vie::comms::proxy::LogEvent_Level level);
};

class Logger {
private:
    Logger(const Logger&);
    void operator=(const Logger&);

    string name_;
    LogRouter* router_;
    map<string, string> context_;
    int fireEvent(const LOGEVENT & logEvent);

public:
    Logger(const string& name, LogRouter* router);
    Logger(const char* loggerName, LogRouter* router);

    int log(::greenhat::vie::comms::proxy::LogEvent_Level level,
            const string & message);

    int log(::greenhat::vie::comms::proxy::LogEvent_Level level,
            const string & message, const map<string, string> & context);

    int log(::greenhat::vie::comms::proxy::LogEvent_Level level,
            const char* message, ...);

    int log(::greenhat::vie::comms::proxy::LogEvent_Level level,
            const map<string, string> & context,
            const char* message, ...);

    int debug(const string & message){
            return log(
            ::greenhat::vie::comms::proxy::LogEvent_Level_DEBUG, message);
    }

    int debug(const string & message,
            const map<string, string> & context){
        return log(
        ::greenhat::vie::comms::proxy::LogEvent_Level_DEBUG, message,
        context);
    }

    int debug(const char* message, ...);

    int debug(const map<string, string> & context,
            const char* message, ...);

    int info(const string & message){
        return log(::greenhat::vie::comms::proxy::LogEvent_Level_INFO,
        message);
    }

    int info(const string & message,
            const map<string, string> & context){
        return log(::greenhat::vie::comms::proxy::LogEvent_Level_INFO,
        message, context);
    }

    int info(const char* message, ...);

    int info(const map<string, string> & context,
            const char* message, ...);

    int warn(const string & message){
        return log(
        ::greenhat::vie::comms::proxy::LogEvent_Level_WARN, message);
    }

    int warn(const string & message,
            const map<string, string> & context){
        return log(
        ::greenhat::vie::comms::proxy::LogEvent_Level_WARN, message,
        context);
    }

    int warn(const char * message, ...);

    int warn(const map<string, string> & context,
            const char * message, ...);

    int error(const string & message){
        return log(
        ::greenhat::vie::comms::proxy::LogEvent_Level_ERROR, message);
    }

    int error(const string & message,
            const map<string, string> & context){
        return log(::greenhat::vie::comms::proxy::LogEvent_Level_ERROR,
        message, context);
    }

    int error(const char* message, ...);

    int error(const map<string, string> & context,
            const char* message, ...);

    bool isTraceEnabled();

    bool isDebugEnabled();

    bool isInfoEnabled();

    bool isWarningEnabled();

    bool isErrorEnabled();

    /*
     * Methods for adding contextual data
     */
    /**
     * Adds key-value pair to the logger's contextual data.
     *
     * @param key
     * @param value
     */
    void putContextData(const string & key, const string & value);

    int getContextData(const string & key, string & value);

    /**
     * Deletes the key and value from the contextual data
     */
    int deleteContextData(const string & key);

    /**
     * Clears all contextual data for this logger instance.
     */
    void clearContextData();

    /**
     * Returns COPY of all contextual data for this logger instance.
     *
     * @return map<string,string> object, empty if no contextual data.
     */
    const map<string, string> & getContext();
};

class LoggerFactory {

    void operator=(const LoggerFactory&);

    map<string, Logger*> loggers_;
    LogRouter* logrouter_;
    list<LogAppender*> appenders_;

    static LoggerFactory* s_instance_;

    LoggerFactory();
    void init();
public:
    static LoggerFactory* getInstance();
    static void destroy();
    ~LoggerFactory();

    void setLogLevel(::greenhat::vie::comms::proxy::LogEvent_Level loglevel);
    Logger* getLogger(const char* name);
    void flush();
    void firstAppenderGetNextAvailableFile();

};


#endif /* RITLOG_H_ */
