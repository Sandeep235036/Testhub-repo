/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/**********************************************************************
 * record.h
 **********************************************************************/
#ifndef RECORD_H_
#define RECORD_H_

#include <string>
#include <map>
#include <vector>

#include "ritcomm.h"
#include "socksvr.h"
#include "proxy.h"

using namespace ::std;
using namespace ::google::protobuf;
using namespace ::greenhat::vie::comms::proxy;

class Logger;
class ServerLogger;
class CICSAgentCondition;
class Recorder {
private:
    Recorder( const Recorder&);
    void operator=(const Recorder&);
    Recorder(CICSRegistration* reg);
    static Recorder* s_instance;
    pthread_rwlockattr_t rwlattr_;
    pthread_rwlock_t rwlock_;
    Logger* log_;
    ServerLogger* serverLogger_;

private:
    CICSRegistration* pReg_;
    vector<string> filterList_;
    vector<CICSAgentCondition*> recorders_;

public:
    static Recorder* instance(CICSRegistration* reg);

    ~Recorder();

    CICSRegistration* registration() {
        return pReg_;
    }
    void handleInvocation(const AscHeader &header,
            const struct COMMAREA * pCommArea);
    void handleInvocation( const AscHeader &header,
             const struct CONTAINER * pContainer);
    void checkRecorder(const AscHeader& header,
            map<string, string > & pMap);
    void configureRecording(Configuration* cfg);
    const vector<string>& getFilterList() {return filterList_;}

private:
    void setFilterList();
    void broadcast(map<string,string> activityMap,
            const string& correlator,
            RecordedEvent& event);
};

#endif // RECORD_H_
