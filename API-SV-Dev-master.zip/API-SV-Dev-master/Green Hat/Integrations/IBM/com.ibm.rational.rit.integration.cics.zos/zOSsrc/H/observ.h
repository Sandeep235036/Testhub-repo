/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017.All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/**********************************************************************
 * observ.h
 **********************************************************************/
#ifndef OBSERV_H_
#define OBSERV_H_
 
#include "ritcomm.h"
#include <map>
 
using namespace ::std;
using namespace ::google::protobuf;
 
//CHANGE
#define OBSERVATION_PATH       "rest/proxy/observation/"  //$NON-NLS-1$
#define OBSERVATION_PATH_TH    "rest/spaces/Initial/virtualization/observation/"  //$NON-NLS-1$
 
#define  RIT_OBSERV_LEVEL_NONE         "LEVEL_NONE"  //$NON-NLS-1$
#define  RIT_OBSERV_LEVEL_STATISTICS   "LEVEL_STATISTICS"  //$NON-NLS-1$
#define  RIT_OBSERV_LEVEL_RESOURCE     "LEVEL_RESOURCES"  //$NON-NLS-1$
#define  RIT_OBSERV_LEVEL_ALL          "LEVEL_ALL"  //$NON-NLS-1$
 
class Observation {
public:
    static const int DELETE_CHECK_POLL_INTERVAL = 5;
    static const int ROUGH_MAX_RESOURCES_PER_INTERVAL = 100;
    static const int INITIAL_DELAY = 10;
    static const int UPDATE_INTERVAL = 30;
 
private:
    pthread_rwlockattr_t rwlattr_;
    pthread_rwlock_t statslock_;
    pthread_rwlock_t levellock_;
 
    int requestCount_;
    int recordedCount_;
    int routedCount_;
    map<string, int> requestMap_;
 
    Logger* log_;
    CICSRegistration* pReg_;
    pthread_t thread_;
    int stop_;
    pthread_rwlock_t statuslock_;
 
private:
    Observation(const Observation&);
    void operator=(const Observation&);
    Observation(CICSRegistration* reg);
    static Observation* s_instance;
 
public:
    static Observation* instance(CICSRegistration* reg);
    ~Observation();
 
    CICSRegistration* registration() {
        return pReg_;
    }
    Logger* logger() {
        return log_;
    }
 
    void start(pthread_attr_t* attr);
    void stop(int status);
    int getStop();
 
    void setObservationLevel(RIT_OBSERV_LEVEL level){
        return pReg_->setObservLevel(level);
    }
    int observationLevel(){return pReg_->observLevel();}
 
    void getMessagePayload(string & msgPayload);
 
    void addRequestCount(const char* progname);
    void addRecordedCount();
    void addRoutingCount();
};
 
#endif
