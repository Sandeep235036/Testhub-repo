/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
#ifndef PARMS_H_
#define PARMS_H_

#include <map>
#include <string>
#include <queue>

class Parms {
public:
    enum PARAMETER{
        MININDEX,
        APPLID =1,
        BINDADDR,
        PORT,
        RTCPURL,
        LOGLEVEL,
        OBSERVATIONLEVEL,
        KEYRING,
        MAXINDEX
    };

    Parms();
    int parseParms(std::queue<std::string> &tokens);
    int parseArgs(int argc,char* argv[]);
    std::string getOptionValue(std::string option);
    virtual ~Parms();
private :
    std::map<PARAMETER,std::string> _params;
    const char* idToString(PARAMETER option);
    enum PARAMETER stringToId(std::string key);
};

#endif /* PARMS_H_ */
