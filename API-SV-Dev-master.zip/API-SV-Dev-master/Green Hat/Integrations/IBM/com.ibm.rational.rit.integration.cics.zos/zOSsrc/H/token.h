#ifndef TOKEN_H_
#define TOKEN_H_
#include <string>
//CHANGE
class TokenHandler {
public:
    static std::string accessToken;
    static std::string bearerToken;
    static void setAccessToken(const std::string& token);
    static void setBearerToken(const std::string& token);
    static void clearAccessToken();
};
#endif
