/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2019. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/***********************************************************************
 * cfgpoll.h
 **********************************************************************/
#ifndef CFGPOLL_H_
#define CFGPOLL_H_
 
#include "ritcomm.h"
#include <vector>
#include <string>
 
using namespace ::std;
//using namespace ::google::protobuf;
typedef ::greenhat::vie::comms::proxy::Configuration Configuration;
 
class Logger;
class ServerLogger;
class ConfigPoller {
private:
    ConfigPoller( const ConfigPoller&);
    void operator=(const ConfigPoller&);
    Logger*          log_;
    ServerLogger*    serverLogger_;
 
    pthread_t thread_;
    CICSRegistration* pReg_;
    int stop_;
    pthread_rwlockattr_t rwlattr_;
    pthread_rwlock_t statuslock_;
    Configuration* cfg_;
    ::google::protobuf::int64 logLevelupdate_;
    ::google::protobuf::int64 updated_;
    vector<string> filterList_;
    static ConfigPoller* s_instance;
    ConfigPoller(CICSRegistration* config);
 
public:
    static const int DEFAULT_CONFIGURATION_POLL_INTERVAL = 5;
 
public:
    static ConfigPoller* instance(CICSRegistration* reg);
    ~ConfigPoller();
    void start(pthread_attr_t* attr);
    void stop(int status);
    CICSRegistration* registration() {
        return pReg_;
    }
    Configuration* getConfig() {
        return cfg_;
    }
    void setConfig(Configuration* cfg) {
        DELETE(cfg_);
        cfg_ = cfg;
    }
    void clearFilterList(Configuration* cfg) {
        filterList_.clear();
    }
    int getStop();
    Logger* logger(){return log_;}
    ServerLogger* svrlogger(){return serverLogger_;}
    int onReceived();
    int cfgChanged();
 
private:
    int passFilterListToExit(const vector<string>& pl);
};
 
#endif // CFGPOLL_H_
