/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/**********************************************************************
 * cndtion.h
 **********************************************************************/
#ifndef CNDTION_H_
#define CNDTION_H_

#include <vector>
#include <set>
#include <string>
#include "ritcomm.h"
#include "socksvr.h"

typedef ::greenhat::vie::comms::proxy::Condition Condition;

class Logger;
class CICSAgentCondition {
    CICSAgentCondition( const CICSAgentCondition&);
    void operator=(const CICSAgentCondition&);
   set<string> ignProgs_;
   vector<string> filter_;
   string sysid_;
   string applid_;
   string jobname_;
   string url_;
   string activityId_;
   bool   isTS_;
   bool   isRouting_;
   Logger* log_;

public:
   CICSAgentCondition(const string & url, const string & activityId,
           bool isRouting = false);
   ~CICSAgentCondition(){};

   bool matches(const AscHeader& header) const;

   const string & getActivityId() {return activityId_;}

   const string & getUrl() {return url_;}

   const string & getSYSID() {return sysid_;}

   const string & getAPPLID() {return applid_;}

   const string & getJOBNAME() { return jobname_;}

   const vector<string> & getFilter() {return filter_;}

   bool isTS() {return isTS_;}

   bool isRouting() {return isRouting_;}

   // Used for unit testing
   void setFilter(const vector<string>& filter) {
       filter_ = filter;
   }

   void setCondition(const Condition& condition);

   void shouldWarn(const string& p) {
       string progname(p, 0, 8);
       ignProgs_.insert(progname);
   }

private:
   string findCICSType(const Condition & condition);
   bool isSingleFilter(const Condition & condition);
   bool isOrFilter(const Condition & condition);
   int  getFilterStr(const Condition & condition, string & filterStr);
};

#endif // CNDTION_H_
