/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/**********************************************************************
 * objxfer.h
 **********************************************************************/
#ifndef OBJXFER_H_
#define OBJXFER_H_

#include <string>
#include <curl/curl.h>
#include "proxy.h"
#include "logevent.h"

using namespace ::std;
using namespace ::greenhat::vie::comms::proxy;
using namespace ::google::protobuf;
using namespace ::com::ibm::greenhat::logging;

class Logger;
class ObjXfer {
    ObjXfer( const ObjXfer&);
    void operator=(const ObjXfer&);
    string url_;
    string keyring_;
    CURL* pcurl_;

public:
    ObjXfer(const string & url, const string & keyring = "");
    ObjXfer(const string & url, CURL* curl);
    ~ObjXfer();

    Registration* postRegistration(const string & url,
            Registration* msg, Logger* log);
    Registration* postRegistration(Registration* object, Logger* log) {
        return postRegistration(url_, object, log);
    }

    int postLog(const string& url, LogEventSet* object, Logger* log);
    int postLog(LogEventSet* object, Logger* log) {
        return postLog(url_, object, log);
    }

    int postObsrvMessage(const string& url, const string& message,
            Logger* log);
    int postObsrvMessage(const string& message, Logger* log) {
        return postObsrvMessage(url_, message, log);
    }

    Configuration* getObj(Logger* log){
        return getObj(url_, log);
    }
    Configuration* getObj(const string & url, Logger* log);


    bool remove(const string & url, Logger* log);
};

#endif // OBJXFER_H_
