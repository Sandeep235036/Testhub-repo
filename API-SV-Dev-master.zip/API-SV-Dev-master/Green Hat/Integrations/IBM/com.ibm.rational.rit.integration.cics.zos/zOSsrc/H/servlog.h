/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/**********************************************************************
 * serverlog.h
 **********************************************************************/

#ifndef SERVERLOG_H_
#define SERVERLOG_H_

#include "ritcomm.h"
#include "ritlog.h"
#include "logevent.h"
#include <queue>

#define SERVERLOG_PATH         "rest/logging/"  //$NON-NLS-1$
#define FAILURE_TIME_PROPERTY  "failureTime"    //$NON-NLS-1$

class Logger;
class ServerLogger {
    Logger* log_;
    CICSRegistration* pReg_;
    ::greenhat::vie::comms::proxy::LogEvent_Level logLevel_;
    pthread_t thread_;
    int stop_;
    pthread_rwlockattr_t rwlattr_;
    pthread_rwlock_t statuslock_;
    pthread_rwlock_t levellock_;
    queue<  com::ibm::greenhat::logging::LogEvent*> container_;
    pthread_mutexattr_t   attr_;
    pthread_mutex_t       mutex_;
private:
    void guardedLog( ::greenhat::vie::comms::proxy::LogEvent_Level level,
            string & message,
            map<string, string>* context);
    void truncateValues(map<string, string>* context);
    string& truncate(string & str);
    void logImpl( ::greenhat::vie::comms::proxy::LogEvent_Level level,
            const string & message,
             map<string, string>* context);
    ServerLogger(CICSRegistration* reg);
    static ServerLogger* s_instance;

public:
    static const int DEFAULT_SERVER_LOG_XMIT_INTERVAL = 5;
    static const int MAX_MESSAGE_LENGTH = 255;
    static const int MAX_LOGEVENT_NUMBER = 10000;
    static const int DEFAULT_SERVER_LOG_SEND_NUMBER = 500;

public:
    static ServerLogger* instance(CICSRegistration* reg);
    static ServerLogger* instance();
    virtual ~ServerLogger();

    CICSRegistration* registration() {return pReg_;}
    Logger* logger() {return log_;}
    pthread_mutex_t* mutex(){return &mutex_;}

    void start(pthread_attr_t* attr);
    void stop(int status);
    int getStop();

    void setLevel( ::greenhat::vie::comms::proxy::LogEvent_Level level);
    bool isLoggable( ::greenhat::vie::comms::proxy::LogEvent_Level level);

    queue< ::com::ibm::greenhat::logging::LogEvent*>& container()
            {return container_;}


    void debug(string & message) {
        debug(message, NULL);
    }

    void debug(string & message, map<string, string>* context) {
        guardedLog( ::greenhat::vie::comms::proxy::LogEvent_Level_DEBUG,
        message, context);
    }

    void debug(const char * message) {
        string msg(message);
        debug(msg, NULL);
    }

    void debug(const char * message, map<string, string>* context) {
        string msg(message);
        guardedLog( ::greenhat::vie::comms::proxy::LogEvent_Level_DEBUG,
        msg, context);
    }

    void info(string & message) {
        info(message, NULL);
    }

    void info(string & message, map<string, string>* context) {
        guardedLog( ::greenhat::vie::comms::proxy::LogEvent_Level_INFO,
        message, context);
    }

    void info(const char * message) {
        string msg(message);
        info(msg, NULL);
    }

    void info(const char * message, map<string, string>* context) {
        string msg(message);
        guardedLog( ::greenhat::vie::comms::proxy::LogEvent_Level_INFO,
        msg, context);
    }

    void warn(string & message) {
        warn(message, NULL);
    }

    void warn(string & message, map<string, string>* context) {
        guardedLog( ::greenhat::vie::comms::proxy::LogEvent_Level_WARN,
        message, context);
    }

    void warn(const char * message) {
        string msg(message);
        warn(msg, NULL);
    }

    void warn(const char * message, map<string, string>* context) {
        string msg(message);
        guardedLog( ::greenhat::vie::comms::proxy::LogEvent_Level_WARN,
        msg, context);
    }

    void error(string & message) {
        error(message, NULL);
    }

    void error(string & message, map<string, string>* context) {
        guardedLog( ::greenhat::vie::comms::proxy::LogEvent_Level_ERROR,
        message, context);
    }

    void error(const char * message) {
        string msg(message);
        error(msg, NULL);
    }

    void error(const char * message, map<string, string>* context) {
        string msg(message);
        guardedLog( ::greenhat::vie::comms::proxy::LogEvent_Level_ERROR,
        msg, context);
    }

    void log( ::greenhat::vie::comms::proxy::LogEvent_Level level,
            string & message,
            map<string, string>* context) {
        guardedLog(level, message, context);
    }

    void log( ::greenhat::vie::comms::proxy::LogEvent_Level level,
            string & message) {
        guardedLog(level, message, NULL);
    }


    void log( ::greenhat::vie::comms::proxy::LogEvent_Level level,
            const char* message,
            map<string, string>* context) {
        string msg(message);
        guardedLog(level, msg, context);
    }

    void log( ::greenhat::vie::comms::proxy::LogEvent_Level level,
            const char* message) {
        string msg(message);
        guardedLog(level, msg, NULL);
    }
};

#endif /* SERVERLOG_H_ */
