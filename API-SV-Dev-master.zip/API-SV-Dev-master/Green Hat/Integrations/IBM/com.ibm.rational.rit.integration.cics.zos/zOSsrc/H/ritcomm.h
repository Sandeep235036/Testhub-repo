/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/**********************************************************************
 * ritcomm.h
 * The common struct and class used in HRVCCICS agent.
 *********************************************************************/
#ifndef RITCOMM_H_
#define RITCOMM_H_
#ifndef _POSIX_SOURCE
#define _POSIX_SOURCE
#endif  //_POSIX_SOURCE

#ifndef _LARGE_TIME_API
#define _LARGE_TIME_API
#endif

#ifndef RESOLVE_VIA_LOOKUP
#define RESOLVE_VIA_LOOKUP
#endif

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <stdarg.h>
#include <pthread.h>
#include <string>
#include <string.h>
#include <map>
#include <algorithm>
#include <limits.h>

#include "proxy.h"
//#include "logevent.h"
#include "ritutil.h"

using namespace std;

#ifndef _OPEN_SYS_SOCK_IPV6
#define _OPEN_SYS_SOCK_IPV6
#endif

#ifndef __LIBASCII
#define __LIBASCII  // for inet_ntoa()
#endif

#ifndef RIT_CICS_AGENT_OS
#define RIT_CICS_AGENT_OS       "z/OS"//$NON-NLS-1$
#define RIT_CICS_AGENT_VERSION  "@VERSION@"//$NON-NLS-1$
#define RIT_CICS_AGENT_BUILDLVL "@BUILDLEVEL@"//$NON-NLS-1$
#define RIT_CICS_AGENT_USERNAME "SYSTASK"//$NON-NLS-1$
#endif

#ifndef DELETE
#define DELETE(a) {delete(a);a=NULL;}
#endif

#ifndef FPRINTF
#define FPRINTF  fprintf_mvs
extern "C" int fprintf_mvs(FILE* stream,  const char * format, ...);
#endif /* FPRINTF */

#ifndef NULL
#define NULL 0
#endif // NULL

#define ERR_BUF_LEN         256
#define RIT_PORTNUM_LEN            5
#define RIT_SERVER_SELECT_TIMEOUT  1
#define RIT_BUFFER_LEN_80          80
#define RIT_EXCI_RETRY_INTERVAL    5
#define RIT_DEFAULT_CONNECT_TIMEOUT 300
#define RIT_DEFAULT_TRANSFER_RETRY  1
#define RIT_DEFAULT_LOW_SPEED_TIME  5
#define RIT_DEFAULT_LOW_SPEED_LIMIT 128
#define RIT_DEFAULT_WAIT_TIMEOUT    30
#define EXCI_MAX_ERROR_COUNT       5
#define RTCP_MAX_ERROR_COUNT       360     /* 360*5=1800s=30min */
#define MAX_PORT_NUMBER            65535
#define MAX_JOBID_LEN              8
#define MAX_APPLID_LEN             8
#define MAX_SYSID_LEN              4
#define MEMORY_ALLOC_FAILURE       -10009
#define MAX_LOG_FILENAME_LEN       64
#define RIT_DPL_FILTER_LEN         13
#define RIT_PROGRAM_NAME_LEN       8
#define RIT_PROGRAM_RULE_LEN       9
#define RIT_TRANSACTION_NAME_LEN   4
#define RIT_TRANSACTION_RULE_LEN   5
#define RIT_MAX_FILTER_NUM         39
#define RIT_MAX_FILTER_LEN         (13 * 39) /*507*/
#define MAX_LOG_MESSAGE_LEN        512
#define RIT_CICS_TMP_PATH          "/tmp/HRVCCICS_"

#ifndef UUID_LENGTH
#define UUID_LENGTH 36
#endif

typedef enum ObservLevel {
    LEVEL_NONE = 0,
    LEVEL_STATISTICS = 1,
    LEVEL_RESOURCES = 2,
    LEVEL_ALL = 3
} RIT_OBSERV_LEVEL;

struct CICSAgentConfig {
    int port_;
    ::greenhat::vie::comms::proxy::LogEvent_Level loglevel_;
    RIT_OBSERV_LEVEL observ_;
    int rtcpMaxErrnum_;
    int exciMaxErrnum_;
    string applid_;
    string bindaddr_;
    string hostname_;
    string server_url_;
    string gsk_keyring_ring_;
    int debugStubCA_;
};

char* trimBlank(char* str);
char* trimTailBlank(char* str);
char* trimPreBlank(char* str);
string& trimString(string& str);
long getConnTimeout();
long getTranferRetry();
long getWaitTimeout();
long getLowSpeedLimit();
long getLowSpeedTime();

class Logger;
class MutexGuard {
    pthread_mutex_t * pMutex_;
    Logger* log_;
public:
    MutexGuard(pthread_mutex_t * pMtx, Logger* log);
    ~MutexGuard();
};

class CICSRegistration {
    int port_;
    volatile ::greenhat::vie::comms::proxy::LogEvent_Level loglevel_;
    volatile RIT_OBSERV_LEVEL observ_;
    int rtcpMaxErrnum_;
    int exciMaxErrnum_;
    volatile int enabled_;
    string applid_;
    string sysid_;
    string jobname_;
    string bindaddr_;
    string hostname_;
    string server_url_;
    string gsk_keyring_ring_;
    string uuid_;

    pthread_rwlockattr_t rwlattr_;
    pthread_rwlock_t loglvllock_;
    pthread_rwlock_t obsvlvllock_;
    pthread_rwlock_t uuidlock_;
    pthread_rwlock_t statuslock_;

    Logger* log_;
    int     debugStubCA_;

    pthread_mutex_t mtxCorrel_;
    map<string, string> correlMap_;
    string currCorel_;

    CICSRegistration(const string & applid,
            const string & bindaddr,
            const string & hostname,
            int port,
            const string & serverurl,
            ::greenhat::vie::comms::proxy::LogEvent_Level loglevel,
            RIT_OBSERV_LEVEL observLevel,
            int rtcpMaxErrnum,
            int exciMaxErrnum,
            const string & gsk_keyring_ring,
            int debugStubCA);
    static CICSRegistration* s_instance;

public:
    static CICSRegistration* instance(CICSAgentConfig* config);
    static CICSRegistration* getInstance();
    ~CICSRegistration();
    const string & applid() {
        return applid_;
    }
    const string & sysid() {
        return sysid_;
    }
    const string & jobname() {
        return jobname_;
    }
    const string & hostname() {
        return hostname_;
    }
    const string & bindAddr() {
        return bindaddr_;
    }
    const string & serverUrl() {
        return server_url_;
    }
    const string & gsk_keyring_ring() {
        return gsk_keyring_ring_;
    }
    Logger* logger() {
        return log_;
    }
    int port() {
        return port_;
    }
    int rtcpMaxErrnum() {
        return rtcpMaxErrnum_;
    }
    int exciMaxErrnum() {
        return exciMaxErrnum_;
    }

    int isDebugStubCA() {
        return debugStubCA_;
    }

    ::greenhat::vie::comms::proxy::LogEvent_Level logLevel();
    void setLogLevel(::greenhat::vie::comms::proxy::LogEvent_Level level);
    string uuid();
    void setId(const string & id);

    void setSYSID(const string& sysid){sysid_ = sysid; trimString(sysid_);}
    void setJOBNAME(const string& jobname){jobname_ = jobname; trimString(jobname_);}

    int status();
    void setStatus(int enabled);
    RIT_OBSERV_LEVEL observLevel();
    void setObservLevel(RIT_OBSERV_LEVEL level);

    string & getCorrelID(const char* inCorrel);
};

struct ObjectToSend {
    char *readptr;
    long sizeleft;
    ObjectToSend() {
        readptr = 0;
        sizeleft = 0;
    }
    ~ObjectToSend() {
        if (readptr != NULL) {
            free(readptr);
        }
    }
};

struct ObjectReceived {
    char *ptr;
    long len;

    ObjectReceived() {
        len = 0;
        ptr = (char*) malloc(len + 1);
        if (ptr == NULL) {
            exit(MEMORY_ALLOC_FAILURE);
        }
        ptr[0] = '\0';
    }
    ~ObjectReceived() {
        if (ptr != NULL) {
            free(ptr);
        }
    }
};

typedef ::greenhat::vie::comms::proxy::RecordedEvent RecordedEvent;

struct Posted_Event {
    string url_;
    string act_;
    string correl_;
    RecordedEvent * event_;
};

const char* RIT_HTTP_HEADER_CONTENT_TYPE =
        "Content-Type: application/x-gh-ctg"; //$NON-NLS-1$
const char* RIT_JSON_HTTP_HEADER_CONTENT_TYPE =
        "Content-Type: application/json; charset=utf-8"; //$NON-NLS-1$ ;
const char* RIT_HTTP_HEADER_SOURCE = "X-GH-Source: "; //$NON-NLS-1$
const char* RIT_HTTP_HEADER_ACTIVITYID =
        "X-GH-ActivityID: "; //$NON-NLS-1$
const char* RIT_HTTP_CorrelationID =
        "X-GH-CorrelationID: "; //$NON-NLS-1$
const char* RIT_HTTP_TIMESTAMP = "X-GH-Timestamp: "; //$NON-NLS-1$

/**
 * no longer being listened for...
 */
const int HTTP_CODE_EVENT_PARTIALLY_DISCARDED = 404;

const char* RIT_HTTP_HEADER_ACTION = "X-GH-Action"; //$NON-NLS-1$
const char* RIT_HTTP_HEADER_PASS_THROUGH =
        "X-GH-PassThrough: "; //$NON-NLS-1$

const char* RIT_PASS_THROUGH_VAL_PASSTHROUGH =
        "PassThrough"; //$NON-NLS-1$

const char* RIT_PASS_THROUGH_VAL_ERROR = "Error"; //$NON-NLS-1$

const char* RIT_HTTP_HEADER_ACTION_VAL_INTERCEPT =
        "Intercept"; //$NON-NLS-1$

const char* DOMAIN_PROPERTY = "Domain"; //$NON-NLS-1$

const char* ENVIRONMENT_PROPERTY = "Environment"; //$NON-NLS-1$

const char* ACTIVITY_ID_PROPERTY = "Activity Id"; //$NON-NLS-1$

const ::greenhat::vie::comms::proxy::LogEvent_Level DEFAULT_LOG_LEVEL =
        ::greenhat::vie::comms::proxy::LogEvent_Level_INFO;

extern "C" size_t stub_read(void *ptr, size_t size, size_t nmemb,
        void *userp);

extern "C" size_t record_read(void *ptr, size_t size, size_t nmemb,
        void *userp);

extern "C" size_t record_write(void *buffer, size_t size, size_t nmemb,
        void *userp);

extern "C" size_t header_write(void *ptr, size_t size, size_t nmemb,
        void *userdata);

int getHeaderField(const ObjectReceived & http_resp_header,
        const char* header,
        string & value);
int convert(const char* from, size_t* inlen, char** to, size_t* outlen);

int ebc2asc(const string& inStr, string& out);
int ebc2asc(const char* inStr, string& out);
int ebc2utf(const string& inStr, string& out);
int ebc2utf(const char* inStr, string& out);
int asc2ebc(const string& inStr, string& out);
int asc2ebc(const char* inStr, string& out);
int utf2ebc(const string& inStr, string& out);
int utf2ebc(const char* inStr, string& out);
int asc2ebc(const char* from, size_t inlen, char** to, size_t* outlen);

int ebc2asc(const char* from, size_t inlen, char** to, size_t* outlen);

int convert(const char* fromCode, const char* toCode, const char* from,
        size_t inlen, char** to, size_t* outlen);
/*  Convert a string to BCD string */
char* toBcdStr(const char* fromStr, char* toStr, int len);
string & upperString(string & inStr);
string & lowerString(string & inStr);

#ifndef  RIT_PROGRAM_FILTER_LEN
#define  RIT_PROGRAM_FILTER_LEN    9
#define  RIT_MAX_FILTER_NUMBER     56
#define  RIT_PGM_FILTER_LENGTH     (9*56)
#endif

int enableRit(CICSRegistration* cicsreg, Logger* log, int cmd);

#endif /* RITCOMM_H_ */
