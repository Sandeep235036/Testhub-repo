/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/**********************************************************************
 * mulxfer.h
 **********************************************************************/
#ifndef MULXFER_H_
#define MULXFER_H_

#include <string>
#include <curl/curl.h>
#include "proxy.h"

using namespace ::std;
using namespace ::greenhat::vie::comms::proxy;
using namespace ::google::protobuf;

class MultiXfer {
    //CURLM *pmcurl_;
    CURL*  pcurl_;
    pthread_t thread_;

public:
    MultiXfer();
    ~MultiXfer();

    void postObj(const string& url, const string & activites,
            RecordedEvent* object);
//    void postObj(map<string, string >& activityMap,
//            RecordedEvent* object);
};

#endif // MULXFER_H_
