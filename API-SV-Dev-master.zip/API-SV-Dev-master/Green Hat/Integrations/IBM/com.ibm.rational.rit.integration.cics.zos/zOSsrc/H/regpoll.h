/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/**********************************************************************
 * regpoll.h
 **********************************************************************/
#ifndef REGPOLL_H_
#define REGPOLL_H_

#include "ritcomm.h"

//using namespace ::google::protobuf;
typedef ::greenhat::vie::comms::proxy::Registration Registration;

class Logger;
class ServerLogger;
class RegisterPoller {
public:
    static const int DEFAULT_REGISTRATION_POLL_INTERVAL = 30;
private:
    RegisterPoller( const RegisterPoller&);
    void operator=(const RegisterPoller&);

private:
    Logger*         log_;
    ServerLogger*   serverLogger_;
    pthread_t thread_;
    CICSRegistration* pReg_;
    int stop_;
    pthread_rwlockattr_t rwlattr_;
    pthread_rwlock_t statuslock_;
    Registration reg_;
    RegisterPoller(CICSRegistration* config);
    static RegisterPoller* s_instance;

public:
    static const int DEFAULT_CONFIGURATION_POLL_INTERVAL = 5;

public:
    static RegisterPoller* instance(CICSRegistration* reg);

    ~RegisterPoller();
    void start(pthread_attr_t* attr);
    void stop(int status);
    int getStop();
    CICSRegistration* registration() {
        return pReg_;
    }
    Registration* getRegistration(){
        return &reg_;
    }
    Logger* logger() {return log_;}
};

#endif // REGPOLL_H_
