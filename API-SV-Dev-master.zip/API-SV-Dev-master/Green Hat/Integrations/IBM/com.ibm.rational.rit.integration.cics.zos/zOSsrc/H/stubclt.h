/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/**********************************************************************
 * stubclt.h
 **********************************************************************/
#ifndef STUBCLT_H_
#define STUBCLT_H_

#include "socksvr.h"
#include "proxy.h"
#include "ritcomm.h"

#include <vector>
#include <string>

using namespace ::std;
using namespace ::google::protobuf;
using namespace greenhat::vie::comms::proxy;

class Logger;
class ServerLogger;
class CICSAgentCondition;
class StubClient{
private:
    StubClient( const StubClient&);
    void operator=(const StubClient&);
    StubClient(CICSRegistration* reg);

    static StubClient* s_instance;
    pthread_rwlockattr_t rwlattr_;
    pthread_rwlock_t rwlock_;
    Logger* log_;
    ServerLogger* serverLogger_;

    CICSRegistration* pReg_;
    vector<string>  filterList_;
    vector<CICSAgentCondition*> clients_;

public:
    static StubClient* instance(CICSRegistration* reg);
    ~StubClient();

    bool handleStub(struct ASCHeader& header,
            struct COMMAREA * pCommArea, CICSAgentCondition* stubClient);
    bool handleStub(struct ASCHeader& header,
            struct CONTAINER ** pCommArea, CICSAgentCondition* stubClient);

    void configureStubbing(Configuration* cfg);
    const vector<string>& getFilterList() {return filterList_;}
    CICSAgentCondition* match(const AscHeader& header);
    bool post_event(Posted_Event* pe);
private:
    void  setFilterList();
};
#endif //STUBCLT_H_
