/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/**********************************************************************
 * svrpoll.h
 * ********************************************************************/
#ifndef SVRPOLL_H_
#define SVRPOLL_H_

#include <string>
#include "ritcomm.h"

using namespace std;

class RegisterPoller;
class ConfigPoller;
class ServerLogger;
class Observation;
class Logger;
class ServerPoller {
private:
    ServerPoller( const ServerPoller &);
    void operator=(const ServerPoller&);
    static ServerPoller* s_instance;
    ServerPoller(CICSRegistration* reg);

private:
    RegisterPoller* regPoller_;
    ConfigPoller*   cfgPoller_;
    ServerLogger*   serverLogger_;
    Observation*    observation_;
    CICSRegistration* pReg_;
    pthread_attr_t thrattr_;
    Logger*        log_;

public:
    static ServerPoller* instance(CICSRegistration* reg);
    ~ServerPoller();

    void start();
    void stop();

    CICSRegistration* registration() {return pReg_;}

    bool suspendRule(const string& ruleId);
    Logger* logger(){return log_;}
    ServerLogger* svrlogger(){return serverLogger_;}
};

#endif // SVRPOLL_H_
