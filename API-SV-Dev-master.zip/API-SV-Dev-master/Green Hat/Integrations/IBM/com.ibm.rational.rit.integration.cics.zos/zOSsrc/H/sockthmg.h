/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*
 * sockthmg.h
 *
 *  Created on: 2016-5-24
 *      Author: martin
 */

#ifndef SOCKTHMG_H_
#define SOCKTHMG_H_
#include <deque>
#include <pthread.h>
#include <vector>
#include "ritlog.h"

typedef void* (*SocketHandler)(int);

extern "C" void* workerThread(void*);
class SockThreadManager {
public:
    SockThreadManager(void* (*handler)(int));
    virtual ~SockThreadManager();
    int scheduleTask(int fd);
    int consumeTask();
    int startWorker(int workers);
    void stopWorker();

    SocketHandler getHandler()
    {
        return handler;
    }

private:

    SocketHandler handler;
    std::vector<pthread_t> workerpool_;
    std::deque<int> eventQueue_;
    pthread_attr_t thread_attr_;
    pthread_condattr_t cond_attr_;
    pthread_cond_t cond_;
    pthread_mutex_t mutex_;
    pthread_mutexattr_t mutexattr_;
    Logger* logger_;
    int seq_;
};

#endif /* SOCKTHMG_H_ */
