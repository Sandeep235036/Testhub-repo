/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*
 * protocol.h
 *
 *  Created on: 2016-5-25
 *      Author: martin
 */

#ifndef PROTOCOL_H_
#define PROTOCOL_H_
#include <stdlib.h>
#include <string.h>
#define CHANNEL_NAME        "RITCHANNEL      "
#define RIT_DUMMY_PGM       "HRVDMPGM"
#define RIT_DUMMY_TRN       "HRVN"
#define RIT_DUMMY_JOB       "HRVDMJOB"
#define RIT_DUMMY_COR       "ZYXW"
#define RIT_MAGIC_RESP      9999

#define RIT_PLTSD_PGM       "HRVSDPGM"
#define RIT_PLTSD_JOB       "HRVSDJOB"
#define RIT_PLTSD_COR       "HRVP"
#define RIT_PLTSD_RESP      9898

#define RIT_DUMMY_COR_BCD   "E9E8E7E6"    /* BCD string for "ZYXW" */
#define RIT_PLTSD_COR_BCD   "D9C9E3D7"    /* bcd STRING FOR "RITP" */

struct HEADER {
    char progName[8];
    char tranID[4];
    char jobName[8];
    char correl[4];
    char abendCode[4];
    int reqresp;
    char channelName[16];
    int length;
    int dataLength;
    int response;
};
typedef struct HEADER Header;

struct ASCHeader {
    char progName[9];
    char tranID[5];
    char jobName[9];
    char correl[9];
    char abendCode[5];
    char channelName[17];
    int  reqresp;
    int length;
    int dataLength;
    int response;
#ifdef __cplusplus
    ASCHeader(const Header& hdr);
#endif
};
typedef struct ASCHeader AscHeader;

struct COMMAREA{
    char*       pCommarea;
    int         len;
#ifdef __cplusplus
    COMMAREA(int sz){
        if(sz > 0){
            len = sz;
            pCommarea = new char[sz+1];
        }else {
            len = 0;
            pCommarea = NULL;
        }
    }
    COMMAREA(){
        len = 0;
        pCommarea = NULL;
    };
    ~COMMAREA(){
        if(pCommarea != NULL){
            delete [] pCommarea;
            pCommarea=NULL;
        }
    }
#endif
};
typedef struct COMMAREA Commarea;

struct CONTAINERHEADER {
    char containerName[16];
    int length;
};

typedef struct CONTAINERHEADER ContainerHeader;

 struct ASCCONTAINERHEADER {
    char containerName[17];
    int length;
#ifdef __cplusplus
    ASCCONTAINERHEADER(const CONTAINERHEADER &hdr);
    ASCCONTAINERHEADER(const ASCCONTAINERHEADER &hdr);
    ASCCONTAINERHEADER(const char* containerName,int length);
    void toContainerHeader(CONTAINERHEADER & hdr);
#endif
};
typedef struct ASCCONTAINERHEADER AscContainerHeader;

struct CONTAINER{
    AscContainerHeader header;
    char* dataarea;
    struct CONTAINER* next;
#ifdef __cplusplus
    CONTAINER(CONTAINERHEADER header):header(header){
        if(header.length > 0) {
            dataarea = new char[header.length+1];
        }
        next = NULL;
    }

    CONTAINER(ASCCONTAINERHEADER header):header(header){
        if(header.length > 0) {
            dataarea = new char[header.length+1];
        }
        next = NULL;
    }

    ~CONTAINER(){
        if(dataarea != NULL){
            delete [] dataarea;
            dataarea=NULL;
        }
    }
#endif
};

typedef struct CONTAINER Container;



#endif /* PROTOCOL_H_ */
