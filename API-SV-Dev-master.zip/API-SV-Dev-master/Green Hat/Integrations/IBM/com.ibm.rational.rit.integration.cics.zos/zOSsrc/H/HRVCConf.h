/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*
 * HRVCConf.h
 *
 *  Created on: May 19, 2016
 *      Author: ibmadmin
 */

#ifndef HRVCCONF_H_
#define HRVCCONF_H_

class HRVCConf {
public:
    static HRVCConf* getInstance();
private:
    HRVCConf();
    virtual ~HRVCConf();

    static HRVCConf* s_instance;

};

#endif /* HRVCCONF_H_ */
