/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*******************************************************************************
 * sockclt.cpp
 * ****************************************************************************/
#include <string.h>
#include <stdio.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/uio.h>
#include <netdb.h>
#include <errno.h>
#include <unistd.h>

#include "socksvr.h"
#include "protocl.h"


int output(struct iovec* iov, int num){
    Header * pHdr = (Header*)iov;
    printf("Progname=%s\n", pHdr->progName);
    printf("jobname=%s\n", pHdr->jobName);
    printf("Length=%s\n", pHdr->length);
    printf("Datalength=%s\n", pHdr->dataLength);
    (int)num;
    return 0;
}

void testclt(char* progName);

int main(){
    testclt("REMOTE");
   // testclt("REMOTE1");
   // testclt("TESTPROG");
    return 0;
}

void testclt(char* progName){
    char commArea[256] = "The payload.3456";
    int commAreaLen = 256;
    Container container;

    memset((void*)&container, 0, sizeof(container));
    strncpy(container.header.progName, progName, 8);
    strncpy(container.header.jobName, "TESTJOBP", 8);
    container.header.length = 256;
    container.header.dataLength = 256;
    container.header.reqresp = 4;
    strncpy(container.header.correl, "1234", 4);
    container.comArea.pCommarea = new char[256];
    memset(container.comArea.pCommarea, 0, 256);
    memcpy(container.comArea.pCommarea, commArea, strlen(commArea));

    int actualLen = container.header.length;
    if (container.header.dataLength > 0
            && container.header.dataLength < container.header.length) {
        actualLen = container.header.dataLength;
    }
    container.comArea.len = actualLen;

    struct sockaddr_in   cliaddr;
    char *    hostname = HOSTNAME;
    struct hostent *hp = gethostbyname(hostname);

    int cltfd = socket(AF_INET, SOCK_STREAM, 0);

    memset(&cliaddr, 0, sizeof(cliaddr));
    cliaddr.sin_family      = AF_INET;
    cliaddr.sin_addr.s_addr = *((ip_addr_t*)hp->h_addr);
    cliaddr.sin_port        = htons(DEFAULT_SERV_PORT);


    int rc = connect(cltfd, (struct sockaddr *) &cliaddr,
            sizeof(cliaddr));
    if(rc != 0){
        printf("connect error, errno=%d\n", errno);
    }

    struct iovec iov[2];
    iov[0].iov_base = (char*)&container.header;
    iov[0].iov_len = sizeof(container.header);
    iov[1].iov_base =(char*)&container.comArea.pCommarea;
    iov[1].iov_len = container.comArea.len;

    ssize_t bytes = writev(cltfd,
            (const struct iovec *)iov, 2);
    //bytes == sizeof(container) + sizeof(iov[0].iov_len);
    if(bytes < 0)
        printf("writev error, errno=%d\n", errno);


    ssize_t rcv = readv(cltfd, (const struct iovec *)iov, 1);

    if(rcv > 0) {
        printf("recv %d bytes from server\n", rcv);
        output(iov, 2);
    }

    ssize_t nsize = container.header.length;
    if(nsize > 0) {
        ssize_t datalen = container.header.dataLength;
        if(datalen > 0 && datalen < nsize) {
            nsize = datalen;
        }
        iov[1].iov_len = nsize;
        ssize_t rcv = readv(cltfd, (const struct iovec *)(iov + 1), 1);
    }

    close(cltfd);
}
