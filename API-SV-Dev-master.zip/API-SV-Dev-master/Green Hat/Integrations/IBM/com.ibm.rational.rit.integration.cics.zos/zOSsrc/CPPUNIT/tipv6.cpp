/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*******************************************************************************
 * objxfer.cpp
 * Class implementation
 ******************************************************************************/
#pragma csect (CODE,"TIPV6")
#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>


int main(){

    string ostr;
    pMsg->SerializeToString(&ostr);
    struct ObjectToSend objSend;
    struct ObjectReceived objRecv;

    objSend.sizeleft = (long) ostr.length();
    objSend.readptr = (char*) malloc(objSend.sizeleft);
    if (objSend.readptr == NULL) {
        FPRINTF(stdout, "Malloc error, errno=%d. Exiting...", errno);//$NON-NLS-1$
        exit(MEMORY_ALLOC_FAILURE);
    }
    memcpy((void*) objSend.readptr, (const void*) ostr.c_str(), ostr.length());
    objSend.readptr[ostr.length() - 1] = '\0';

    // First set the URL that is about to receive our POST.
    curl_easy_setopt(pcurl_, CURLOPT_URL, url.c_str());
    curl_easy_setopt(pcurl_, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_WHATEVER);
    // Now specify we want to POST data
    curl_easy_setopt(pcurl_, CURLOPT_POST, 1L);
    //curl_easy_setopt(pcurl_, CURLOPT_NOSIGNAL, 1L);
    // we want to use our own read function
    curl_easy_setopt(pcurl_, CURLOPT_READFUNCTION, record_read);
    // pointer to pass to our read function
    curl_easy_setopt(pcurl_, CURLOPT_READDATA, &objSend);
    curl_easy_setopt(pcurl_, CURLOPT_WRITEFUNCTION, record_write);
    curl_easy_setopt(pcurl_, CURLOPT_WRITEDATA, &objRecv);

    // Set the expected POST size. If you want to POST large amounts of data,
    // consider CURLOPT_POSTFIELDSIZE_LARGE/
    curl_easy_setopt(pcurl_, CURLOPT_POSTFIELDSIZE,
            (curl_off_t) objSend.sizeleft);

    // Perform the request, res will get the return code
    CURLcode res = curl_easy_perform(pcurl_);
    // Check for errors
    if (res != CURLE_OK) {
        log->error("ObjXfer::postRegister: curl_easy_perform() failed: %s",//$NON-NLS-1$
                curl_easy_strerror(res));
        return NULL;
    }
    long httpCode = 0;
    res = curl_easy_getinfo(pcurl_, CURLINFO_RESPONSE_CODE, &httpCode);
    if (res != CURLE_OK) {
        log->error("postObj: curl_easy_getinfo() failed: %s",//$NON-NLS-1$
                curl_easy_strerror(res));
        return NULL;
    }
#ifdef DEBUG_OBJXFER
    FPRINTF(stdout, "HTTP RESPONSE CODE AFTER POST: %d\n", httpCode);//$NON-NLS-1$
#endif // DEBUG_OBJXFER
    if (200 != httpCode)
        return NULL;
