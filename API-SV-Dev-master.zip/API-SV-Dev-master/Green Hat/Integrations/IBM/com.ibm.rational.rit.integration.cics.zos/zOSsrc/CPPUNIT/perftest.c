#pragma XOPTS(EXCI)
#pragma csect (CODE,"PERFTEST")
/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*********************************************************************
 * perftest.c
 *********************************************************************/

#ifndef _LARGE_TIME_API
#define _LARGE_TIME_API
#endif

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>

#include "dfhxcplh.h"

#define RITPERFT_NAME "PERFRM03"

#define no_abort   0
#define yes        1
#define MAX_COMMAREA_LENGTH 512   /* 56*9=504 +4=512 */
void linkrets(exci_exec_return_code *);

typedef struct TESTCOMM{
   char  progname[9];        /* PIC A(8).            */
   char  sysid[5];           /*  PIC A(6).           */
   int   request;            /* PIC 9(9).            */
   int   answer;             /* PIC 9(18).           */
   char  time01[8];
   char  time02[8];
   int   eclapsedTime;       /* PIC S9(15).          */
   char  COMMENT[256];       /*    PIC A(256).       */
} TestComm;
/*===================================================================*/
/*                                                                   */
/*   execcall:    This routine will use an EXEC level EXCI link      */
/*                request to call into the target CICS system, and   */
/*                invoke the RITCONFG program                        */
/*===================================================================*/
int execcall(TestComm* pcomm,
              const char* system)
{
#ifdef DEBUG_RITEXCID
     fprintf(stdout, "Entering execcall...\n");
     fprintf(stdout, "The CICS applid is: %s\n", system);
             pcomm->ruleNum);
#endif
     char transid??(5??) = {0};
     char program??(9??) = {0};
     char applid??(9??) = {0};
     strncpy(transid, "RITX", 4);
     strncpy(program, RITPERFT_NAME,8);
     strncpy(applid, system, 8);
/*===================================================================*/
/*   Declare local variables.                                        */
/*===================================================================*/
                                           /*=====================*/
 exci_exec_return_code link_retarea;          /* EXEC Return area.   */
 short int link_commlength;                   /* Length of Commarea  */
 short int link_datalength;                   /* Len of outbound area*/
 short int abort_needed = no_abort;           /* Abort flag.         */
/*===================================================================*/
/*   Set the Commarea Length and Data Length constants(in bytes).    */
/*===================================================================*/
    link_commlength = sizeof(TestComm);
/*    link_datalength = 100;*/
    link_datalength = link_commlength;

#ifdef DEBUG_RITEXCID
     fprintf(stdout, "Before call execcall: EXEC_CICS_LINK\n");
     fprintf(stdout, "Comm-area length is %d\n", link_commlength);
     fprintf(stdout, "Data length is %d\n", link_datalength);
#endif
/*===================================================================*/
/*                                                                   */
/*   Perform the Link Request.                                       */
/*                                                                   */
/*===================================================================*/
  EXEC CICS LINK PROGRAM(program)
                      APPLID(system)
                      RETCODE(&link_retarea)
                      COMMAREA(pcomm)
                      LENGTH(link_commlength)
                      DATALENGTH(link_datalength)
                      TRANSID(transid)
                      SYNCONRETURN;

#ifdef DEBUG_RITEXCID
     fprintf(stdout,
         "After call execcall: EXEC_CICS_LINK, return code=%d\n",
         link_retarea.exec_resp);
#endif
/*===================================================================*/
/*                                                                   */
/*   Check on how successful the call was.                           */
/*                                                                   */
/*===================================================================*/
                                           /*========================*/
   if (link_retarea.exec_resp != 0)        /* Check high lvl response*/
   {                                       /*                        */
      linkrets(&link_retarea);             /* Output response codes  */
      abort_needed=yes;                    /*                        */
   }                                       /*                        */
   return(abort_needed);                   /*========================*/
}

void linkrets(exci_exec_return_code *pRet_Area)
{
    char      pMsg_String[256];
    short int Msg_Len;
    /* output response, reason, subreason */
    fprintf(stdout, "EXCI LINK failed. "
    "Response = %d Response2 = %d "
      "Abend Code = %4.4s*\n",
               pRet_Area->exec_resp,
               pRet_Area->exec_resp2,
               pRet_Area->exec_abcode);

    /* output message if one exists */
    if (pRet_Area->exec_msg_ptr != NULL)
    {
      /* get message length       */
      Msg_Len = pRet_Area->exec_msg_len;
      Msg_Len = Msg_Len > 255 ? 255 : Msg_Len;
      memcpy(pMsg_String, pRet_Area->exec_msg_ptr, Msg_Len);

      /* null terminate our message string */
      *(pMsg_String + Msg_Len) = '\0';

      /* output message */
      fprintf(stderr, "%80.120s\n", pMsg_String);
    }

    return;
}

int main(int argc, char** argv){
    time64_t ltime, ltime2;
    time64(&ltime);
    printf("%s", ctime64(&ltime));

    int count = 0;
    char applid[9] = {0};

    if(argc > 1){
        count = atoi(argv[1]);
    }
    if(count < 1){
        count = 100;
    }

    if(argc > 2){
        strncpy(applid, argv[2], 8);
    }
    if(strlen(applid) < 8){
        strcpy(applid, "IY3HZCI5");
    }

    TestComm comm;
    memset(&comm, 0, sizeof(comm));

    int rc = 0;
    for(int i = 0; i < count && rc == 0; i++){
        comm.request = i + 1;
        rc = execcall(&comm, applid);
        if(rc == 0){
            printf("Request=%d,answer=%d,eclapse time=%d\n",
            comm.request, comm.answer, comm.eclapsedTime);
        }else{
            printf("ececcall failed. rc=%d", rc);
        }
    }

    time(&ltime2);
    printf("%s", ctime(&ltime2));
    printf("Eclapsed time is %d seconds\n", ltime2 - ltime);

    return 0;
}
