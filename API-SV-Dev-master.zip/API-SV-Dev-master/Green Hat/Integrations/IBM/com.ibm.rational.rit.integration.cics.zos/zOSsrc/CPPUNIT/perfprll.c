#pragma csect (CODE,"PERFPRLL")
/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*********************************************************************
 * perfprll.c
 *********************************************************************/
#define _POSIX_SOURCE
#define _XOPEN_SOURCE_EXTENDED 1
#ifndef _LARGE_TIME_API
#define _LARGE_TIME_API
#endif

#include <sys/types.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>

#define MAX_LEN 81

int main(int argc, char** argv) {
    time64_t ltime, ltime2;
    time64(&ltime);
    printf("%s", ctime64(&ltime));

    int taskCount = 0;

    if (argc > 1) {
        taskCount = atoi(argv[1]);
    }
    if (taskCount < 1) {
        taskCount = 100;
    }

    if (taskCount > 1000) {
        taskCount = 1000;
    }

    FILE * sysut1 = NULL;
    FILE * sysut2 = NULL;
    char line[MAX_LEN], *result;
    int num;

    for (int i = 0; i < taskCount; i++) {
        char buffer1[ 16 ] = "//JOBNAME";
        char buffer2[ 16 ] = "//PRF";
        char buffer3[ 16 ] = "";

        sprintf(buffer3, "000%d", i + 1);
        num = strlen(buffer3);
        strncat(buffer2, buffer3 + num - 4, 4);

        printf("buffer2 = %s\n", buffer2);
        sysut1 = fopen("DD:SYSUT1", "r");
        if (sysut1 == NULL) {
            perror("fopen() failed");
            printf("__errno2 = %08x line=%d\n",
                    __errno2(), __LINE__);
            break;
        }
        sysut2 = fopen("DD:SYSUT2", "w");
       /* "w,RECFM=FB,LRECL=80,BLKSIZE=800");*/
        if (sysut2 == NULL) {
            perror("fopen() failed");
            printf("__errno2 = %08x line=%d\n",
                    __errno2(), __LINE__);
            break;
        }
        int firstline = 1;
        while ((result = fgets(line, MAX_LEN, sysut1)) != NULL) {
            printf("The string is %s\n", result);
            if(firstline && strncmp(line, buffer1, 9) == 0){
                firstline = 0;
                for(int j = 0; j < 9; j++){
                    line[j] = buffer2[j];
                }
            }
            /* Put buffer into file */
            if ((num = fputs(line, sysut2)) == EOF) {
                printf("fputs failed");
            }
        }
        fclose(sysut2);
        sysut2 = NULL;
        fclose(sysut1);
        sysut1 = NULL;
    }
    if (sysut1) {
        fclose(sysut1);
    }
    if (sysut2) {
        fclose(sysut2);
    }
    return 0;
}
