/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/

#include <stdio.h>
#include <errno.h>
#include <time.h>
#include <unistd.h>
#include <iconv.h>
#include <string>

#pragma runopts(posix(on))
using namespace std;

#ifndef _LARGE_TIME_API
#define _LARGE_TIME_API
#endif

#ifndef NULL
#define NULL 0
#endif // NULL
#define RIT_COMMAND_MAX_SIZE  32
#define RIT_COM_RESP_TOKEN_SIZE 8

int convert(const char* fromCode, const char* toCode, const char* from,
        size_t inlen, char** to, size_t* outlen) {
    iconv_t cd; /* conversion descriptor          */
    size_t inleft; /* number of bytes left in inbuf  */
    int rc; /* return code of iconv()         */
    if ((cd = iconv_open(toCode, fromCode)) == (iconv_t)(-1)) {
        return (-1001);
    }
    inleft = inlen;
    *outlen = inlen + 60;
    char* inptr = (char*) from;

    *to = new char[*outlen];
    if (*to != 0) {
        memset(*to, 0, *outlen);
    } else {
        *to = 0;
        return (-1003);
    }
    char* outptr = (char*) *to;
    rc = iconv(cd, &inptr, &inleft, &outptr, outlen);
    if (rc == -1) {
        delete (*to);
        *to = 0;
        return (-1002);
    }
    iconv_close(cd);
    (*to)[inlen] = 0;
    return 0;
}

int asc2ebc(const char* from, size_t inlen, char** to, size_t* outlen) {
    const char* fromCode = "ISO8859-1";
    const char* toCode = "IBM-1047";
    return convert(fromCode, toCode, from, inlen, to, outlen);
}

int asc2ebc(const char* inStr, string& out) {
    char* from = (char*) inStr;
    size_t inlen = strlen(inStr);
    char* to = 0;
    size_t outlen = 0;
    int rc = asc2ebc(from, inlen, &to, &outlen);
    if (rc == 0) {
        out.clear();
        out.append(to);
    }
    delete (to);
    return rc;
}

const char * fileName1 = "DD:RITLOG01";
const char * fileName2 = "DD:RITLOG02";
const char * fileName3 = "DD:RITLOG03";
int main() {
    int rc = 0;
    string ebcName1, ebcName2, ebcName3;
    asc2ebc(fileName1, ebcName1);
    asc2ebc(fileName2, ebcName2);
    asc2ebc(fileName3, ebcName3);
    FILE *stream1, *stream2, *stream3;

    FILE *f;
    //f = fopen(ebcName1.c_str(), "at+, lrecl=256, blksize=6144, recfm=VB");
    f = fopen(fileName1, "at+, lrecl=256, blksize=6144, recfm=VB");
    if (f == NULL) {
        perror("fopen() failed");
        printf("__errno2 = %08x fileName=%s line=%d\n",
                __errno2(), ebcName1.c_str(), __LINE__);
    } else {
        rc = fputs(
                "IN 1st open with \"at+, lrecl=256, blksize=6144, recfm=VB\"",
                f);
        if (rc != EOF) {
            printf("write %d bytes by fputs; LINE=%d\n", rc, __LINE__);
        } else {
            printf("fputs failed with errno=%d, errno2=%08x, line=%d\n",
                    errno,
                    __errno2(), __LINE__);

        }
        fclose(f);
    }
    /* reset errno2 to zero */
    *__err2ad() = 0x0;
    printf("__errno2 = %08x, LINE=%d\n", __errno2(), __LINE__);

    f = fopen("//'HANHL.RIT.CICS.V860.RITLOG02'",
            "wt+, lrecl=256, blksize=6144, recfm=VB");
    if (f == NULL) {
        perror("fopen() failed");
    printf("__errno2 = %08x fileName=HANHL.RIT.CICS.V860.RITLOG02, line=%d\n",
                __errno2(), __LINE__);
    } else {
        rc = fputs(
                "IN 2nd open with \"wt+, lrecl=256, blksize=6144, recfm=VB\"",
                f);
        if (rc != EOF) {
            printf("write %d bytes by fputs, line=%d\n", rc, __LINE__);
        } else {
            printf("fputs failed with errno=%d, errno2=%08x\n, line=%d",
                    errno,
                    __errno2(), __LINE__);

        }
        fclose(f);
    }

    //stream3 = fopen(ebcName3.c_str(), "at+, lrecl=256, blksize=6144, recfm=VB");
    stream3 = fopen(fileName3, "at+, lrecl=256, blksize=6144, recfm=VB");

    if (stream3 == NULL) {
        fprintf(stdout,
"Could not open log file DD:RITLOG03 for appending. Errno=%d, line=%d\n",
                errno, __LINE__);

        stream3 = fopen(ebcName3.c_str(),
                "w+, lrecl=256, blksize=6144, recfm=VB");
        if (stream3 == NULL) {
            fprintf(stdout,
        "Could not open log file DD:RITLOG01 for w+. Errno=%d, line=%d\n",
                    errno, __LINE__);
        }
    }
    if (stream3 != NULL) {
        time64_t ltime;
        time64(&ltime);
        char buffer[128] = { 0 };
        sprintf(buffer, "--->>>--HRVCCICS--<<<---created log at %s\n",
                ctime64(&ltime));
        string ebcLog;
        asc2ebc(buffer, ebcLog);
        rc = fputs(ebcLog.c_str(), stream3);
        if (rc != EOF) {
            printf("write %d bytes by fputs, line=%d\n",
                    rc, __LINE__);
        } else {
            printf("fputs failed with errno=%d, errno2=%08x, line=%d\n",
                    errno,
                    __errno2(), __LINE__);

        }
        fclose(stream3);
    }

    return 0;
}
