/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*********************************************************************
 * perfrm03.c
 *********************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>

/* #define DEBUG_PERFRM03 */

#ifndef _LARGE_TIME_API
#define _LARGE_TIME_API
#endif

#define  RIT_PROGRAM_FILTER_LEN    9
#define  RIT_MAX_FILTER_NUMBER     56
#define  RIT_PGM_FILTER_LENGTH     (9*56)
#define RIT_CICS_TDQ    "RITL"

const char queue[] = {RIT_CICS_TDQ};

/* Commarea Map         */
typedef struct TESTCOMM{
   char  progname[9];        /* PIC A(8).            */
   char  sysid[5];           /*  PIC A(6).           */
   int   request;            /* PIC 9(9).            */
   int   answer;             /* PIC 9(18).           */
   char  time01[8];
   char  time02[8];
   int   eclapsedTime;       /* PIC S9(15).          */
   char  COMMENT[256];       /*    PIC A(256).       */
} TestComm;
/*
 * Main transaction program
 */
void main() {
    TestComm* pCommarea = 0;
    time64_t ltime1, ltime2;
    time64(&ltime1);

    char msg80[80] = "";
    short int leng = 80; /* Length for messages         */
    /* Get the EIB address */
    EXEC CICS
    ADDRESS EIB( dfheiptr);

    EXEC CICS
    ADDRESS COMMAREA( pCommarea );

    if (dfheiptr->eibresp != DFHRESP(NORMAL)) {
        sprintf(msg80,
        "In Perfrm03: ADDRESS COMMAREA error, resp1=%d,resp2=%d\n",
            dfheiptr->eibresp, dfheiptr->eibresp2);
        EXEC CICS
        WRITEQ TD
        QUEUE (queue)
        FROM (msg80)
        LENGTH(leng);
    }

    EXEC CICS ASKTIME ABSTIME(pCommarea->time01);

    int iLength = sizeof(TestComm);
   strcpy("REQUEST", pCommarea->COMMENT);
   strcpy("LTOR", pCommarea->sysid);
   strcpy("PERFRM01", pCommarea->progname);

    EXEC CICS
    LINK
    PROGRAM("PERFRM04")
    COMMAREA (pCommarea)
    LENGTH(iLength)
    DATALENGTH(iLength);

    if (dfheiptr->eibresp != DFHRESP(NORMAL)) {
        sprintf(msg80, "Link to PERFRM04 error, resp1=%d,resp2=%d\n",
            dfheiptr->eibresp, dfheiptr->eibresp2);
        EXEC CICS
        WRITEQ TD
        QUEUE (queue)
        FROM (msg80)
        LENGTH(leng) ;
    }
#ifdef DEBUG_PERFRM03
    else{
        sprintf(msg80, "In Perfrm03: answer = %d\n",
                pCommarea->answer);
        EXEC CICS
        WRITEQ TD
        QUEUE (queue)
        FROM (msg80)
        LENGTH(leng);
    }
#endif

    EXEC CICS ASKTIME ABSTIME(pCommarea->time02);
    time(&ltime2);
    pCommarea->eclapsedTime = ltime2 - ltime1;
    EXEC CICS RETURN;
}
