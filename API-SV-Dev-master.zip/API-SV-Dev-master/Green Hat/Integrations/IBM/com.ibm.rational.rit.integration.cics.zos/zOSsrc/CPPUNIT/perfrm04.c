/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*********************************************************************
 * perfrm04.c
 *********************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

/* #define DEBUG_PERFRM04 */

#define RIT_CICS_TDQ    "RITL"

const char queue[] = {RIT_CICS_TDQ};

/* Commarea Map         */

typedef struct TESTCOMM{
   char  progname[9];        /* PIC A(8).            */
   char  sysid[5];           /*  PIC A(6).           */
   int   request;            /* PIC 9(9).            */
   int   answer;             /* PIC 9(18).           */
   char  time01[8];
   char  time02[8];
   int   eclapsedTime;       /* PIC S9(15).          */
   char  COMMENT[256];       /*    PIC A(256).       */
} TestComm;

/*
 * Main transaction program
 */
void main() {
    TestComm* pCommarea = 0;
    char msg80[80] = "";
    short int leng = 80; /* Length for messages         */
    /* Get the EIB address */
    EXEC CICS
    ADDRESS EIB( dfheiptr);

    EXEC CICS
    ADDRESS COMMAREA( pCommarea );

    if (dfheiptr->eibresp != DFHRESP(NORMAL)) {
        sprintf(msg80,
        "In Perfrm04: ADDRESS COMMAREA error, resp1=%d,resp2=%d\n",
            dfheiptr->eibresp, dfheiptr->eibresp2);
        EXEC CICS
        WRITEQ TD
        QUEUE (queue)
        FROM (msg80)
        LENGTH(leng);
    }
#ifdef DEBUG_PERFRM04
    else{
        sprintf(msg80, "In Perfrm04: request = %d\n",
                pCommarea->request);
        EXEC CICS
        WRITEQ TD
        QUEUE (queue)
        FROM (msg80)
        LENGTH(leng);
    }
#endif
    pCommarea->answer = pCommarea->request * pCommarea->request;
    strcpy("Answer", pCommarea->COMMENT);
    strcpy("RTOL", pCommarea->sysid);
    strcpy("PERFRM02", pCommarea->progname);

    EXEC CICS RETURN;
}
