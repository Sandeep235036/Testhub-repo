/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2019. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*********************************************************************
 * cfgpoll.cpp
 * Implementation of Class ConfigPoller
 ********************************************************************/
#pragma csect (CODE,"HRVCCFPL")
#include "cfgpoll.h"
#include "svrpoll.h"
#include "objxfer.h"
#include "cndtion.h"
#include "record.h"
#include "stubclt.h"
#include "ritutil.h"
#include "ritlog.h"
#include "servlog.h"
#include "observ.h"
#include "rtcpset.h"
 
#include <vector>
#include <string>
#include <pthread.h>
#include <signal.h>
#include <dll.h>
 
//#define DEBUG_CFGPOLL 1
//#define DEBUG_CFGPOLL_PASS_TO_CICS 1
 
#define SPACE9   "         "//$NON-NLS-1$
 
#define CONFIGURATION_PATH     "rest/proxy/config/" //$NON-NLS-1$
#define CONFIGURATION_PATH_TH  "rest/spaces/Initial/virtualization/config/"
static const char* DEFAULT_NO_FILTER = "*       *   ";
 
using namespace std;
using namespace greenhat::vie::comms::proxy;
using namespace google::protobuf;
 
static void*
cfgPoller(void * poller) {
    ConfigPoller* pPoller = (ConfigPoller*) poller;
    Logger* log = pPoller->logger();
    ServerLogger* svrlog = pPoller->svrlogger();
    CICSRegistration* pReg = pPoller->registration();
    //CHANGE
    string baseurl;
    if (!rtcp_server) {
      baseurl = pReg->serverUrl() + CONFIGURATION_PATH_TH;
      sleep(3); // sleep 3 second to avoid run same time with regpoller
    }
    else {
      baseurl = pReg->serverUrl() + CONFIGURATION_PATH;
      sleep(1); // sleep 1 second to avoid run same time with regpoller
    }
 
    std::string asciiUrl;
    ebc2asc(baseurl.c_str(), asciiUrl);
 
    ObjXfer pXfer(baseurl,pReg->gsk_keyring_ring());
 
    int count = 0;
    int errCntRTCP = 0;
    int errCntExci = 0;
    int maxRTCPErr = pReg->rtcpMaxErrnum();
    log->info("Using RTCP maximum error count: %d.",
              maxRTCPErr);
    int maxEXCIErr = pReg->exciMaxErrnum();
    log->info("Using EXCI maximum error count: %d.",
              maxEXCIErr);
 
    pthread_t thid = pthread_self();
    FPRINTF(stdout, "ConfigPoller thread id is %X.\n", thid);
    log->info("ConfigPoller thread id is %X.", thid);//$NON-NLS-1$
 
  //string uuid;
    std::string uuid;
    while (pPoller->getStop() == 0) {
        //CHANGE
        uuid = pReg->uuid();
        if (uuid.length() == UUID_LENGTH) {
        // uuid length correct, then try to poll the configuration
            std::string url = std::string(asciiUrl) + uuid;
         // std::string url = std::string(asciiUrl);
        //  string url = baseurl + uuid;
            Configuration* pCfg = (Configuration*) pXfer.getObj(url, log);
            if (NULL != pCfg) {// Got conf.
                errCntRTCP = 0;  // reset errCntRTCP
                pPoller->setConfig(pCfg);
                if (pPoller->onReceived() != 0) { // update conf. to exit
                    FPRINTF(stdout, "Error passing filter rules to CICS.\n"); //$NON-NLS-1$
                    log->warn("Pass filter rules to CICS exit error."); //$NON-NLS-1$
                    svrlog->warn("Pass filter rules to CICS exit error.");
                    errCntExci++;
                } else { // reset errCntExci
                    if (errCntExci>0) {
                        // if this is the first successful connection to
                        // CICS after a previous connection failure, need to
                        // re-enable the exit and send the filter list to CICS again.
                        FPRINTF(stdout, "Connection to CICS reestablished. Reenabling exit\n"); //$NON-NLS-1$
                        log->info("Connection to CICS reestablished. Reenabling exit"); //$NON-NLS-1$
                        enableRit(pReg, log, RIT_ENABLE_CMD);
                        // To trigger resending the filter list to CICS, clear the
                        // ConfigPoller's copy of the filter list.
                        pPoller->clearFilterList(pCfg);
                    }
                    errCntExci = 0;
                }
#ifdef DEBUG_CFGPOLL
                FPRINTF(stdout,
                        "Got configuration for Agent ID: %s\n", //$NON-NLS-1$
                        uuid.c_str());
#endif // DEBUG_CFGPOLL
            } else { // got NULL from getObj
                string urle,uuide;
                asc2ebc(url, urle);
                asc2ebc(uuid, uuide);
                log->warn("Received null proxy Configuration," //$NON-NLS-1$
                        " URL=%s, baseURL=%s, UUID=%s", //$NON-NLS-1$
                        urle.c_str(), baseurl.c_str(), uuide.c_str());
                //      url.c_str(), baseurl.c_str(), uuid.c_str());
                char msg[256] = {0};
                sprintf(msg, "Received null proxy Configuration," //$NON-NLS-1$
                        " URL=%s, baseURL=%s, UUID=%s", //$NON-NLS-1$
                        urle.c_str(), baseurl.c_str(), uuide.c_str());
                //      url.c_str(), baseurl.c_str(), uuid.c_str());
                svrlog->warn(msg);
                errCntRTCP++;
                pReg->setId("");
            }
        }else{ //UUID_LENGTH error, indicate RegPoller did not update uuid
            errCntRTCP++;
        }
        if (errCntRTCP > maxRTCPErr) {
            log->error("Communication with RTCP failed." //$NON-NLS-1$
                            " RITCICS will exit now...");//$NON-NLS-1$
            log->debug("Raise SIGUSR2.");//$NON-NLS-1$
            raise(SIGUSR2);
        }
        if (errCntExci > maxEXCIErr) {
            log->error("Communication with CICS region failed." //$NON-NLS-1$
                            " RITCICS will exit now...");//$NON-NLS-1$
            log->debug("Raise SIGUSR2.");//$NON-NLS-1$
            raise(SIGUSR2);
        }
        sleep(ConfigPoller::DEFAULT_CONFIGURATION_POLL_INTERVAL);
    } // end while()
    pPoller->stop(2);
    pthread_exit(NULL);
    return NULL;
}
 
ConfigPoller* ConfigPoller::s_instance = NULL;
 
ConfigPoller* ConfigPoller::instance(CICSRegistration* reg) {
    if (s_instance == NULL) {
        s_instance = new ConfigPoller(reg);
    }
    return s_instance;
}
 
ConfigPoller::ConfigPoller(CICSRegistration* reg)
:pReg_(reg),
 stop_(0),
 logLevelupdate_(0),
 updated_(0),
 cfg_(NULL)
{
    log_ = LoggerFactory::getInstance()->getLogger("ConfigPoller"); //$NON-NLS-1$
    serverLogger_ = ServerLogger::instance(reg);
 
    int rc = pthread_rwlockattr_init(&rwlattr_);
    if (rc == -1) {
        log_->error("error in pthread_rwlockattr_init"); //$NON-NLS-1$
        FPRINTF(stdout, "pthread_rwlockattr_init error, errno=%d. Exiting...\n", //$NON-NLS-1$
                errno);
        raise(SIGUSR1);
    }
    rc = pthread_rwlockattr_setpshared(&rwlattr_, PTHREAD_PROCESS_PRIVATE);
    if (rc == -1) {
        log_->error("error in pthread_rwlockattr_setpshared"); //$NON-NLS-1$
        FPRINTF(stdout,
                "pthread_rwlockattr_setpshared error, errno=%d. Exiting...\n", //$NON-NLS-1$
                errno);
        raise (SIGUSR1);
    }
    rc = pthread_rwlock_init(&statuslock_, &rwlattr_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_init"); //$NON-NLS-1$
        FPRINTF(stdout, "pthread_rwlock_init error, errno=%d. Exiting...\n", //$NON-NLS-1$
                errno);
        raise (SIGUSR1);
    }
}
 
ConfigPoller::~ConfigPoller() {
    int i = getWaitTimeout();
    while (getStop() != 2 && i > 0) {
        stop(1);
        i--;
        sleep(1);
    }
    if (pthread_rwlock_destroy(&statuslock_) == -1) {
        log_->error("error in pthread_rwlock_destroy loglvllock"); //$NON-NLS-1$
    }
    if (pthread_rwlockattr_destroy(&rwlattr_) == -1) {
        log_->error("error in pthread_rwlockattr_destroy"); //$NON-NLS-1$
    }
    DELETE(cfg_);
}
 
void ConfigPoller::start(pthread_attr_t* attr) {
    if (pthread_create(&thread_, attr, cfgPoller, (void*) this) != 0) {
        log_->error("pthread_create() error, errno=%d\n", errno); //$NON-NLS-1$
    }
}
 
void ConfigPoller::stop(int status) {
    int rc = pthread_rwlock_wrlock(&statuslock_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_wrlock"); //$NON-NLS-1$
    }
    stop_ = status;
    rc = pthread_rwlock_unlock(&statuslock_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_unlock"); //$NON-NLS-1$
    }
    log_->info("ConfigPoller stopping ...\n"); //$NON-NLS-1$
}
 
int ConfigPoller::getStop() {
    int rc = pthread_rwlock_rdlock(&statuslock_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_rdlock"); //$NON-NLS-1$
    }
    int status = stop_;
    rc = pthread_rwlock_unlock(&statuslock_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_unlock"); //$NON-NLS-1$
    }
    return status;
}
 
int ConfigPoller::onReceived() {
    pReg_->setObservLevel((RIT_OBSERV_LEVEL) cfg_->observationlevel());
 
    if (cfg_->has_lastloglevelupdate()) {
        int64 logLevelUpdated = cfg_->lastloglevelupdate();
 
        if (logLevelupdate_ < logLevelUpdated) {
            logLevelupdate_ = logLevelUpdated;
            if (cfg_->has_loglevel()) {
                serverLogger_->setLevel(cfg_->loglevel());
            }
        }
    }else if (cfg_->has_loglevel()) {
        serverLogger_->setLevel(cfg_->loglevel());
    }
 
    if (cfg_->has_lastupdated()) {
        int64 updated = cfg_->lastupdated();
 
        if (updated > updated_) {
            updated_ = updated;
        }
    }
    return (cfgChanged());
}
 
int ConfigPoller::cfgChanged() {
    bool plChanged = false;
    vector < string > filterList;
 
    if (stop_ == 1) {
        return 0;
    }
 
    Recorder* recorder = Recorder::instance(pReg_);
    StubClient* stubClient = StubClient::instance(pReg_);
 
    recorder->configureRecording(cfg_);
    stubClient->configureStubbing(cfg_);
 
    // put stub rules first to keep it as the higher priority
    const vector<string> & filtersStub = stubClient->getFilterList();
    if(filtersStub.size()){
        vector<string>::const_iterator its = filtersStub.begin();
        for (; its != filtersStub.end(); its++) {
            filterList.push_back(*its);
        }
    }
    const vector<string> & filtersRec = recorder->getFilterList();
    if(filtersRec.size()){
        vector<string>::const_iterator itr = filtersRec.begin();
 
        // put record rules 1st to keep it as the lower priority
        for (; itr != filtersRec.end(); itr++) {
            filterList.push_back(*itr);
        }
    }
 
    if (filterList_.size() != filterList.size()) {
        plChanged = true;
    } else if (filterList_.size() != 0) {
        vector<string>::iterator it = filterList.begin();
        vector<string>::iterator ito = filterList_.begin();
        for (; it != filterList.end(); it++, ito++) {
            string str1 = *it;
            string str2 = *ito;
            if (str1.compare(str2)) {
                plChanged = true;
                break;
            }
        }
    }
 
    if (plChanged || updated_ == 0) {
        filterList_.clear();
        vector<string>::iterator it = filterList.begin();
        for (; it != filterList.end(); it++) {
            filterList_.push_back(*it);
        }
        if(filterList_.empty()){
            filterList_.push_back(DEFAULT_NO_FILTER);
        }
        // call the pass fitler vector to exit
        // in order to keep consistent
        return passFilterListToExit(filterList);
    }
 
    // call the heartbtc function
    // in order to get CICS status
 
  //string applid;
  //int rc = asc2ebc(pReg_->applid(), applid);
    string applid ;
    applid = pReg_->applid();
    int rc ;
  /*if (rc != 0) {
        log_->error("asc2ebc for applid error, rc=%d", rc);    //$NON-NLS-1$
    } */
 
    COMMSTATUS commArea;
    memset(&commArea, 0, sizeof(commArea));
 
#ifdef DEBUG_CFGPOLL_HEARTBEAT
    FPRINTF(stdout, "@@@ Before call heartbtc in DLL @@@\n");    //$NON-NLS-1$
#endif
    rc = heartbtc(&commArea, applid.c_str());
    if (rc != 0) {
        log_->error("HeartBeat call failed. Return codes is: %d\n", rc); //$NON-NLS-1$
        char msg[80] = {0};
        sprintf(msg, "HeartBeat call failed. Return codes is: %d\n", rc);
        serverLogger_->error(msg);
    }
#ifdef DEBUG_CFGPOLL_HEARTBEAT
    FPRINTF(stdout, "Return code of HeartBeat() is %d\n", rc);    //$NON-NLS-1$
    FPRINTF(stdout, "@@@ After call HeartBeat in DLL @@@\n");//$NON-NLS-1$
#endif
    return rc;
}
 
int ConfigPoller::passFilterListToExit(const vector<string>& filterList) {
#ifdef DEBUG_CFGPOLL_PASS_TO_CICS
    FPRINTF(stdout, "Entering ConfigPoller::passFilterListToExit:\n"); //$NON-NLS-1$
#endif
    vector<string>::const_iterator it = filterList.begin();
    char buffer[RIT_MAX_FILTER_LEN + 1] = { 0 };
    char* ptr = buffer;
    for (; it != filterList.end(); it++) {
        strncpy(ptr, (*it).c_str(), RIT_DPL_FILTER_LEN);
        ptr += RIT_DPL_FILTER_LEN;
    }
    buffer[RIT_DPL_FILTER_LEN * filterList.size()] = 0;
    string ctsFilter;
    ctsFilter = buffer;
    int rc;
  /*int rc = asc2ebc(buffer, ctsFilter);
    if (rc != 0) {
        log_->error("asc2ebc for filters error, rc=%d", rc);    //$NON-NLS-1$
    } */
    string applid;
    applid = pReg_->applid();
  /*rc = asc2ebc(pReg_->applid(), applid);
    if (rc != 0) {
        log_->error("asc2ebc for applid error, rc=%d", rc);    //$NON-NLS-1$
    } */
 
    EXCICOMMAREA commArea;
 // memset(&commArea, sizeof(commArea), 0);
    memset(&commArea,0,sizeof(commArea));
    commArea.ruleNum = filterList.size();
    commArea.ruleNum =
            commArea.ruleNum > RIT_MAX_FILTER_NUM ?
            RIT_MAX_FILTER_NUM : commArea.ruleNum;
    memcpy(commArea.filters, ctsFilter.c_str(),
            commArea.ruleNum * RIT_DPL_FILTER_LEN);
 
#ifdef DEBUG_CFGPOLL_PASS_TO_CICS
    FPRINTF(stdout, "@@@ Before call execcall in DLL @@@\n");    //$NON-NLS-1$
    FPRINTF(stdout, "DPL_Filter='%s'\n", buffer);
#endif
    rc = execcall(&commArea, applid.c_str());
    if (rc != 0) {
        log_->error("EXCI call failed. Return codes is: %d\n", rc); //$NON-NLS-1$
        char msg[80] = {0};
        sprintf(msg, "EXCI call failed. Return codes is: %d\n", rc);
        serverLogger_->error(msg);
    } else {
        log_->debug("EXCI call succeed. Filters=%s", buffer);
        if (updated_ == 0) {
            updated_ = 1;
        }
    }
#ifdef DEBUG_CFGPOLL_PASS_TO_CICS
    FPRINTF(stdout, "Return code of execcall() is %d\n", rc);    //$NON-NLS-1$
    FPRINTF(stdout, "@@@ After call execcall in DLL @@@\n");//$NON-NLS-1$
#endif
    return rc;
}
