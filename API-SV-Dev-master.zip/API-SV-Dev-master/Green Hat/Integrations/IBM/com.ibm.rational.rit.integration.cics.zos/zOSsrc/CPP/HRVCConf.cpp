/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017.All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*
 * HRVCConf.cpp
 *
 *  Created on: May 19, 2016
 *      Author: ibmadmin
 */

#include "HRVCConf.h"

HRVCConf::HRVCConf() {
    // TODO Auto-generated constructor stub

}

HRVCConf* HRVCConf::getInstance() {
    if(!s_instance){
        s_instance = new HRVCConf();
    }
    return s_instance;
}

HRVCConf::~HRVCConf() {
    // TODO Auto-generated destructor stub
}

