/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017.?All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*******************************************************************************
 * stubclt.cpp
 ******************************************************************************/
#pragma csect (CODE,"HRVCSCTL")
#define OPEN_DEFAULT 1
#define OPEN_SYS_EXT 1
#define _LARGE_TIME_API 1
#define _OPEN_THREADS 3
#define  _XOPEN_SOURCE 600
#define _OPEN_SYS 1
#define _ISOC99_SROURCE 1
#define _XOPEN_SOURCE_EXTENDED 1
#define _POSIX_SOURCE 1
#define _POSIX_C_SOURCE 200112L
#define _OPEN_SYS_MUTEX_EXT 1
#define _OPEN_SYS_ITOA_EXT 1
#include "stubclt.h"
#include "cndtion.h"
#include "ritcomm.h"
#include "ritlog.h"
#include "servlog.h"
#include "observ.h"
#include <curl/curl.h>
 
#include <set>
#include <string>
#include <pthread.h>
//CHANGE
#include "rtcpset.h"
#include <fstream>
 
//#define STUBCLT_DEBUG 1
//#define STUBCLT_DEBUG_HANDLER 1
 
#define STUBCLT_ERROR 1300
 
using namespace ::std;
using namespace ::google::protobuf;
 
const char* PASS_THROUGH_VAL_PASSTHROUGH = "PassThrough"; //$NON-NLS-1$
const char* PASS_THROUGH_VAL_ERROR = "Error"; //$NON-NLS-1$
const char* HTTP_HEADER_ACTION_VAL_INTERCEPT = "Intercept"; //$NON-NLS-1$
 
StubClient* StubClient::s_instance = 0;
 
StubClient* StubClient::instance(CICSRegistration* reg) {
    if (s_instance == 0) {
        s_instance = new StubClient(reg);
    }
    return s_instance;
}
 
static void* stub_post_event(void * arg){
    Logger* log = LoggerFactory::getInstance()->getLogger("StubClient");//$NON-NLS-1$
    ServerLogger* serverLogger = ServerLogger::instance(
            CICSRegistration::getInstance());
    CURL *curl = curl_easy_init();
    bool* status = new bool;
    Posted_Event* pe = (Posted_Event*) arg;
 
    struct ObjectToSend objSend;
    struct ObjectReceived objRecv;
    struct ObjectReceived http_resp_header;
 
  //objSend.sizeleft = (long) pe->event_->ByteSize();
    objSend.sizeleft = (long) pe->event_->ByteSizeLong();
    objSend.readptr = (char*) malloc(objSend.sizeleft);
    if (objSend.readptr == NULL) {
        FPRINTF(stdout, "malloc error, errno=%d. Exiting...\n", errno);//$NON-NLS-1$
        exit(MEMORY_ALLOC_FAILURE);
    }
    ::google::protobuf::uint8* output = (::google::protobuf::uint8*)objSend.readptr;
    pe->event_->SerializeWithCachedSizesToArray(output);
 
    string HTTP_CTYPE,RIT_AID,RIT_CID,RIT_HTIME;
    ebc2asc(RIT_HTTP_HEADER_CONTENT_TYPE,HTTP_CTYPE);
    ebc2asc(RIT_HTTP_HEADER_ACTIVITYID,RIT_AID);
    ebc2asc(RIT_HTTP_CorrelationID,RIT_CID);
    ebc2asc(RIT_HTTP_TIMESTAMP,RIT_HTIME);
    struct curl_slist *http_headers = NULL;
    char buffer[128] = "";
 // http_headers = curl_slist_append(http_headers,
 //         RIT_HTTP_HEADER_CONTENT_TYPE);
    http_headers = curl_slist_append(http_headers,
            HTTP_CTYPE.c_str());
  //snprintf(buffer, 127, "%s%s", RIT_HTTP_HEADER_ACTIVITYID,
  //        pe->act_.c_str());
    snprintf(buffer, 127, "%s%s", RIT_AID.c_str(),
            pe->act_.c_str());
    http_headers = curl_slist_append(http_headers, buffer);
  //snprintf(buffer, 127, "%s%s", RIT_HTTP_CorrelationID,
  //        pe->correl_.c_str());
    snprintf(buffer, 127, "%s%s",  RIT_CID.c_str(),
            pe->correl_.c_str());
    http_headers = curl_slist_append(http_headers, buffer);
 // time64_t ltime;
 // time64(&ltime);
    std::time_t ltime;
    ltime = std::time(nullptr);
  //snprintf(buffer, 127, "%s%d", RIT_HTTP_TIMESTAMP, ltime);
  //http_headers = curl_slist_append(http_headers, buffer);
    snprintf(buffer, 127, "%s%ld", RIT_HTIME.c_str(), ltime);
    http_headers = curl_slist_append(http_headers, buffer);
    // Clear out Expect field of http header
    string expect;
    //CHANGE
    string url;
    asc2ebc(pe->url_,url);
    log->error("stub_post_event url to post the stub: %s", url.c_str()) ; //$NON-NLS-1$
    ebc2asc("Expect:",expect);
    http_headers = curl_slist_append(http_headers, expect.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, http_headers);
    curl_easy_setopt(curl, CURLOPT_URL, pe->url_.c_str());
    // Now specify we want to POST data
    curl_easy_setopt(curl, CURLOPT_POST, 1L);
    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
    // we want to use our own read function
    curl_easy_setopt(curl, CURLOPT_READFUNCTION, stub_read);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, record_write);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &objRecv);
    // pointer to pass to our read function
    curl_easy_setopt(curl, CURLOPT_READDATA, &objSend);
    curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, header_write);
    curl_easy_setopt(curl, CURLOPT_WRITEHEADER, &http_resp_header);
    // consider CURLOPT_POSTFIELDSIZE_LARGE
    curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, objSend.sizeleft);
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, getConnTimeout());
//    curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, getLowSpeedTime());
//    curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, getLowSpeedLimit());
    // Perform the request, res will get the return code
    CURLcode res = curl_easy_perform(curl);
    // Check for errors
    string err;
    if (res != CURLE_OK) {
        asc2ebc(curl_easy_strerror(res),err);
        log->error("stub_post_event() failed: %s",//$NON-NLS-1$
            err.c_str());
    //  log->error("stub_post_event() failed: %s",//$NON-NLS-1$
    //      curl_easy_strerror(res));
        FPRINTF(stdout, "stub_post_event() failed: %s.\n",//$NON-NLS-1$
                curl_easy_strerror(res));
        curl_easy_cleanup(curl);
        map<string, string> contextMap;
        contextMap[ACTIVITY_ID_PROPERTY] = pe->act_;
        string msg("WARNING: IBM Rational Integration Tester has stopped listening on ");//$NON-NLS-1$
                msg += pe->url_;
        serverLogger->warn(msg, &contextMap);
        FPRINTF(stdout,"%s.\n", msg.c_str());//$NON-NLS-1$
        log->warn(
                "Stub invocation failed. No valid stub found."//$NON-NLS-1$
                "Invocation will pass to real gateway.\n");//$NON-NLS-1$
        // Stub doesn't seem to be running
        curl_easy_cleanup(curl);
        *status = false;
        return (void*)status;
    }
    long httpCode = 0;
    res = curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &httpCode);
    if (res != CURLE_OK) {
        asc2ebc(curl_easy_strerror(res),err);
 //     log->error(
 // "curl_easy_getinfo() failed: %s",curl_easy_strerror(res));//$NON-NLS-1$
        log->error(
    "curl_easy_getinfo() failed: %s",err.c_str());//$NON-NLS-1$
        curl_easy_cleanup(curl);
        *status = false;
        return (void*)status;
    }
    string passTrough,PASS_THROUGH;
    int rc = getHeaderField(http_resp_header,
        RIT_HTTP_HEADER_PASS_THROUGH, passTrough);
    if(rc == 0){
    //  if(passTrough.compare(RIT_PASS_THROUGH_VAL_PASSTHROUGH) == 0){
            *status = false;
            log->debug("Stub send response to passTrough\n");//$NON-NLS-1$
            curl_easy_cleanup(curl);
            return (void*)status;
    //  }
    }
 
    ::google::protobuf::io::CodedInputStream input((const uint8*)objRecv.ptr, (int)objRecv.len);
    delete pe->event_;
    pe->event_ = new RecordedEvent();
    *status = pe->event_->MergePartialFromCodedStream(&input);
    curl_easy_cleanup(curl);
    return (void*)status;
}
 
 
bool StubClient::post_event(Posted_Event* pe){
    CURL *curl = curl_easy_init();
    bool status = false; // passTrough
 
    struct ObjectToSend objSend;
    struct ObjectReceived objRecv;
    struct ObjectReceived http_resp_header;
 
    string HTTP_CTYPE,RIT_AID,RIT_CID,RIT_HTIME;
    ebc2asc(RIT_HTTP_HEADER_CONTENT_TYPE,HTTP_CTYPE);
    ebc2asc(RIT_HTTP_HEADER_ACTIVITYID,RIT_AID);
    ebc2asc(RIT_HTTP_CorrelationID,RIT_CID);
    ebc2asc(RIT_HTTP_TIMESTAMP,RIT_HTIME);
    objSend.sizeleft = (long) pe->event_->ByteSizeLong();
  //objSend.sizeleft = (long) pe->event_->ByteSize();
    objSend.readptr = (char*) malloc(objSend.sizeleft);
    if (objSend.readptr == NULL) {
        FPRINTF(stdout, "malloc error, errno=%d. Exiting...\n", errno);//$NON-NLS-1$
        exit(MEMORY_ALLOC_FAILURE);
    }
    ::google::protobuf::uint8* output = (::google::protobuf::uint8*)objSend.readptr;
    pe->event_->SerializeWithCachedSizesToArray(output);
 
    struct curl_slist *http_headers = NULL;
    char buffer[128] = "";
  //http_headers = curl_slist_append(http_headers,
  //        RIT_HTTP_HEADER_CONTENT_TYPE);
    http_headers = curl_slist_append(http_headers,
            HTTP_CTYPE.c_str());
  //snprintf(buffer, 127, "%s%s", RIT_HTTP_HEADER_ACTIVITYID,
  //        pe->act_.c_str());
    snprintf(buffer, 127, "%s%s", RIT_AID.c_str(),
            pe->act_.c_str());
    http_headers = curl_slist_append(http_headers, buffer);
  //snprintf(buffer, 127, "%s%s", RIT_HTTP_CorrelationID,
  //        pe->correl_.c_str());
    snprintf(buffer, 127, "%s%s", RIT_CID.c_str(),
            pe->correl_.c_str());
    http_headers = curl_slist_append(http_headers, buffer);
  //time64_t ltime;
  //time64(&ltime);
    std::time_t ltime;
    ltime = std::time(nullptr);
  //snprintf(buffer, 127, "%s%d", RIT_HTTP_TIMESTAMP, ltime);
    snprintf(buffer, 127, "%s%ld", RIT_HTIME.c_str(), ltime);
    http_headers = curl_slist_append(http_headers, buffer);
    // Clear out Expect field of http header
    string expect;
    ebc2asc("Expect:",expect);
    http_headers = curl_slist_append(http_headers, expect.c_str());
    //CHANGE
    string url;
    asc2ebc(pe->url_,url);
    log_->error("url to post the stub: %s", url.c_str()); //$NON-NLS-1$
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, http_headers);
    curl_easy_setopt(curl, CURLOPT_URL, pe->url_.c_str());
    // Now specify we want to POST data
    curl_easy_setopt(curl, CURLOPT_POST, 1L);
    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
    // we want to use our own read function
    curl_easy_setopt(curl, CURLOPT_READFUNCTION, stub_read);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, record_write);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &objRecv);
    // pointer to pass to our read function
    curl_easy_setopt(curl, CURLOPT_READDATA, &objSend);
    curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, header_write);
    curl_easy_setopt(curl, CURLOPT_WRITEHEADER, &http_resp_header);
    // consider CURLOPT_POSTFIELDSIZE_LARGE
    curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, objSend.sizeleft);
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, getConnTimeout());
    curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, getLowSpeedTime());
    curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, getLowSpeedLimit());
    // Perform the request, res will get the return code
    CURLcode res = curl_easy_perform(curl);
    // Check for errors
    string err;
    if (res != CURLE_OK) {
        asc2ebc(curl_easy_strerror(res),err);
        log_->error("curl_easy_perform() failed: %s",//$NON-NLS-1$
            err.c_str());
   //   log_->error("curl_easy_perform() failed: %s",//$NON-NLS-1$
   //       curl_easy_strerror(res));
        curl_easy_cleanup(curl);
        map<string, string> contextMap;
        contextMap[ACTIVITY_ID_PROPERTY] = pe->act_;
        string msg("IBM Rational Integration Tester has stopped listening on ");//$NON-NLS-1$
                msg += pe->url_;
        serverLogger_->warn(msg, &contextMap);
        log_->warn(
                "Stub invocation failed. No valid stub found."//$NON-NLS-1$
                "Invocation will pass to real gateway.\n");//$NON-NLS-1$
        // Stub doesn't seem to be running
        status = false;
        curl_easy_cleanup(curl);
        return status;
    }
    long httpCode = 0;
    res = curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &httpCode);
    if (res != CURLE_OK) {
        asc2ebc(curl_easy_strerror(res),err);
  //    log_->error(
  //"curl_easy_getinfo() failed: %s", curl_easy_strerror(res));//$NON-NLS-1$
        log_->error(
    "curl_easy_getinfo() failed: %s", err.c_str());//$NON-NLS-1$
        curl_easy_cleanup(curl);
        return false;
    }
    string passTrough,PASS_THROUGH;
    int rc = getHeaderField(http_resp_header,
        RIT_HTTP_HEADER_PASS_THROUGH, passTrough);
    if(rc == 0){
     // if(passTrough.compare(RIT_PASS_THROUGH_VAL_PASSTHROUGH) == 0){
            log_->debug("Stub send response to passTrough\n");//$NON-NLS-1$
            curl_easy_cleanup(curl);
            return false;
    //  }
    }
 
    ::google::protobuf::io::CodedInputStream input((const uint8*)objRecv.ptr, (int)objRecv.len);
 
    if(pReg_->isDebugStubCA()){
        log_->debug("Get protobuf-wired from RIT stub:");
        char* p = objRecv.ptr;
        char buff[241] = {0};
        for(int i = 0; i < objRecv.len; i += 120){
            int maxNum = objRecv.len - i;
            maxNum = maxNum > 120 ? 120 : maxNum;
            for(int j = 0; j < maxNum; j ++){
                sprintf(buff + 2 * j, "%2.2X", *(p + i + j));
            }
            log_->debug(buff);
        }
    }
    pe->event_->MergePartialFromCodedStream(&input);
    curl_easy_cleanup(curl);
    return true;
}
 
/*
 * parameter header: the comm-area header
 * parameter commArea: the buffer of comm-area
 * return value: true -- if we want bypass the
 *                false -- if not bypass
 */
bool StubClient::handleStub(struct ASCHeader& header, struct COMMAREA* pCommArea,
        CICSAgentCondition* ritStub) {
    Observation::instance(pReg_)->addRoutingCount();
 
    // Build the event to send
    string correlator = pReg_->uuid() + ":" +
            pReg_->getCorrelID(header.correl);
    RecordedEvent* event = new RecordedEvent();
    event->set_type(CTG);
    struct timeval64 ltimeval;
    int rc = gettimeofday64(&ltimeval, NULL);
    if(rc != 0){
        time64_t ltime;
        time64(&ltime);
        event->set_timestamp(ltime * 1000);
    }else{
        event->set_timestamp(ltimeval.tv_sec * 1000 +
                ltimeval.tv_usec / 1000);
    }
    CTGRecordedEvent* pCTG = event->mutable_ctgrecordedevent();
    if(header.reqresp == INT_BeforeLink){
        pCTG->set_type(CTGRecordedEvent_Type_REQUEST);
    }else{
        pCTG->set_type(CTGRecordedEvent_Type_RESPONSE);
    }
    pCTG->set_program(header.progName, strlen(header.progName));
    pCTG->set_tranname(header.tranID, strlen(header.tranID));
    char jobname[10] = {0};
    strncpy(jobname, header.jobName, 8);
    strcat(jobname, " ");
    pCTG->set_sysid(pReg_->sysid());
    pCTG->set_applid(pReg_->applid());
    pCTG->set_cicstype(CTGRecordedEvent_CICSType_TS);
 
    pCTG->set_commarealength(header.length);
    pCTG->set_payload((const void*)pCommArea->pCommarea, pCommArea->len);
    pCTG->set_payloadlength(pCommArea->len);
 
    Posted_Event postedEvents;
    int error = 0;
 
    postedEvents.url_ = ritStub->getUrl();
    postedEvents.act_ = ritStub->getActivityId();
    postedEvents.correl_ = correlator;
    postedEvents.event_ = event;
    int nice = 1;
    pthread_t worker;
    bool* status = NULL;
    do{
        /* reset errno2 and errno to zero */
        errno = 0;
        *__err2ad() = 0x0;
        error = pthread_create(&worker, NULL, stub_post_event, (void*)&postedEvents);
        if(error != 0){
            /* an error occurred during the pthread_create() */
            int errorNo = errno;
            int errorNo2 = __errno2();
            char strerrBuf[ERR_BUF_LEN] = {0};
            rc = strerror_r(errorNo, strerrBuf, ERR_BUF_LEN);
            if(rc != 0){
                FPRINTF(stdout, "strerror_r return %d\n", rc);
            }
            pthread_t thid = pthread_self();
            log_->error("pthread_create error, errno=%08x, __errno2 = %08x, %s in thread:%X\n",
                 errno, errorNo2, strerrBuf, thid);//$NON-NLS-1$
            if(pReg_->logLevel() < 2){
                FPRINTF(stdout,
                    "pthread_create error, errno=%08x, __errno2 = %08x, %s in thread:%X\n",
                     errno, errorNo2, strerrBuf, thid);//$NON-NLS-1$
            }
            if(errno == EAGAIN || errno == ENOMEM){
                sleep(nice);
                nice = nice * 2;
            }else{
                raise(SIGUSR1);
                sleep(10);
                break;
            }
        }else{
            nice = 1;
        }
    }while(error != 0);
 
    // now wait for worker thread to terminate
    error = pthread_join(worker, (void**)&status);
 
    bool bRes = *status;
    DELETE(status);
    string pgmname;
    asc2ebc(header.progName,pgmname);
    if(bRes == false){
     // log_->debug("Program %s passTrough in stub", header.progName);
        log_->debug("Program %s passTrough in stub", pgmname.c_str());
        //CHANGE
        if (!rtcp_server) {
          std::ofstream outfile("DD:SYSPRINT");
          if (outfile.is_open()) {
 
            if (transno <= 1) {
           outfile << "*********** Transaction Report ***********" << std::endl;
           outfile << "Tranno  ,Tranname, Response, Message " << std::endl;
            }
              string tranid;
              asc2ebc(header.tranID,tranid);
              // Added the passThrough message
              outfile << transno++ << "       ," << tranid        <<"    , Passthru" << ", " << "Program " << pgmname << " passTrough in stub"  << std::endl;
 
              outfile.close();
          }
          }
        delete postedEvents.event_;
        postedEvents.event_ = NULL;
        return bRes; // passTrough is true, return false
    }
    CTGRecordedEvent* pCTGBack = postedEvents.event_->mutable_ctgrecordedevent();
    if (pCTGBack->has_cicsabendcode()) {
        strncpy(header.abendCode, pCTGBack->cicsabendcode().c_str(), 5);
 
    //  log_->debug("Program %s got abend in stub", header.progName);
        log_->debug("Program %s got abend in stub", pgmname.c_str());
        delete postedEvents.event_;
        postedEvents.event_ = NULL;
        return bRes; // return true with abendcode
    } else {
        memset(header.abendCode, 0, 4);
    }
 
    int payloadLength = 0;
    if(pCTGBack->has_payloadlength()){
        payloadLength = pCTGBack->payloadlength();
    }
    if(pCTGBack->has_payload()){
        const string& payload = pCTGBack->payload();
        int strLen = payload.length();
 
        if(payloadLength < header.length){
            if(payloadLength > 0){
                header.dataLength = payloadLength;
            }else{
                header.dataLength = 0;
            }
        }else{
            header.dataLength = header.length;
            if(payloadLength > header.length){
                log_->warn("Stub received header length=%d, payload length=%d",//$NON-NLS-1$
                    header.length, payloadLength);
                map<string, string> contextMap;
                contextMap[ACTIVITY_ID_PROPERTY] = postedEvents.act_;
                string msg("CICS TS Agent recieved a stub response containing commarea data larger "//$NON-NLS-1$
                "than the request commarea length. Data will be truncated.");//$NON-NLS-1$
                serverLogger_->warn(msg, &contextMap);
            }
        }
        pCommArea->len = header.dataLength;
        char* pResponse = (char*)realloc(pCommArea->pCommarea, pCommArea->len);
        if(pResponse == NULL){
            log_->error("Stub::handleStub realloc failed."//$NON-NLS-1$
             "File=%s,line=%d\n", __FILE__, __LINE__);//$NON-NLS-1$
        }
        pCommArea->pCommarea = pResponse;
        memcpy((void*)pCommArea->pCommarea, (const void*)payload.c_str(),
                pCommArea->len);
 
        asc2ebc(header.progName,pgmname);
     // log_->debug("StubClient::handleStub: program %s return comarea length %d.",
     //         header.progName, pCommArea->len);
        log_->debug("StubClient::handleStub: program %s return comarea length %d.",
                pgmname.c_str(), pCommArea->len);
        if (!rtcp_server) {
          std::ofstream outfile("DD:SYSPRINT");
          if (outfile.is_open()) {
 
            if (transno <= 1) {
           outfile << "*********** Transaction Report ***********" << std::endl;
           outfile << "Tranno  ,Tranname, Response, Message " << std::endl;
            }
              string tranid;
              asc2ebc(header.tranID,tranid);
              // Added the passThrough message
              outfile << transno++ << "       ," << tranid        <<"    , COM-AREA" << ", " << "TStubClient::handleStub: program "  << pgmname.c_str() << " return comarealength " << pCommArea->len << std::endl;
 
              outfile.close();
          }
          }
        if(pReg_->isDebugStubCA()){
            log_->debug("Get COM-AREA from RIT stub:");
            char* p = pCommArea->pCommarea;
            char buff[241] = {0};
            for(int i = 0; i < pCommArea->len; i += 120){
                int maxNum = pCommArea->len - i;
                maxNum = maxNum > 120 ? 120 : maxNum;
                for(int j = 0; j < maxNum; j ++){
                    sprintf(buff + 2 * j, "%2.2X", *(p + i + j));
                }
                log_->debug(buff);
            }
        }
    }else{
        log_->debug("StubClient::handleStub() pCTGBack has no payload.");
    }
    delete postedEvents.event_;
    postedEvents.event_ = NULL;
    return bRes;
}
 
CICSAgentCondition* StubClient::match(const AscHeader& header){
    if(clients_.size() < 1){
        return NULL;
    }
    vector<CICSAgentCondition*>::iterator it = clients_.begin();
  //for (!clients_.empty(); it != clients_.end(); it++) {
    for (auto it = clients_.begin(); it != clients_.end(); ++it){
       CICSAgentCondition* condition = *it;
       if(condition == NULL){
           continue;
       }
       if (condition->matches(header)) {
          return condition;
       } else {// if (condition->matches(header))
           string pgmname,tid;
           asc2ebc(header.progName,pgmname);
           asc2ebc(header.tranID,tid);
        // log_->debug("Current program: %s transaction name: %s doesn't match current filter: %s",//$NON-NLS-1$
        //     header.progName, header.tranID, condition->getFilter().at(0).c_str());
           log_->debug("Current program: %s transaction name: %s doesn't match current filter: %s",//$NON-NLS-1$
               pgmname.c_str(), tid.c_str(), condition->getFilter().at(0).c_str());
       }
    } // for
    return NULL;
}
 
StubClient::StubClient(CICSRegistration* reg)
:pReg_(reg)
{
    log_ = LoggerFactory::getInstance()->getLogger("StubClient");//$NON-NLS-1$
    serverLogger_ = ServerLogger::instance(reg);
    int rc = pthread_rwlockattr_init(&rwlattr_);
    if(rc == -1){
        log_->error("error in pthread_rwlockattr_init");//$NON-NLS-1$
        FPRINTF(stdout, "pthread_rwlockattr_init error, errno=%d. Exiting...\n", errno);//$NON-NLS-1$
        exit(STUBCLT_ERROR + 1);
    }
    rc = pthread_rwlockattr_setpshared(&rwlattr_, PTHREAD_PROCESS_PRIVATE);
    if(rc == -1){
        log_->error("error in pthread_rwlockattr_setpshared");//$NON-NLS-1$
        FPRINTF(stdout, "pthread_rwlockattr_setpshared error, errno=%d. Exiting...\n", errno);//$NON-NLS-1$
        exit(STUBCLT_ERROR + 2);
    }
    rc = pthread_rwlock_init(&rwlock_, &rwlattr_);
    if(rc == -1){
        log_->error("error in pthread_rwlock_init");//$NON-NLS-1$
        FPRINTF(stdout, "pthread_rwlock_init error, errno=%d. Exiting...\n", errno);//$NON-NLS-1$
        exit(STUBCLT_ERROR + 3);
    }
}
 
StubClient::~StubClient(){
    if (pthread_rwlock_destroy(&rwlock_) == -1) {
        log_->error("error in pthread_rwlock_destroy");//$NON-NLS-1$
    }
    if (pthread_rwlockattr_destroy(&rwlattr_) == -1) {
        log_->error("error in pthread_rwlockattr_destroy");//$NON-NLS-1$
    }
}
 
void StubClient::configureStubbing(Configuration* pCfg) {
    if(pCfg == NULL){
        return;
    }
    set < string > currentActivityIds;
    set < string > oldActivityIds;
 
    vector < string > stubURLs;
    vector<CICSAgentCondition*> newClients;
    vector<CICSAgentCondition*> ignoreList;
 
    const RepeatedPtrField<Rule>& stubClients = pCfg->stubs();
  //RepeatedPtrField<Rule>::iterator it = stubClients.begin();
  auto it = stubClients.begin();
    for (; stubClients.size() && it != stubClients.end(); it++) {
        const Rule& stub = *it;
        const RepeatedPtrField<Activity>& activities = stub.activities();
   //   RepeatedPtrField<Activity>::iterator ita = activities.begin();
        auto ita = activities.begin();
        for (; activities.size() && ita != activities.end(); ita++) {
            const Activity & activity = *ita;
            const RoutingActivity& routing = activity.routingactivity();
            const string& id = routing.id();
            const RepeatedPtrField<Address> & destinations =
                    routing.destinations();
        //  RepeatedPtrField<Address>::iterator itd = destinations.begin();
            auto itd = destinations.begin();
            for (;destinations.size() && itd != destinations.end(); itd++) {
                const Address & addr = *itd;
                const string & host = addr.host();
                int port = addr.port();
                char strport[8] = "";
                sprintf(strport, "%d", port);
                std::string asciiUrl,ebcurl,hostebc;
                asc2ebc(host,hostebc);
             // string url = "http://" + host + ":" + strport + "/";//$NON-NLS-1$
                string url = "http://" + hostebc + ":" + strport + "/";//$N ON-NLS-1$
                ebc2asc(url, asciiUrl);
 
             // CICSAgentCondition* condition = new CICSAgentCondition(url, id, true);
                CICSAgentCondition* condition = new CICSAgentCondition(asciiUrl, id, true);
                condition->setCondition(stub.condition());
                std::string urle;
                std::string applide;
                std::string syside;
                std::string jobnamee;
                std::string ide;
                std::string cics_typ;
                std::string applidr;
                std::string sysidr;
                std::string jobnamer;
                std::string idr;
                applide = condition->getAPPLID();
                syside = condition->getSYSID();
                jobnamee = condition->getJOBNAME();
                asc2ebc(url,urle);
                asc2ebc(id,ide);
                asc2ebc(id,idr);
                applidr = pReg_->applid().c_str();
                sysidr  = pReg_->sysid().c_str();
                jobnamer = pReg_->jobname().c_str();
                // ignore rules that don't apply
                // to this region
             /* if (condition->getAPPLID().length() > 0 && pReg_->applid().compare(condition->getAPPLID() )
                  || condition->getSYSID().length() > 0 && pReg_->sysid().compare(condition->getSYSID() )
                  || condition->getJOBNAME().length() > 0 && pReg_->jobname().compare(condition->getJOBNAME() )
                  || ( condition->isTS() == false ) )
                { */
                if (applide.length() > 0
                    && applidr.compare(applide)
                    || syside.length() > 0
                        && sysidr.compare(syside)
                    || jobnamee.length() > 0
                        && jobnamer.compare(jobnamee)
                    || (condition->isTS() == false)) {
                    ignoreList.push_back(condition);
                    log_->debug("Ignore router below:");//$NON-NLS-1$
                    log_->debug("RoutingActivity url is: %s",//$NON-NLS-1$
                            url.c_str());
                    log_->debug("RoutingActivity id is: %s",//$NON-NLS-1$
                            id.c_str());
                    log_->debug("Routing applid is:%s",//$NON-NLS-1$
                    //      condition->getAPPLID().c_str());
                            applide.c_str());
                    log_->debug("Routing sysid is:%s",//$NON-NLS-1$
                    //      condition->getSYSID().c_str());
                            syside.c_str());
                    log_->debug("Routing jobname is:%s",//$NON-NLS-1$
                    //  condition->getJOBNAME().c_str());
                        jobnamee.c_str());
                    log_->debug("Routing type is TS:%s",//$NON-NLS-1$
                        condition->isTS()?"true":"false");//$NON-NLS-1$
                    log_->debug("Routing fitler is:%s",//$NON-NLS-1$
                        condition->getFilter().at(0).c_str());//$NON-NLS-1$
                    continue;
                }
 
                currentActivityIds.insert(id);
                stubURLs.push_back(url);
                newClients.push_back(condition);
            }
        }
    }
 
    vector<CICSAgentCondition*> oldClients;
    int rc = pthread_rwlock_wrlock(&rwlock_);
    if(rc == -1){
        log_->error("error in pthread_rwlock_wrlock");//$NON-NLS-1$
    }
    oldClients.clear();
    if(clients_.size()){
        vector<CICSAgentCondition*>::iterator itclient = clients_.begin();
        for( ; itclient != clients_.end(); itclient++){
            oldClients.push_back(*itclient);
        }
    }
    clients_.clear();
    if(newClients.size()){
        vector<CICSAgentCondition*>::iterator itclient = newClients.begin();
        for( ; itclient != newClients.end(); itclient++){
            clients_.push_back(*itclient);
        }
    }
    rc =  pthread_rwlock_unlock(&rwlock_);
    if(rc == -1){
        log_->error("error in pthread_rwlock_unlock");//$NON-NLS-1$
    }
 
    if(!oldClients.empty()){
        vector<CICSAgentCondition*>::iterator itc = oldClients.begin();
        for (;oldClients.size() && itc != oldClients.end(); itc++) {
            CICSAgentCondition* oldCondition = *itc;
            oldActivityIds.insert(oldCondition->getActivityId());
        }
    }
 
    // Find which activities are really new and log them
    map < string, string > context;
    if(!currentActivityIds.empty()){
        set<string>::iterator ita = currentActivityIds.begin();
        for (; currentActivityIds.size() && ita != currentActivityIds.end(); ita++) {
            const string& activity = *ita;
            if (oldActivityIds.find(activity) == oldActivityIds.end()) {
                map<string, string> contextMap;
                contextMap[ACTIVITY_ID_PROPERTY] = activity;
                serverLogger_->info("CICS TS Agent started routing", &contextMap);//$NON-NLS-1$
            }
        }
    }
 
    // Find which activities have ended and log them
    if(!oldActivityIds.empty()){
        set<string>::iterator ito = oldActivityIds.begin();
        for (;oldActivityIds.size() && ito != oldActivityIds.end(); ito++) {
            const string & activity = *ito;
            if (currentActivityIds.find(activity) == currentActivityIds.end()) {
                map<string, string> contextMap;
                contextMap[ACTIVITY_ID_PROPERTY] = activity;
                serverLogger_->info("CICS TS Agent stopped routing", &contextMap);//$NON-NLS-1$
            }
        }
    }
 
    if(!ignoreList.empty()){
        vector<CICSAgentCondition*>::iterator itg = ignoreList.begin();
        for (;ignoreList.size() && itg != ignoreList.end(); itg++) {
            CICSAgentCondition* pCond = *itg;
            if(pCond){
                DELETE (pCond);
            }
        }
    }
    setFilterList();
}
 
bool StubClient::handleStub(struct ASCHeader& header,
        struct CONTAINER** pContainer, CICSAgentCondition* stubClient) {
    Observation::instance(pReg_)->addRoutingCount();
 
    // Build the event to send
    string correlator = pReg_->uuid() + ":" +
            pReg_->getCorrelID(header.correl);
    RecordedEvent* event=new RecordedEvent();
    event->set_type(CTG);
    struct timeval64 ltimeval;
    int rc = gettimeofday64(&ltimeval, NULL);
    if(rc != 0){
        time64_t ltime;
        time64(&ltime);
        event->set_timestamp(ltime * 1000);
    }else{
        event->set_timestamp(ltimeval.tv_sec * 1000 +
                ltimeval.tv_usec / 1000);
    }
    CTGRecordedEvent* pCTG = event->mutable_ctgrecordedevent();
    if(header.reqresp == INT_BeforeLink){
        pCTG->set_type(CTGRecordedEvent_Type_REQUEST);
    }else{
        pCTG->set_type(CTGRecordedEvent_Type_RESPONSE);
    }
    pCTG->set_program(header.progName, strlen(header.progName));
    pCTG->set_tranname(header.tranID, strlen(header.tranID));
    pCTG->set_jobname(header.jobName,strlen(header.jobName));
    pCTG->set_sysid(pReg_->sysid());
    pCTG->set_applid(pReg_->applid());
    pCTG->set_cicstype(CTGRecordedEvent_CICSType_TS);
 
    CTGRecordedEvent_Channel* channel = pCTG->mutable_channel();
    channel->set_name(header.channelName,strlen(header.channelName));
    for (const Container* ptr = *pContainer; ptr != NULL; ptr =
            ptr->next) {
        CTGRecordedEvent_Container* container =
                channel->add_containers();
        container->set_name(ptr->header.containerName,
                strlen(ptr->header.containerName));
        container->set_bitdata(ptr->dataarea, ptr->header.length);
    }
 
    Posted_Event postedEvents;
    int error = 0;
 
    postedEvents.url_ = stubClient->getUrl();
    postedEvents.act_ = stubClient->getActivityId();
    postedEvents.correl_ = correlator;
    postedEvents.event_ = event;
    int nice = 1;
    pthread_t worker;
    bool* status = NULL;
    do{
        /* reset errno2 and errno to zero */
        errno = 0;
        *__err2ad() = 0x0;
        error = pthread_create(&worker, NULL, stub_post_event, (void*)&postedEvents);
        if(error != 0){
            /* an error occurred during the pthread_create() */
            int errorNo = errno;
            int errorNo2 = __errno2();
            char strerrBuf[ERR_BUF_LEN] = {0};
            rc = strerror_r(errorNo, strerrBuf, ERR_BUF_LEN);
            if(rc != 0){
                FPRINTF(stdout, "strerror_r return %d\n", rc);
            }
            pthread_t thid = pthread_self();
            log_->error("pthread_create error, errno=%08x, __errno2 = %08x, %s in thread:%X\n",
                 errno, errorNo2, strerrBuf, thid);//$NON-NLS-1$
            if(pReg_->logLevel() < 2){
                FPRINTF(stdout,
                    "pthread_create error, errno=%08x, __errno2 = %08x, %s in thread:%X\n",
                     errno, errorNo2, strerrBuf, thid);//$NON-NLS-1$
            }
            if(errno == EAGAIN || errno == ENOMEM){
                sleep(nice);
                nice = nice * 2;
            }else{
                raise(SIGUSR1);
                sleep(10);
                break;
            }
        }else{
            nice = 1;
        }
    }while(error != 0);
 
    // now wait for worker thread to terminate
    error = pthread_join(worker, (void**)&status);
    string pgmname;
    asc2ebc(header.progName,pgmname);
    bool bRes = *status;
    DELETE(status);
    if(bRes == false){
      //log_->debug("Program %s passTrough in stub", header.progName);
        log_->debug("Program %s passTrough in stub", pgmname.c_str());
        if (!rtcp_server) {
          std::ofstream outfile("DD:SYSPRINT");
          if (outfile.is_open()) {
 
            if (transno <= 1) {
           outfile << "*********** Transaction Report ***********" << std::endl;
           outfile << "Tranno  ,Tranname, Response, Message " << std::endl;
            }
              string tranid;
              asc2ebc(header.tranID,tranid);
              // Added the passThrough message
              outfile << transno++ << "       ," << tranid        <<"    , Passthru" << ", " << "Program " << pgmname << " passTrough in stub"  << std::endl;
 
              outfile.close();
          }
          }
        delete postedEvents.event_;
        postedEvents.event_ = NULL;
        return bRes; // passTrough is true, return false
    }
    CTGRecordedEvent* pCTGBack = postedEvents.event_->mutable_ctgrecordedevent();
    if (pCTGBack->has_cicsabendcode()) {
        strncpy(header.abendCode, pCTGBack->cicsabendcode().c_str(), 5);
 
     // log_->debug("Program %s got abend in stub", header.progName);
        log_->debug("Program %s got abend in stub", pgmname.c_str());
        FPRINTF(stdout, "Program %s got abend in stub", pgmname.c_str());
        delete postedEvents.event_;
        postedEvents.event_ = NULL;
        return bRes; // return true with abendcode
    } else {
        memset(header.abendCode, 0, 4);
    }
 
    int payloadLength = 0;
    if(pCTGBack->has_payloadlength()){
        payloadLength = pCTGBack->payloadlength();
    }
    if(pCTGBack->has_channel()){
        struct CONTAINER* clear_ptr = *pContainer;
        while (clear_ptr != NULL) {
            *pContainer = clear_ptr->next;
            DELETE(clear_ptr);
            clear_ptr = *pContainer;
        }
        *pContainer=NULL;
        CTGRecordedEvent_Channel channel = pCTGBack->channel();
        if (channel.containers_size() > 0) {
            google::protobuf::RepeatedPtrField<
                    CTGRecordedEvent_Container> containers =
                    channel.containers();
            ::google::protobuf::RepeatedPtrField<
                    CTGRecordedEvent_Container>::iterator it =
                    containers.begin();
            Container ** ptr = pContainer;
            for (; it != containers.end(); ++it) {
                CTGRecordedEvent_Container container = *it;
                if (container.has_bitdata()) {
                    const string& bitdata = container.bitdata();
                    if (!bitdata.empty()) {
                        log_->debug("Got Container %s, data",
                                container.name().c_str(),
                                bitdata.c_str());
                        AscContainerHeader header(
                                container.name().c_str(),
                                bitdata.length());
                        *ptr = new Container(header);
                        memcpy((void*)(*ptr)->dataarea,
                                (const void*)bitdata.c_str(),
                                bitdata.length());
                        ptr = &(*ptr)->next;
                    }
                }
            }
            *ptr = NULL;
        }
    }
    delete postedEvents.event_;
    postedEvents.event_ = NULL;
    return bRes;
}
 
void StubClient::setFilterList() {
#ifdef STUBCLT_DEBUG
    FPRINTF(stdout, "    >>>Enter StubClient::setFilterList:\n");//$NON-NLS-1$
#endif
    int rc = pthread_rwlock_wrlock(&rwlock_);
    if(rc == -1){
        log_->error("error in pthread_rwlock_wrlock");//$NON-NLS-1$
    }
    filterList_.clear(); // we need to clear the previous routing rules
    vector<CICSAgentCondition*>::iterator it = clients_.begin();
    for (;clients_.size() && it != clients_.end(); it++) {
        CICSAgentCondition* condition = *it;
        // If we have system information, ignore rules that don't
        //  apply to this region
        if (
            condition->getAPPLID().length() > 0 &&pReg_->applid().compare(condition->getAPPLID()) ||
            condition->getSYSID().length() > 0 && pReg_->sysid().compare(condition->getSYSID()) ||
            condition->getJOBNAME().length() > 0 && pReg_->jobname().compare(condition->getJOBNAME()) ||
            (condition->isTS() == false) ) {
            continue;
        }
 
        const vector<string> & filters = condition->getFilter();
        vector<string>::const_iterator citr = filters.begin();
        for(;citr != filters.end(); citr ++){
            string prefix("@");
            filterList_.push_back(prefix + (*citr));
#ifdef STUBCLT_DEBUG
            FPRINTF(stdout, "Got filter from stub client:%s\n", (*citr).c_str());//$NON-NLS-1$
#endif
        }
    }
    rc =  pthread_rwlock_unlock(&rwlock_);
    if(rc == -1){
        log_->error("error in pthread_rwlock_unlock");//$NON-NLS-1$
    }
#ifdef STUBCLT_DEBUG
    FPRINTF(stdout, "Filters number is %d:\n", filterList_.size());//$NON-NLS-1$
    vector<string>::iterator itd = filterList_.begin();
    for(;filterList_.size() && itd != filterList_.end(); itd++){
        FPRINTF(stdout, "%s\n",(*itd).c_str());
    }
    FPRINTF(stdout, "    <<<Exit StubClient::setFilterList:\n");//$NON-NLS-1$
#endif
}
 
