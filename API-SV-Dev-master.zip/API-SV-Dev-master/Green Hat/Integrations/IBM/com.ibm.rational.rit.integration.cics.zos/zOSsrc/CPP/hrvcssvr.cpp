/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017.All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*******************************************************************************
 * socksvr.cpp
 * ****************************************************************************/
#pragma csect (CODE,"HRVCSSVR")
#define OPEN_DEFAULT 1
#define OPEN_SYS_EXT 1
#define _LARGE_TIME_API 1
#define _OPEN_THREADS 3
#define  _XOPEN_SOURCE 600
#define _OPEN_SYS 1
#define _ISOC99_SROURCE 1
#define _XOPEN_SOURCE_EXTENDED 1
#define _POSIX_SOURCE 1
#define _POSIX_C_SOURCE 200112L
#define _OPEN_SYS_MUTEX_EXT 1
#define _OPEN_SYS_ITOA_EXT 1
#define _OPEN_SYS_SOCK_EXT  1
#define _EXT 1
#include "socksvr.h"
#include "ritcomm.h"
#include "ritutil.h"
#include "ritlog.h"
#include "servlog.h"
#include "record.h"
#include "stubclt.h"
#include "observ.h"
#include "sockthmg.h"
#include <sys/time.h>
#include <sys/uio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <string>
#include <set>
 
using namespace std;
 
extern UserParm* g_userparm;
 
#define SOCKSVR_ERROR_BASE 13000
 
/*
 * byPass the XPCREQ to the actual target program
 * both the header and comm-area need to return to RITEXITC.
 */
void setContinueComm(int fd, Header& header, Commarea* pCommArea) {
 
    Logger* log = LoggerFactory::getInstance()->getLogger("SockServer");
 
    struct iovec iov[2];
    iov[0].iov_base = (char*) &header;
    iov[0].iov_len = sizeof(header);
    iov[1].iov_base = (char*) pCommArea->pCommarea;
    iov[1].iov_len = pCommArea->len;
 
    ssize_t nsize = writev(fd, (const struct iovec *) iov, 2);
    if (nsize < 0) {
        log->error("Socksvr writev error, errno=%d,file=%s,line=%d\n",
                errno, __FILE__, __LINE__);
    }
    close(fd);
}
 
void setContinueCont(int fd,Header& header,
        struct CONTAINER* pContainer) {
    Logger* log = LoggerFactory::getInstance()->getLogger("SockServer");
    int rc=0;
    const int flag =0;
    rc = send(fd, (char*) &header, sizeof(header),flag);
    if(rc == -1){
        log->error("SEND header UNsuccesful. "
                "The global errno is %d.\n", errno);
        close(fd);
        return;
    }
    struct CONTAINER* clear_ptr = pContainer;
    ContainerHeader containerHeader;
    ContainerHeader containerHeaderAck;
 
    while (clear_ptr != NULL) {
        clear_ptr->header.toContainerHeader(containerHeader);
        rc = send(fd, (char*) &containerHeader, sizeof(containerHeader),flag);
        if(rc == -1){
            log->error("SEND header UNsuccesful. "
                    "The global errno is %d.\n", errno);
            close(fd);
            return;
        }
        rc = send(fd, (char*) clear_ptr->dataarea, containerHeader.length,flag);
        if(rc == -1){
            log->error("SEND header UNsuccesful. "
                    "The global errno is %d.\n", errno);
            close(fd);
            return;
        }
        pContainer = clear_ptr->next;
        DELETE(clear_ptr);
        clear_ptr = pContainer;
    }
    containerHeader.length=0;
    rc = send(fd, (char*) &containerHeader, sizeof(containerHeader),flag);
    if(rc == -1){
        log->error("SEND header UNsuccesful. "
                "The global errno is %d.\n", errno);
    }
    close(fd);
    return;
 
}
/*
 * PassTrough in stubbing or in recording:
 * let RITEXITC continue with normal XPCREQ and XPCREQC.
 */
void setContinue(int fd, Header& header) {
    Logger* log = LoggerFactory::getInstance()->getLogger("SockServer");
 
    struct iovec iov;
    iov.iov_base = (char*) &header;
    iov.iov_len = sizeof(header);
 
    ssize_t nsize = writev(fd, (const struct iovec *) &iov, 1);
    if (nsize < 0) {
        log->error("Socksvr writev error, errno=%d, line=%d\n", errno,
                __LINE__);
    }
    close(fd);
}
 
void * invokeHdr(int connfd) {
    Logger* log = LoggerFactory::getInstance()->getLogger("SockServer");
    CICSRegistration* reg = CICSRegistration::getInstance();
 
    if (connfd < 0) {
        log->error("socket invalid, exit handler working thread\n");
        return NULL;
    }
    bool bContinue = true;
    while (bContinue) {
        Header header;
        Commarea* pCommArea = NULL;
        int n, nsize;
        memset((void*) &header, 0, sizeof(header));
 
        n = recv(connfd, (void*) &header, sizeof(header), MSG_WAITALL);
        if (n <= 0) {
            if (n == -1) {
                // error handling
                if (errno == 0) {
                    log->debug("Peer close the connection");
                } else if (errno == EAGAIN) {
                    log->debug("Resource Temporarily unavailable");
                    sleep(1);
                    continue;
                } else {
                    log->error("Error in recv, errno=%d, line=%d\n",
                            errno, __LINE__);
                }
            }
            bContinue = false;
            close(connfd);
            return NULL;
        } else {
            AscHeader ahdr(header);
        string pName;
        asc2ebc(ahdr.progName,pName);
        string tID;
        asc2ebc(ahdr.tranID,tID);
        string jName;
        asc2ebc(ahdr.jobName,jName);
    //  string corr;
    //  asc2ebc(ahdr.correl,corr);
        string chName;
        asc2ebc(ahdr.channelName,chName);
            if ((ahdr.length == 0) && (ahdr.dataLength == 0)) {
              //if (strncmp(ahdr.channelName, CHANNEL_NAME, 16) != 0) {
                if (strncmp(chName.c_str(), CHANNEL_NAME, 16) != 0) {
                    ContainerHeader containerHeader;
                    struct CONTAINER* headContainer;
                    n = recv(connfd, (void*) &containerHeader,
                            sizeof(containerHeader), MSG_WAITALL);
                    if (n <= 0) {
                        bContinue = false;
 
                        header.response = INT_OK;
                        header.length = 0;
                        header.dataLength = 0;
 
                        setContinue(connfd, header);
                        continue;
                    }
                    for (struct CONTAINER** ptr = &headContainer;
                            containerHeader.length > 0;
                            ptr = &(*ptr)->next) {
                        *ptr = new Container(containerHeader);
                        n = recv(connfd, (void*) (*ptr)->dataarea,
                                containerHeader.length,
                                MSG_WAITALL);
                        if (n < containerHeader.length) {
                            struct CONTAINER* clear_ptr = headContainer;
                            while (clear_ptr != NULL) {
                                headContainer = clear_ptr->next;
                                DELETE(clear_ptr);
                                clear_ptr = headContainer;
                            }
                            bContinue = false;
 
                            header.response = INT_OK;
                            header.length = 0;
                            header.dataLength = 0;
 
                            setContinue(connfd, header);
                            break;
                        }
                        (*ptr)->dataarea[containerHeader.length]='\0';
                        n = recv(connfd, (void*) &containerHeader,
                                sizeof(containerHeader), MSG_WAITALL);
                        if (n < sizeof(containerHeader)) {
                            struct CONTAINER* clear_ptr = headContainer;
                            while (clear_ptr != NULL) {
                                headContainer = clear_ptr->next;
                                DELETE(clear_ptr);
                                clear_ptr = headContainer;
                            }
                            bContinue = false;
 
                            header.response = INT_OK;
                            header.length = 0;
                            header.dataLength = 0;
 
                            setContinue(connfd, header);
                            break;
                        }
                    }
                    if(headContainer == NULL){
                        bContinue = false;
 
                        header.response = INT_OK;
                        header.length = 0;
                        header.dataLength = 0;
 
                        setContinue(connfd, header);
                        continue;
                    }else {
                        Observation::instance(reg)->addRequestCount(
                                ahdr.progName);
                        Recorder* pRec = Recorder::instance(reg);
                        StubClient* pStub = StubClient::instance(reg);
                        pRec->handleInvocation(ahdr, headContainer); // record
                        if (header.reqresp != INT_BeforeLink) {
                            bContinue = false;
                            header.response = INT_OK;
                            header.length = 0;
                            header.dataLength = 0;
 
                            setContinueCont(connfd, header,headContainer);
                            continue;
                        }
                        else {
                            // Before Link
                            CICSAgentCondition* pStubClt = pStub->match(
                                    ahdr);
                            if (NULL != pStubClt) {
                                // RIT running stub for this program
                                bContinue = false;
                                bool handled = pStub->handleStub(ahdr,
                                        &headContainer, pStubClt);
 
                                if (handled) {
                                    // if handled==true, byPass (including Abend)
                                    if (strlen(ahdr.abendCode) > 0) {
                                        string ebcAbendcode;
                                        asc2ebc(ahdr.abendCode,
                                                ebcAbendcode);
                                        strncpy(header.abendCode,
                                                ebcAbendcode.c_str(),
                                                4);
                                    } else {
                                        memset(header.abendCode, 0, 4);
                                    }
                                    bContinue=false;
                                    header.response = INT_Bypass; // set byPass in header
                                    header.dataLength = ahdr.dataLength;
                                    setContinueCont(connfd, header,
                                            headContainer);
                                    continue;
                                }
                            }
                            header.response = INT_OK;
                            header.length = 0;
                            header.dataLength = 0;
                            bContinue =false;
 
                            setContinueCont(connfd, header,headContainer);
                            continue;
                        }
 
                    }
            /*  } else if ((strncmp(ahdr.progName, RIT_DUMMY_PGM, 8)
                        == 0)
                        && (strncmp(ahdr.tranID, RIT_DUMMY_TRN, 4) == 0)
                        && (strncmp(ahdr.jobName, RIT_DUMMY_JOB, 8) == 0)
                        && (strncmp(ahdr.correl, RIT_DUMMY_COR_BCD, 8)
                                == 0)) { */
                } else if ((strncmp(pName.c_str(), RIT_DUMMY_PGM, 8)
                        == 0)
                        && (strncmp(tID.c_str(), RIT_DUMMY_TRN, 4) == 0)
                        && (strncmp(jName.c_str(), RIT_DUMMY_JOB, 8) == 0 )
                        && (strncmp(ahdr.correl, RIT_DUMMY_COR_BCD, 8)
                                == 0)) {
                    // this is the special message we send from
                    // RITMNGRC to RITAGENT, which is used for verifying the
                    // communication path. See WI 47836.
                    FPRINTF(stdout,
                            "RITAGENT received TEST CONNECTION package.\n");
                    FPRINTF(stdout,
                            "Set TEST CONNECTION response to %d.\n",
                            RIT_MAGIC_RESP);
                    header.response = RIT_MAGIC_RESP;
                    setContinue(connfd, header);
                    break; // we are ready to exit
                } else if ((strncmp(ahdr.progName, RIT_PLTSD_PGM, 8)
                        == 0)
                        && (strncmp(ahdr.tranID, RIT_DUMMY_TRN, 8) == 0)
                        && (strncmp(ahdr.jobName, RIT_PLTSD_JOB, 8) == 0)
                        && (strncmp(ahdr.correl, RIT_PLTSD_COR_BCD, 8)
                                == 0)) {
                    // this is the special message we send from
                    // RITMNGRC to RITAGENT, which is used for verifying the
                    // communication path. See WI 47836.
                    FPRINTF(stdout,
                            "RITAGENT received SHUTDOWN package.\n");
                    FPRINTF(stdout, "Set SHUTDOWN response to %d.\n",
                            RIT_PLTSD_RESP);
                    header.response = RIT_PLTSD_RESP;
                    setContinue(connfd, header);
                    // raise SIGUSR1 to tell main program to exit.
                    log->debug("Raise SIGUSR1.");
                    ritpost(&g_userparm->CANCLECB);
                    sleep(1);
                    break; // we are ready to exit
                }
            }else {
            if (header.dataLength > 0
                    && header.dataLength < header.length) {
                nsize = header.dataLength;
            } else {
                nsize = header.length;
            }
 
            if (nsize > 0) {
                pCommArea = new Commarea(nsize);
                if (pCommArea->pCommarea == NULL
                        || (n = recv(connfd,
                                (void*) pCommArea->pCommarea, nsize,
                                MSG_WAITALL)) < nsize) {
                    string err;
                    if (errno == ENOMEM) {
                        asc2ebc(strerror(errno),err);
                    //  log->debug(
                    //          "Memory allocation failed for commarea.%s",
                        log->debug(
                                "Memory allocation failed for commarea.%s",
                                err.c_str());
                    }
                    if (n == -1) {
                        // error handling
                        if (errno == 0) {
                            log->debug("Peer close the connection");
                        } else {
                            log->error(
                                    "Error in recv, errno=%d, line=%d\n",
                                    errno, __LINE__);
                        }
                    }
                    close(connfd);
                    DELETE(pCommArea);
                    return NULL;
                }
                pCommArea->pCommarea[nsize]='\0';
 
            }
            Recorder* pRec = Recorder::instance(reg);
            StubClient* pStub = StubClient::instance(reg);
            if (pRec == NULL || pStub == NULL) {
                return NULL;
            }
            Observation::instance(reg)->addRequestCount(ahdr.progName);
            pRec->handleInvocation(ahdr, pCommArea); // record
            if (header.reqresp != INT_BeforeLink){
                if (header.response == 0) {
                    bContinue = false;
 
                    header.response = INT_OK;
                    header.length = 0;
                    header.dataLength = 0;
 
                    setContinue(connfd, header);
                } else {
                    header.response = 0;
                }
            } else {
                // BeforeLink
                CICSAgentCondition* pStubClt = pStub->match(ahdr);
                if (NULL != pStubClt) {
                    // RIT running stub for this program
                    bContinue = false;
                    bool handled = pStub->handleStub(ahdr, pCommArea,
                            pStubClt);
 
                    if (handled) {
                        // if handled==true, byPass (including Abend)
                        if (strlen(ahdr.abendCode) > 0) {
                            string ebcAbendcode;
                            asc2ebc(ahdr.abendCode, ebcAbendcode);
                            strncpy(header.abendCode,
                                    ebcAbendcode.c_str(), 4);
                        } else {
                            memset(header.abendCode, 0, 4);
                        }
                        header.response = INT_Bypass; // set byPass in header
                        header.dataLength = ahdr.dataLength;
                        setContinueComm(connfd, header, pCommArea);
                    } else { //  handled==false, passTrough
 
                        header.response = INT_OK;
                        header.length = 0;
                        header.dataLength = 0;
 
                        setContinue(connfd, header);
                    }
                }else{
                    if (header.response == 0) {
                        bContinue = false;
 
                        header.response = INT_OK;
                        header.length = 0;
                        header.dataLength = 0;
 
                        setContinue(connfd, header);
                    }
                }
            }
            DELETE(pCommArea);
        }}
    } // end of while
    return NULL;
}
 
void* socksvr(void* arg) {
    Logger* log = LoggerFactory::getInstance()->getLogger("SockServer");
    SockServer* pServer = (SockServer*) arg;
    CICSRegistration* pReg = pServer->registration();
    ServerLogger* serverLogger = ServerLogger::instance(pReg);
    int socketarray_[RIT_SOCK_MAX];
    int sockarraysize =0;
 
    memset(&socketarray_, 0, sizeof(socketarray_));
 
    int listenfd, connfd;
    socklen_t clilen;
    struct sockaddr_storage cliaddr;
    struct addrinfo hints, *servinfo, *servsave;
    char portBuf[RIT_PORTNUM_LEN] = { 0 };
    char hostbuf[_POSIX_HOST_NAME_MAX];
    char hostname[_POSIX_HOST_NAME_MAX] = { 0 };
    struct timeval timeout;
    const int on = 1;
    int sockfdmax = 0;
    fd_set readset;
    int rc;
 
    char strerrBuf[ERR_BUF_LEN] = { 0 };
 
    memset(&hints, 0, sizeof(hints));
    hints.ai_socktype = SOCK_STREAM;
    setenv("_EDC_ADD_ERRNO2", "1", 1); // add errno2 to strerror()
    // ctrace() will be called when errno is 24/111
    setenv("_EDC_ERRNO_DIAG", "2,111", 1);
    hints.ai_flags = AI_PASSIVE;
    pthread_t thid = pthread_self();
    FPRINTF(stdout, "SockSvr thread id is %X.\n", thid);
    log->info("SockSvr thread id is %X.", thid);
 
    hints.ai_family = AF_UNSPEC;
  //itoa(pReg->port(), portBuf, DECIMAL);
    strcpy(portBuf, std::to_string(pReg->port()).c_str());
 
    rc = getaddrinfo(NULL, portBuf, &hints, &servinfo);
    if (rc) {
        log->error("Socksvr getaddrinfo eror, errno=%d.", errno);
        FPRINTF(stdout, "getaddrinfo error, errno=%d. Exiting...\n",
                errno);
        exit(SOCKSVR_ERROR_BASE);
    }
 
    servsave = servinfo;
 
    do {
        listenfd = socket(servinfo->ai_family, servinfo->ai_socktype,
                servinfo->ai_protocol);
        if (listenfd < 0) {
            log->warn("Socksvr failed to create %s socket, errno %d.",
                    errno);
            continue;
        }
        rc = setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &on,
                sizeof(on));
        if (rc < 0) {
            close(listenfd);
            log->warn(
                    "Socksvr failed to selistenfdt option for socket, errno=%d.",
                    errno);
            continue;
        }
        if (servinfo->ai_family == AF_INET6) {
            if (setsockopt(listenfd, IPPROTO_IPV6, IPV6_V6ONLY, &on,
                    sizeof(on)) < 0) {
                close(listenfd);
                log->warn(
                        "Socksvr failed to set option for socket, errno=%d.",
                        errno);
                continue;
            }
        }
        if ((::bind(listenfd, servinfo->ai_addr, servinfo->ai_addrlen) < 0)) {
      //if ((bind(listenfd, servinfo->ai_addr, servinfo->ai_addrlen) < 0)) {
            close(listenfd);
            log->warn("Socksvr failed to bind to socket, errno=%d.",
                    errno);
            continue;
        }
        rc = listen(listenfd, LISTENQ);
        if (rc != 0) {
            close(listenfd);
            log->warn("Socksvr failed to listen to socket, errno=%d.",
                    errno);
        } else {
            if(listenfd > sockfdmax){
                sockfdmax = listenfd;
            }
            socketarray_[sockarraysize++] = listenfd;
        }
    } while ((servinfo = servinfo->ai_next) != NULL&&
            sockarraysize < RIT_SOCK_MAX);
    if (sockarraysize <= 0) {
        freeaddrinfo(servsave);
       log->error("Socksvr init error,file:%s, line: %d\n", __FILE__, __LINE__);
      //log->error("Socksvr init error,"__FILE__, __LINE__);
        FPRINTF(stdout, "Failed to open a port. Exiting...\n");
        exit(SOCKSVR_ERROR_BASE + 1);
    }
 
    freeaddrinfo(servsave);
    log->info("RITAGENT is listening at port:%d.", pReg->port());
    FPRINTF(stdout, "RITAGENT is listening at port:%d.\n",
            pReg->port());
 
    while (true) {
        FD_ZERO(&readset);
        for (int sockindex = 0; sockindex < sockarraysize; sockindex++) {
            FD_SET(socketarray_[sockindex], &readset);
        }
        memset(&timeout, 0, sizeof(timeout));
        timeout.tv_sec = RIT_SERVER_SELECT_TIMEOUT;
        timeout.tv_usec = 0;
        /* reset errno2 and errno to zero */
        errno = 0;
        *__err2ad() = 0x0;
        int rc = select(sockfdmax + 1, &readset, NULL, NULL, &timeout);
        if (rc < 0) {
            /* an error occurred during the SELECT() */
            int errorNo = errno;
            int errorNo2 = __errno2();
            rc = strerror_r(errorNo, strerrBuf, ERR_BUF_LEN);
            if (rc != 0) {
                FPRINTF(stdout, "strerror_r return %d\n", rc);
            }
            log->error(
                    "select error, errno=%08x, __errno2 = %08x, %s\n",
                    errno, errorNo2, strerrBuf);
            if (pReg->logLevel() < 2) {
                FPRINTF(stdout,
                        "select error, errno=%08x, __errno2 = %08x, %s\n",
                        errno, errorNo2, strerrBuf);
            }
            //log->debug("Raise SIGUSR1.");
            //raise(SIGUSR1);
            sleep(60);
        } else if (rc == 0) {
            /* no sockets or messages were ready in our little poll */
            // log->debug( "No incoming DPL messages" );
        } else {
            int sockindex = 0;
            for (sockindex = 0; sockindex < sockarraysize; sockindex++) {
                if (FD_ISSET(socketarray_[sockindex], &readset)) {
                    *__err2ad() = 0x0;
                    errno = 0;
                    connfd = accept(socketarray_[sockindex],
                            (struct sockaddr *) &cliaddr, &clilen);
                    if (connfd == -1) {
                        /* an error occurred during the accept() */
                        int errorNo = errno;
                        int errorNo2 = __errno2();
                        rc = strerror_r(errorNo, strerrBuf,
                                ERR_BUF_LEN);
                        if (rc != 0) {
                            log->debug("strerror_r return %d\n", rc);
                        }
                        log->debug(
                                "accept error, errno=%08x, __errno2 = %08x, %s\n",
                                errno, errorNo2, strerrBuf);
                    } else {
                        int error = 0;
                        int nice = 1;
                        log->debug("server thread accept fd %d",connfd);
                        invokeHdr(connfd);
                    } // accepted valid connfd
                } //file descriptor is ready for processing
            } //iterate through all of file descriptor
            if (sockindex != sockarraysize) {
                log->debug("Error after select...");
            }
        } //else select
    } // while loop
    pServer->stop(2);
    pthread_exit(NULL);
    return NULL;
}
 
SockServer* SockServer::s_instance = NULL;
 
SockServer* SockServer::instance(CICSRegistration* reg) {
    if (s_instance == 0) {
        s_instance = new SockServer(reg);
    }
    return s_instance;
}
 
SockServer::SockServer(CICSRegistration* reg) :
        pReg_(reg), stop_(0), log_(0){
    log_ = LoggerFactory::getInstance()->getLogger("SockServer");
 
    int rc = pthread_attr_init(&thrattr_);
    if (rc == -1) {
        log_->error("error in pthread_attr_init.");
        FPRINTF(stdout, "pthread_attr_init error, errno=%d. Exiting.\n",
                errno);
        exit(EXIT_FAILURE);
    }
    int ds = 1; // PTHREAD_CREATE_DETACHED
  //rc = pthread_attr_setdetachstate(&thrattr_, &ds);
    rc = pthread_attr_setdetachstate(&thrattr_,&ds);
    if (rc == -1) {
        log_->error("error in pthread_attr_setdetachstate");
        FPRINTF(stdout,
                "pthread_attr_setdetachstate error, errno=%d. Exiting.\n",
                errno);
        exit(EXIT_FAILURE);
    }
    rc = pthread_attr_setweight_np(&thrattr_, __MEDIUM_WEIGHT);
    if (rc == -1) {
        log_->error("error in pthread_attr_setweight_np.");
        FPRINTF(stdout,
                "pthread_attr_setweight_np error, errno=%d. Exiting.\n",
                errno);
        exit(EXIT_FAILURE);
    }
    rc = pthread_rwlockattr_init(&rwlattr_);
    if (rc == -1) {
        log_->error("error in pthread_rwlockattr_init.");
        FPRINTF(stdout,
                "pthread_rwlockattr_init error, errno=%d. Exiting.\n",
                errno);
        exit(EXIT_FAILURE);
    }
    rc = pthread_rwlockattr_setpshared(&rwlattr_,
            PTHREAD_PROCESS_PRIVATE);
    if (rc == -1) {
        log_->error("error in pthread_rwlockattr_setpshared.");
        FPRINTF(stdout,
                "pthread_rwlockattr_setpshared error, errno=%d. Exiting.\n",
                errno);
        exit(EXIT_FAILURE);
    }
    rc = pthread_rwlock_init(&statuslock_, &rwlattr_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_init.");
        FPRINTF(stdout,
                "pthread_rwlock_init error, errno=%d. Exiting.\n",
                errno);
        exit(EXIT_FAILURE);
    }
}
 
SockServer::~SockServer() {
    int i = getWaitTimeout();
    while (getStop() != 2 && i > 0) {
        stop(1);
        i--;
        sleep(1);
    }
    if (pthread_attr_destroy(&thrattr_) == -1) {
        log_->error("error in pthread_attr_destroy.");
    }
    if (pthread_rwlock_destroy(&statuslock_) == -1) {
        log_->error("error in pthread_rwlock_destroy loglvllock.");
    }
    if (pthread_rwlockattr_destroy(&rwlattr_) == -1) {
        log_->error("error in pthread_rwlockattr_destroy.");
    }
}
 
void SockServer::start() {
    if (pthread_create(&thread_, &thrattr_, &socksvr, (void*) this)
            != 0) {
        log_->error("pthread_create() error, errno=%d.", errno);
    }
    //taskManager.startWorker(1);
    log_->debug("SockSocket started.");
 
}
/*EDEADLK The current thread already owns the read or write lock for writing or reading.
 * EINVAL The value specified by rwlock is not valid.
 * ENOMEM There is not enough memory to acquire a lock.
 * This errno will only occur in the private path.*/
void SockServer::stop(int status) {
    int rc = pthread_rwlock_wrlock(&statuslock_);
    if (rc == -1) {
        if (errno != EDEADLK) {
            log_->error("error in pthread_rwlock_wrlock, errno=%d.",
                    errno);
        }
    }
    stop_ = status;
    rc = pthread_rwlock_unlock(&statuslock_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_wrlock, errno=%d.", errno);
    }
    //taskManager.stopWorker();
    log_->info("SockServer is stopping.");
}
 
int SockServer::getStop() {
    int rc = pthread_rwlock_rdlock(&statuslock_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_rdlock.");
    }
    int status = stop_;
    rc = pthread_rwlock_unlock(&statuslock_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_unlock.");
    }
    return status;
}
 
//SockThreadManager& SockServer::getTaskManager() {
//    return taskManager;
//}
