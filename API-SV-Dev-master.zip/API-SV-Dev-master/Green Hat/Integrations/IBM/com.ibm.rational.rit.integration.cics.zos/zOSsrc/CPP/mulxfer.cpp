/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017.All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*******************************************************************************
 * mulxfer.cpp
 ******************************************************************************/
#pragma csect (CODE,"MULXFER")
#define OPEN_DEFAULT 1
#define OPEN_SYS_EXT 1
#define _LARGE_TIME_API 1
#define _OPEN_THREADS 3
#define  _XOPEN_SOURCE 600
#define _OPEN_SYS 1
#define _ISOC99_SROURCE 1
#define _XOPEN_SOURCE_EXTENDED 1
#define _POSIX_SOURCE 1
#define _POSIX_C_SOURCE 200112L
#define _OPEN_SYS_MUTEX_EXT 1
#define _OPEN_SYS_ITOA_EXT 1
#include <time.h>
#include "mulxfer.h"
#include "ritcomm.h"
/*
using namespace std;
typedef CURL* PCURL;
 
#define DEBUG_MULXFER 1
 
#define MAX_URL_LEN  256
 
//struct ObjectToSendMulti {
//    char*  buffer;
//    char** readptr;
//    long* sizeleft;
//    ObjectToSendMulti(const string& ostr, int num) {
//        int length = ostr.length();
//        buffer = new char[length];
//        if (buffer == NULL) {
//            exit(MEMORY_ALLOC_FAILURE);
//        }
//        memcpy(buffer, (char*) ostr.c_str(), length);
//        buffer[length - 1] = '\0';
//
//        readptr = new char*[num];
//        sizeleft = new long[num];
//        for(int i = 0; i < num; i++){
//            readptr[i] = buffer;
//            sizeleft[i] =length;
//        }
//    }
//    ~ObjectToSendMulti() {
//        delete [] readptr;
//        delete [] sizeleft;
//        delete buffer;
//    }
//};
//
//struct ObjectReceivedMulti {
//    char * buffer;
//    char ** ptr;
//    long * len;
//
//    ObjectReceivedMulti(int num, const string& ostr) {
//        int length = ostr.length();
//        buffer = new char[length];
//        if (buffer == NULL) {
//            exit(MEMORY_ALLOC_FAILURE);
//        }
//        memcpy(buffer, (char*) ostr.c_str(), length);
//        buffer[length - 1] = '\0';
//
//        ptr = new char*[num];
//        len = new long[num];
//        for(int i = 0; i < num; i++){
//            len[i] = 0;
//            ptr[i] = 0;
//        }
//
//
//        objSend.sizeleft = (long) ostr.length();
//        objSend.readptr = (char*) malloc(objSend.sizeleft);
//        if (objSend.readptr == NULL) {
//            exit(MEMORY_ALLOC_FAILURE);
//        }
//        memcpy(objSend.readptr, (char*) ostr.c_str(), ostr.length());
//        objSend.readptr[ostr.length() - 1] = '\0';
//
//    }
//    ~ObjectReceivedMulti() {
//        delete [] ptr;
//        delete [] len;
//        delete buffer;
//    }
//};
 
MultiXfer::MultiXfer() {
    //pmcurl_ = curl_multi_init();
    pcurl_ = curl_easy_init();
}
 
MultiXfer::~MultiXfer() {
    curl_easy_cleanup(pcurl_);
   // curl_multi_cleanup(pmcurl_);
}
 
static size_t
mulxfer_read(void *ptr, size_t size, size_t nmemb, void *userp) {
 
    struct ObjectToSend *objSend = (struct ObjectToSend *) userp;
 
    if (size * nmemb < 1)
        return 0;
 
    if (objSend->sizeleft) {
        *(char *) ptr = objSend->readptr[0];
        objSend->readptr++;
        objSend->sizeleft--;
        return 1;
    }
 
    return 0;
}
 
 
//static size_t
//mulxfer_multi_read(void *ptr, size_t size, size_t nmemb, void *userp) {
//
//    struct ObjectToSendMulti *objSend = (struct ObjectToSendMulti *) userp;
//
//    if (size * nmemb < 1)
//        return 0;
//
//    if (objSend->sizeleft) {
//        *(char *) ptr = objSend->readptr[0];
//        objSend->readptr++;
//        objSend->sizeleft--;
//        return 1;
//    }
//
//    return 0;
//}
 
static size_t
mulxfer_write(void *buffer, size_t size, size_t nmemb, void *userp) {
 
    ObjectReceived* pRecv = (ObjectReceived*) userp;
 
    size_t len = size * nmemb;
    size_t newLen = len + pRecv->len;
    pRecv->ptr = (char*) realloc(pRecv->ptr, newLen + 1);
    if (pRecv->ptr == NULL) {
        FPRINTF(stdout, "realloc() failed\n");
        exit(MEMORY_ALLOC_FAILURE);
    }
    memcpy(pRecv->ptr + pRecv->len, buffer, len);
    pRecv->ptr[newLen] = '\0';
    pRecv->len = newLen;
 
    return len;
}
 
void
MultiXfer::postObj(const string & url, const string & activities,
        RecordedEvent* object)
{
#ifdef DEBUG_MULXFER
    FPRINTF(stdout, "Enter MultiXfer::postObj, file=%s, line=%d\n"
        "URL=%s\n",
        __FILE__, __LINE__, url.c_str());
#endif
    string ostr;
    object->SerializeToString(&ostr);
 
    struct ObjectToSend objSend;
    struct ObjectReceived objRecv;
 
    objSend.sizeleft = (long) ostr.length();
    objSend.readptr = (char*) malloc(objSend.sizeleft);
    if (objSend.readptr == NULL) {
        exit(MEMORY_ALLOC_FAILURE);
    }
    memcpy(objSend.readptr, (char*) ostr.c_str(), ostr.length());
    objSend.readptr[ostr.length() - 1] = '\0';
 
    struct curl_slist *http_headers=NULL;
    char buffer[128] = "";
    http_headers = curl_slist_append(http_headers,
            RIT_HTTP_HEADER_CONTENT_TYPE);
//    snprintf(buffer, 127, "%s%s", RIT_HTTP_HEADER_SOURCE,
//            "winmvs3h.hursley.ibm.com");
//    http_headers = curl_slist_append(http_headers, buffer);
    snprintf(buffer, 127, "%s%s", RIT_HTTP_HEADER_ACTIVITYID,
            activities.c_str());
    http_headers = curl_slist_append(http_headers, buffer);
//    snprintf(buffer, 127, "%s%s", RIT_HTTP_CorrelationID,
//            "correlationid");
//    http_headers = curl_slist_append(http_headers, buffer);
    time64_t ltime;
    time64(&ltime);
    snprintf(buffer, 127, "%s%d", RIT_HTTP_TIMESTAMP, ltime);
    http_headers = curl_slist_append(http_headers, buffer);
 
    curl_easy_setopt(pcurl_, CURLOPT_HTTPHEADER, http_headers);
    curl_easy_setopt(pcurl_, CURLOPT_URL, url.c_str());
    // Now specify we want to POST data
    curl_easy_setopt(pcurl_, CURLOPT_POST, 1L);
    curl_easy_setopt(pcurl_, CURLOPT_NOSIGNAL, 1L);
    // we want to use our own read function
    curl_easy_setopt(pcurl_, CURLOPT_READFUNCTION, mulxfer_read);
    curl_easy_setopt(pcurl_, CURLOPT_WRITEFUNCTION, mulxfer_write);
    curl_easy_setopt(pcurl_, CURLOPT_WRITEDATA, &objRecv);
    // pointer to pass to our read function
    curl_easy_setopt(pcurl_, CURLOPT_READDATA, &objSend);
 
#ifdef USE_CHUNKED
    {
        struct curl_slist *chunk = NULL;
        chunk = curl_slist_append(chunk, "Transfer-Encoding: chunked");
        res = curl_easy_setopt(pcurl_, CURLOPT_HTTPHEADER, chunk);
        // use curl_slist_free_all() after the *perform() call to free this
        // list again
    }
#else
    // Set the expected POST size. If you want to POST large amounts of data,
    // consider CURLOPT_POSTFIELDSIZE_LARGE/
    curl_easy_setopt(pcurl_, CURLOPT_POSTFIELDSIZE, objSend.sizeleft);
#endif
    // Perform the request, res will get the return code
    CURLcode res = curl_easy_perform(pcurl_);
    // Check for errors
    if (res != CURLE_OK) {
        cout << "postObj: curl_easy_perform() failed: ";
        cout << curl_easy_strerror(res) << endl;
        return;
    }
#ifdef DEBUG_MULXFER
    cout << "curl_easy_perform OK" << endl;
#endif // DEBUG_OBJXFER
    long httpCode = 0;
    res = curl_easy_getinfo(pcurl_, CURLINFO_RESPONSE_CODE, &httpCode);
    if (res != CURLE_OK) {
        cout << "postObj: curl_easy_getinfo() failed: ";
        cout << curl_easy_strerror(res) << endl;
        return;
    }
#ifdef DEBUG_MULXFER
    cout << "HTTP RESPONSE CODE AFTER POST: " << httpCode << endl;
#endif // DEBUG_OBJXFER
    if (200 == httpCode){
        string parsedStr(objRecv.ptr);
        object->ParseFromString(parsedStr);
    }
#ifdef DEBUG_MULXFER
    FPRINTF(stdout, "Event type=%d\n",object->type());
    FPRINTF(stdout, "Event timestamp=%d\n",object->timestamp());
    const CTGRecordedEvent& ctg = object->ctgrecordedevent();
    FPRINTF(stdout, "CTGEvent applid=%s\n",  ctg.applid().c_str());
    FPRINTF(stdout, "CTGEvent sysid=%s\n",  ctg.sysid().c_str());
#endif // DEBUG_OBJXFER
    return;
}
 
//void
//MultiXfer::postObj(map<string, string >& activityMap,
//        RecordedEvent* object) {
//    int nRec = activityMap.size();
//    int still_running; // keep number of running handles
//    int i = 0;
//
//    CURLMsg *msg; // for picking up messages with the transfer status
//    int msgs_left; // how many messages are left
//    vector<PCURL> aHandles(nRec);
//    vector<string> aURLs(nRec);
//
//    string ostr;
//    object->SerializeToString(&ostr);
//
//    struct ObjectToSendMulti objSendMul(ostr, nRec);
//    struct ObjectReceivedMulti objRecv(nRec);
//
//    map<string, string>::const_iterator it = activityMap.begin();
//    // Allocate one CURL handle per transfer
//    for (i = 0; i < nRec; i++, it++){
//        const pair<string, string>& curr = *it;
//        aHandles[i] = curl_easy_init();
//        aURLs[i] = curr.first;
//        curl_easy_setopt(aHandles[i], CURLOPT_URL, curr.first.c_str());
//        // Now specify we want to POST data
//        curl_easy_setopt(aHandles[i], CURLOPT_POST, 1L);
//        curl_easy_setopt(aHandles[i], CURLOPT_NOSIGNAL, 1L);
//        // we want to use our own read function
//        curl_easy_setopt(aHandles[i], CURLOPT_READFUNCTION, mulxfer_multi_read);
//        curl_easy_setopt(aHandles[i], CURLOPT_WRITEFUNCTION, mulxfer_multi_write);
//        curl_easy_setopt(aHandles[i], CURLOPT_WRITEDATA, &objRecv);
//        // pointer to pass to our read function
//        curl_easy_setopt(aHandles[i], CURLOPT_READDATA, &objSendMul);
//        curl_easy_setopt(aHandles[i], CURLOPT_POSTFIELDSIZE_LARGE, objSendMul.sizeleft[i]);
//
//        curl_multi_add_handle(pmcurl_, aHandles[i]);
//    }
//
//    curl_multi_perform(pmcurl_, &still_running);
//
//    while (still_running) {
//        struct timeval timeout;
//        int rc; // select() return code
//
//        fd_set fdread;
//        fd_set fdwrite;
//        fd_set fdexcep;
//        int maxfd = -1;
//
//        long curl_timeo = -1;
//
//        FD_ZERO(&fdread);
//        FD_ZERO(&fdwrite);
//        FD_ZERO(&fdexcep);
//
//        // set a suitable timeout to check the transfer
//        timeout.tv_sec = 0;
//        timeout.tv_usec = 200;
//
//        curl_multi_timeout(pmcurl_, &curl_timeo);
//        if (curl_timeo >= 0) {
//            timeout.tv_sec = curl_timeo / 1000;
//            if (timeout.tv_sec > 1)
//                timeout.tv_sec = 1;
//            else
//                timeout.tv_usec = (curl_timeo % 1000) * 1000;
//        }
//
//        // get file descriptors from the transfers
//        curl_multi_fdset(pmcurl_, &fdread, &fdwrite, &fdexcep, &maxfd);
//
//        rc = select(maxfd + 1, &fdread, &fdwrite, &fdexcep, &timeout);
//
//        switch (rc) {
//        case -1:
//            // select error
//            break;
//        case 0: // timeout
//        default: // action
//            curl_multi_perform(pmcurl_, &still_running);
//            break;
//        }
//    }
//
//    // See how the transfers went
//    while ((msg = curl_multi_info_read(pmcurl_, &msgs_left))) {
//        if (msg->msg == CURLMSG_DONE) {
//            int idx, found = 0;
//
//            // Find out which handle this message is about
//            for (idx = 0; idx < nRec; idx++) {
//                found = (msg->easy_handle == aHandles[idx]);
//                if (found)
//                    break;
//            }
//            printf("%s transfer completed with status %d\n",
//                    aURLs[idx].c_str(), (int)msg->data.result);
//        }
//    }
//
//
//    for (i = 0; i < nRec; i++)
//        curl_easy_cleanup(aHandles[i]);
//}
*/
