/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017.All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*******************************************************************************
 * hrvcprms.cpp
 * Class
 ******************************************************************************/
#pragma csect (CODE,"HRVCPRMS")
#include "parms.h"
#include <iterator>
#include <iostream>
using namespace std;
 
Parms::Parms() {
    this->_params.clear();
}
 
int Parms::parseParms(std::queue<std::string> &tokens) {
    PARAMETER status(MININDEX);
    std::string value = "";
  //for( ; ! tokens.empty();tokens.pop() ){
    while (!tokens.empty()) {
        std::string str = tokens.front();
        tokens.pop();
        size_t pos = str.find_first_of('-');
        if (pos == 0) {
            enum PARAMETER key = stringToId(str.substr(pos + 1));
            if (key != MININDEX && key != MAXINDEX) {
                //update value before read new option
                this->_params[status] = value;
 
                //switch to new status
                status = key;
             // value = "";
                value.clear();
                continue;
            }
        }
 
        value += str;
    }
    //update value before read new option
    this->_params[status] = value;
 
    return 0;
}
 
Parms::~Parms() {
    this->_params.clear();
}
 
const char* Parms::idToString(PARAMETER option) {
    switch (option) {
    case APPLID:
        return "APPLID";
        break;
    case BINDADDR:
        return "BINDADDR";
        break;
    case PORT:
        return "PORT";
        break;
    case RTCPURL:
        return "RTCPURL";
        break;
    case LOGLEVEL:
        return "LOGLEVEL";
        break;
    case OBSERVATIONLEVEL:
        return "OBSERVATIONLEVEL";
        break;
    case KEYRING:
        return "KEYRING";
        break;
    default:
        return "invalid";
        break;
    }
    return NULL;
}
 
std::string Parms::getOptionValue(std::string option) {
    return this->_params[stringToId(option)];
}
 
int Parms::parseArgs(int argc, char* argv[]) {
    //omit first parm which is the location of the program
    for (int index = 1; index < argc; index++) {
        if (index > MININDEX && index < MAXINDEX) {
            enum PARAMETER key = (enum PARAMETER )index;
            std::string str = argv[index];
            this->_params[key]= str;
        }
    }
    return 0;
}
 
enum Parms::PARAMETER Parms::stringToId(std::string key) {
if (key.compare("APPLID") == 0) {
    return APPLID;
} else if (key.compare("BINDADDR") == 0) {
    return BINDADDR;
} else if (key.compare("PORT") == 0) {
    return PORT;
} else if (key.compare("RTCPURL") == 0) {
    return RTCPURL;
} else if (key.compare("LOGLEVEL") == 0) {
    return LOGLEVEL;
} else if (key.compare("OBSERVATIONLEVEL") == 0) {
    return OBSERVATIONLEVEL;
} else if (key.compare("KEYRING") == 0) {
    return KEYRING;
}
return MAXINDEX;
}
