/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2019. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*******************************************************************************
 * hrvccics.cpp
 * This program run in JES batch. It is the main control of RIT CICS Agent.
 * Functions:
 * 1. Add period task which send registration to RTCP
 * 2. Add period task which get record/stub configurations from RTCP
 * 3. Add period task which send diagnostic log to RTCP
 * 4. Add period task which send observation request/resource to RTCP
 * 5. Listen on socket to wait connection from CICS
 * 6. Handle the record/stub according to configuration
 * 7. Accept Enable/disable/STOP command from the console
 ******************************************************************************/
#pragma csect(CODE,"HRVCCICS")//$NON-NLS-1$
#ifndef RESOLVE_VIA_LOOKUP
#define RESOLVE_VIA_LOOKUP
#endif
 
#ifndef _OPEN_SYS_SOCK_IPV6
#define _OPEN_SYS_SOCK_IPV6
#endif
 
#include <curl/curl.h>
#include "ritcomm.h"
#include "ritutil.h"
#include "svrpoll.h"
#include "regpoll.h"
#include "cfgpoll.h"
#include "observ.h"
#include "record.h"
#include "stubclt.h"
#include "socksvr.h"
#include "ritlog.h"
#include "servlog.h"
#include <signal.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/msg.h>
#include <errno.h>
#include <fcntl.h>
#include <fstream>
#include <sstream>
#include "parms.h"
#include <google/protobuf/stubs/common.h>
 
#ifndef _XOPEN_SOURCE_EXTENDED
#define _XOPEN_SOURCE_EXTENDED 1
#endif
 
#ifndef _ALL_SOURCE
#define _ALL_SOURCE
#endif
 
#ifndef _OPEN_MSGQ_EXT
#define _OPEN_MSGQ_EXT    1
#endif
 
#include <sys/ps.h>
#include "rtcpset.h"
// #define DEBUG_RITCICS
 
/*
 * param1: CICS region applid=IY3HZCI5
 * param2: sysid = cics
 * param3: regionJOBName = IY3HZCI5
 * param4: server base-url=http://hostname:7819/RTCP/
 * param5: logger level=info
 * param6: observation level
 */
 
#ifdef __cplusplus             /* the __cplusplus macro is     */
extern "C" void rit_exit(void); /* automatically defined by the  */
extern "C" void sig_int(int a);
extern "C" void sig_pipe(int a);
extern "C" void sig_usr1(int a);
extern "C" void sig_usr2(int a);
extern "C" void sig_ioerr(int a);
#else                          /* C++/MVS compiler              */
void rit_exit(void);
void sig_int(int);
void sig_pipe(int);
void sig_usr1(int);
void sig_usr2(int);
void sig_ioerr(int);
#endif
 
#define RIT_INTERNAL_TEST     "RITTEST" //$NON-NLS-1$
int parseParams(int argc, char** argv, CICSAgentConfig& config);
int checkBindAddr(CICSAgentConfig& config);
string & getStartInfo(string & startInfo);
/** stop all the threads and cleanup the environment */
void ritStop(int rc);
 
void CONSOLE(const char* message, ...);
 
// Global variables for CICS agent
CICSRegistration* g_reg = NULL;
ServerPoller* g_serverPoller = NULL;
SockServer* g_sockSvr = NULL;
UserParm* g_userparm = NULL;
pthread_mutex_t g_log_mutex;
pthread_mutexattr_t g_mutex_attr;
pthread_t IPT;
int g_stop = 0;
int g_switch_log_num = 0;
char g_hostname[_POSIX_HOST_NAME_MAX];
 
char g_rit_fn[32] = "";  // path name for file "/tmp/rit_applid"
int g_fd = -1;  // mark the clear flag for file "/tmp/rit_applid"
 
void setupSignalHandler() {
    struct sigaction info, siginthdlr, sigpipeHdlr, sigusr1hdlr, sigusr2hdlr, sigioerrhdlr;
    // for SIGINT
    siginthdlr.sa_handler = &sig_int;
    sigemptyset(&(siginthdlr.sa_mask));
    siginthdlr.sa_flags = 0;
    if (sigaction(SIGINT, &siginthdlr, &info) != 0) {
        FPRINTF(stdout, "Set handler failed for SIGINT.\n");  //$NON-NLS-1$
    }
    // for SIGPIPE
    sigpipeHdlr.sa_handler = &sig_pipe;
    sigemptyset(&(sigpipeHdlr.sa_mask));
    sigpipeHdlr.sa_flags = 0;
    if (sigaction(SIGPIPE, &sigpipeHdlr, &info) != 0) {
        FPRINTF(stdout, "Set handler failed for SIGPIPE.\n");  //$NON-NLS-1$
    }
    // for SIGUSR1
    sigusr1hdlr.sa_handler = &sig_usr1;
    sigemptyset(&(sigusr1hdlr.sa_mask));
    sigusr1hdlr.sa_flags = 0;
    if (sigaction(SIGUSR1, &sigusr1hdlr, &info) != 0) {
        FPRINTF(stdout, "Set handler failed for SIGUSR1.\n");  //$NON-NLS-1$
    }
    // for SIGUSR2
    sigusr2hdlr.sa_handler = &sig_usr2;
    sigemptyset(&(sigusr2hdlr.sa_mask));
    sigusr2hdlr.sa_flags = 0;
    if (sigaction(SIGUSR2, &sigusr2hdlr, &info) != 0) {
        FPRINTF(stdout, "Set handler failed for SIGUSR2.\n");  //$NON-NLS-1$
    }
    // for SIGIOERR
    sigioerrhdlr.sa_handler = &sig_ioerr;
    sigemptyset(&(sigioerrhdlr.sa_mask));
    sigioerrhdlr.sa_flags = 0;
    if (sigaction(SIGIOERR, &sigioerrhdlr, &info) != 0) {
        FPRINTF(stdout, "Set handler failed for SIGIOERR.\n");  //$NON-NLS-1$
    } else {
    }
}
/*
#include <stdio.h>
#include <stdarg.h>
int FPRINTF(FILE *stream, const char *format, ...) {
    va_list args;
    va_start(args, format);
    int ret = vfprintf(stream, format, args);  // call standard fprintf
    va_end(args);
    return ret;
}*/
 
int main(int argc, char** argv) {
    google::protobuf::LogSilencer _protobuf_silencer;
    CICSAgentConfig config;
    memset(&config, 0, sizeof(config));
    int rc = 0;
// handle parameters
    if ((rc = parseParams(argc, argv, config)) != 0) {
        return (rc);
    }
 
    rc = atexit(rit_exit);
    if (rc != 0) {
        FPRINTF(stdout, "Error in atexit.\n");  //$NON-NLS-1$
    }
 
    if (pthread_mutexattr_init(&g_mutex_attr) != 0) {
        FPRINTF(stdout, "pthread_mutex_attr_init() error.\n");
        exit(1);
    }
    if (pthread_mutexattr_setkind_np(&g_mutex_attr, __MUTEX_NONRECURSIVE)
            != 0) {
        FPRINTF(stdout, "pthread_mutex_attr_setkind_np() error.\n");
        exit(2);
    }
    if (pthread_mutex_init(&g_log_mutex, &g_mutex_attr) != 0) {
        FPRINTF(stdout, "mutex_init error.\n");
    }
 
    setupSignalHandler();
 
    IPT = pthread_self();
    FPRINTF(stdout, "Main thread id is %X.\n", IPT);
 
    LoggerFactory* loggerFactory =LoggerFactory::getInstance();
 
    g_reg = CICSRegistration::instance(&config);
    if (g_reg == NULL) {
        FPRINTF(stdout, "g_reg is NULL.\n");
        exit(-1);
    }
    loggerFactory->setLogLevel(g_reg->logLevel());
 
    Logger* g_logger = loggerFactory->getLogger("HRVCCICS");  //$NON-NLS-1$
 
    g_logger->info(
      "\n>>>>>>>>>>>>>>>>----RITAGENT is starting----<<<<<<<<<<<<<<<<\n");
    g_logger->info("HRVCCICS version: %s build: %s",
      RIT_CICS_AGENT_VERSION, RIT_CICS_AGENT_BUILDLVL);
 
 
    string startInfo;
    getStartInfo(startInfo);
 
    g_logger->info(startInfo);
 
 
    CURLcode res = curl_global_init(CURL_GLOBAL_ALL);
    if (res != CURLE_OK) {
        g_logger->error("curl_global_init failed: rc = %d", res);  //$NON-NLS-1$
        return (res);
    }
 
//setup console command handling
    UserParm userParm;
    g_userparm = &userParm;
    memset(g_userparm, '\0', sizeof(UserParm)); /* clear it  */
    g_userparm->ACANCECB = &g_userparm->CANCLECB;
    g_userparm->AIOERECB = &g_userparm->IOERRECB;
 
    if (g_reg->logLevel()
            == ::greenhat::vie::comms::proxy::LogEvent_Level_DEBUG) {
        CONSOLE( "HRVCCICS setup ECB");  //
    }
    g_logger->debug("HRVCCICS setup ECB");  //$NON-NLS-1$
    rc = setupmod(g_userparm);
    if (g_reg->logLevel()
            == ::greenhat::vie::comms::proxy::LogEvent_Level_DEBUG) {
        CONSOLE("HRVCCICS got AMODECB=0x%8.8X", g_userparm->AMODECB);
    }
    g_logger->debug("HRVCCICS got AMODECB=0x%8.8X", g_userparm->AMODECB);
    if (rc != 0) {
        return (rc);
    }
    CONSOLE("HRVCCICS: Version %s Build %s.",  //$NON-NLS-1$
            RIT_CICS_AGENT_VERSION, RIT_CICS_AGENT_BUILDLVL);
    CONSOLE("HRVCCICS is starting.");  //$NON-NLS-1$
 
//enable the CICS exit
    int connCnt = 0;
    int status = 0;
    while (status != RIT_ENABLE_CMD && connCnt < config.exciMaxErrnum_) {
        connCnt++;
        status = enableRit(g_reg, g_logger, RIT_ENABLE_CMD);
        if (status == RIT_ENABLE_CMD) {
            CONSOLE( "HRVCCICS EXIT is now %s.",  //$NON-NLS-1$
                    status == RIT_ENABLE_CMD ? "enabled" : "disabled"); //$NON-NLS-1$
            break; // test passed, exit while
        } else {
            // exit when enable the exit failed, need to check the error message in log
            CONSOLE( "Enable CICS exit unsuccessfully %d time(s)",
                    connCnt); //$NON-NLS-1$
            sleep(RIT_EXCI_RETRY_INTERVAL);
        }
    }
 
    if (status != RIT_ENABLE_CMD) {
        // exit when enable the exit failed,
        // need to check the error message in g_logger
        ritStop(16);
    }
 
// start CICS agent for the worker threads
    ServerPoller* g_serverPoller = ServerPoller::instance(g_reg);
    g_serverPoller->start();
 
    sleep(1);
 
    SockServer* g_sockSvr = SockServer::instance(g_reg);
    g_sockSvr->start();
 
//try connect to RITAgent from the CICS program RITMNGRC
    connCnt = 0;
    sleep(1);  // Wait 1 seconds to allow the other threads ready
    while (status != RIT_TESTCONN_CMD && connCnt < config.exciMaxErrnum_) {
        connCnt++;
        status = enableRit(g_reg, g_logger, RIT_TESTCONN_CMD);
        if (status == RIT_TESTCONN_CMD) {
            CONSOLE(
                    "Connect successfully from CICS region to RITAGENT.\n");
            CONSOLE(
                    "RITAGENT is running in intercepting status.\n"); //$NON-NLS-1$
            break; // test passed, exit while
        } else {
            // exit when enable the exit failed, need to check the error message in log
            CONSOLE(
                    "Connect from CICS region to RITAGENT unsuccessfully %d time(s)",
                    connCnt); //$NON-NLS-1$
            sleep(RIT_EXCI_RETRY_INTERVAL);
        }
    }
    if (status != RIT_TESTCONN_CMD) {
        // exit when connect from CICS program to RITAGENT failed
        // need to check the error message in log
        ritStop(16);
    }
 
    char cmdBuffer[RIT_COMMAND_MAX_SIZE] = { 0 };
    while (g_stop == 0) {
        g_userparm->CANCLECB = 1;
        g_userparm->IOERRECB = 2;
        g_userparm->ACANCECB = &g_userparm->CANCLECB;
        g_userparm->AIOERECB = &g_userparm->IOERRECB;
        /* QEDIT ECB - when an operator stop or modify command    */
        /*        has been issued                                 */
        /* Cancel  ECB if we were cancelled                       */
        /* The ECB list has the top bit on in the last entry      */
        /* to indicate last ECB in the list                       */
        int * ECBLIST[3];
        memcpy(&ECBLIST[0], &g_userparm->AMODECB, 4);
        memcpy(&ECBLIST[1], &g_userparm->AIOERECB, 4);
        memcpy(&ECBLIST[2], &g_userparm->ACANCECB, 4);
        /* set high bit on to indicate end of ECB list */
        ECBLIST[2] = (int *) (0x80000000 | (int) ECBLIST[2]);
        /* now wait for console request or signal request */
        rc = ritwait((int*) &ECBLIST);
 
        int lQEDIT = 0;
        int lCancel = 0;
        int lIoerr = 0;
        /* check the wait bit                                     */
        lQEDIT = *(g_userparm->AMODECB) >> 30;
        lCancel = g_userparm->CANCLECB >> 30;
        lIoerr = g_userparm->IOERRECB >> 30;
        /* if the ECB that was posted was signaling that there is */
        /* an I/O error writing to the log, don't try logging.    */
        if (lIoerr == 0) {
            g_logger->debug("ritwait retcode = %d", rc);
            g_logger->debug("CONECB<%8.8x> IOECB<%8.8x> CANECB<%8.8x>",
                    *(g_userparm->AMODECB), g_userparm->IOERRECB,
                    g_userparm->CANCLECB);
            g_logger->debug("lQEDIT=%8.8x lCancel=%8.8x lIoerr=%8.8x", lQEDIT,
                    lCancel, lIoerr);
        }
        /* if something wrong and need to stop                    */
        if (lCancel > 0) {
            time64_t ltime;
            time64(&ltime);
            CONSOLE("Got cancel signal at time:%s",    //$NON-NLS-1$
                    ctime64(&ltime));
            g_stop = 1;
        } else if (lQEDIT > 0) {
            /* if cancel/stop was posted                              */
            rc = checkmod(g_userparm, &g_userparm->FLAG,
                    (char*) g_userparm->COMMAND);
            const char* pData = g_userparm->COMMAND;
            string cmd;
            int rc = ebc2asc(pData, cmd);
            if (rc != 0) {
                g_logger->error("asc2ebc for modify command error, rc=%d", rc); //$NON-NLS-1$
            }
            int flag = g_userparm->FLAG;
            cmd = upperString(cmd);
            pData = cmd.c_str();
            switch (flag) {
            case (0x04): {
                g_logger->debug("Start Command:%s.", pData);       //$NON-NLS-1$
            }
                break;
            case (0x44): {
                g_logger->debug("Operator Modify Command:%s.", pData); //$NON-NLS-1$
                int lCommand = strlen(pData);
                if (lCommand < 4) {
                    g_logger->warn("Unknown command %s", pData);   //$NON-NLS-1$
 
                    CONSOLE( "Invalid command:%s,"      //$NON-NLS-1$
                                    " supported modify command is STOP and REFR",//$NON-NLS-1$
                    pData);
                } else if (strcmp(pData, "STOP") == 0) {        //$NON-NLS-1$
 
                    g_stop = 1;/* indicate we got stop */
                    //disable the CICS exit
                    int status = enableRit(g_reg, g_logger, RIT_DISABLE_CMD);
                    CONSOLE( "HRVCCICS EXIT is now %s.", //$NON-NLS-1$
                            status == RIT_DISABLE_CMD ? "disabled" : "enabled"); //$NON-NLS-1$
 
                } else if (strncmp(pData, "REFR", 4) == 0) {       //$NON-NLS-1$
                    CONSOLE( "HRVCCICS is refreshing the log."); //$NON-NLS-1$
 
                    loggerFactory->flush();
                } else { //Invalid command
                    CONSOLE( "Invalid command:%s," //$NON-NLS-1$
                                    " supported modify command is STOP and REFR",//$NON-NLS-1$
                    pData);
                }
            }
                break;
            case (0x40): {
 
                g_logger->debug("Operator STOP Command:%s", pData); //$NON-NLS-1$
                g_stop = 1;/* we got stop */
                //disable the CICS exit
                int status = enableRit(g_reg, g_logger, RIT_DISABLE_CMD);
                CONSOLE( "HRVCCICS EXIT is now %s.", //$NON-NLS-1$
                        status == RIT_DISABLE_CMD ? "disabled" : "enabled"); //$NON-NLS-1$
 
            }
                break;
            default:
                g_logger->debug("Unknown Command:%s", pData); //$NON-NLS-1$
                break;
            } // switch
        } else if (lIoerr > 0) {
            loggerFactory->firstAppenderGetNextAvailableFile();
        } // end if lCancel/lIoerr/lQEDIT
    } //end of while, main loop
// we got here after stop flag is 1
    ritStop(0);
    return 0;
}
/*
 * stop all the threads and cleanup the environment
 */
void ritStop(int rc) {
    CONSOLE("HRVCCICS is stopping. Please wait.");    //$NON-NLS-1$
    Logger* g_logger=LoggerFactory::getInstance()->getLogger("HRVCCiCS");
    g_logger->info("HRVCCICS is exiting.");    //$NON-NLS-1$
// disable the CICS exit
    if (g_reg->status() != RIT_DISABLE_CMD) {
        int status = enableRit(g_reg, g_logger, RIT_DISABLE_CMD);
        CONSOLE("HRVCCICS EXIT is now %s.",    //$NON-NLS-1$
                status == RIT_DISABLE_CMD ? "disabled" : "enabled"); //$NON-NLS-1$
    }
    if (g_serverPoller) {
        g_serverPoller->stop();
    }
    if (g_sockSvr) {
        g_sockSvr->stop(1);
    }
 
    LoggerFactory::destroy();
    DELETE(g_serverPoller);
    DELETE(g_sockSvr);
    DELETE(g_reg);
    DELETE(g_userparm);
 
    curl_global_cleanup();
 
    if (pthread_mutex_destroy(&g_log_mutex) != 0) {
        FPRINTF(stdout, "pthread_mutex_destroy() error.\n");
    }
 
    if (g_fd != -1) {
        if (unlink(g_rit_fn) != 0) {
            FPRINTF(stdout, "unlink failed with errno=%d.\n", errno); //$NON-NLS-1$
        } else {
            g_fd = -1;
        }
    }
 
    exit(rc);
}
int  transno = 1;
bool rtcp_server = true;  // default = true
void updateRtcpFlag(const std::string& url) {
    if (url.empty()) {
        rtcp_server = true;
        return;
    }
    std::string lower = url;
    std::transform(lower.begin(), lower.end(), lower.begin(),
::tolower);
    // "test" ? false (highest priority)
    if (lower.find("test") != std::string::npos) {
        rtcp_server = false;
        return;
    }
        // "rtcp" ? true
        if (lower.find("rtcp") != std::string::npos) {
            rtcp_server = true;
            return;
        }
        // default
        rtcp_server = true;
    }
 
// system will try to read SYSIN DD and override values specified in args;
int parseParams(int argc, char** argv, CICSAgentConfig& config) {
    int rc;
    Parms parms;
    parms.parseArgs(argc, argv);
 
    //read SYSINDD
    string buffer;
    ifstream sysinDD("DD:SYSCTL");
 
    if (sysinDD) {
        queue<string> tokens;
        string token;
        string crvtBuffer;
        stringstream bufferStream;
        while (sysinDD.good()) {
            getline(sysinDD, crvtBuffer);
            stringstream ss(crvtBuffer);
            std::string word;
            while (ss >> word) {
            tokens.push(word);
       //   ebc2asc(crvtBuffer,token);
       //   bufferStream << token + ' ';
       //   while (bufferStream >> token) {
       //       tokens.push(token);
            }
        }
        sysinDD.close();
        parms.parseParms(tokens);
    } else {
        FPRINTF(stdout, "SYSIN DD is not opened and args are in effect.\n"); //$NON-NLS-1$
    }
 
    config.applid_ = parms.getOptionValue("APPLID");
    config.bindaddr_ = parms.getOptionValue("BINDADDR");
    config.port_ = atoi(parms.getOptionValue("PORT").c_str());
    config.server_url_ = parms.getOptionValue("RTCPURL");
 //CHANGE
    updateRtcpFlag(config.server_url_);
    FPRINTF(stdout, "RTCP Flag: %s\n", rtcp_server ? "true" : "false");  //$NON-NLS-1$
 
    if (config.port_ < 1 || config.port_ > MAX_PORT_NUMBER) {
        FPRINTF(stdout, "Port must be between 0 and 65535!\n"); //$NON-NLS-1$
        return -1;
    }
 
    int len = config.applid_.length();
    if (len < 1 || len > MAX_APPLID_LEN) {
        FPRINTF(stdout, "APPLID length must be between 1 and 8!\n"); //$NON-NLS-1$
        return -1;
    }
 
    size_t pos = config.server_url_.find_first_of("http"); //$NON-NLS-1$
 
    if (pos != 0) {
        FPRINTF(stdout, "RTCPURL must begin with \"http\" !\n"); //$NON-NLS-1$
        return -1;
    }
    string loglevl = parms.getOptionValue("LOGLEVEL");
    if (loglevl.length() > 0) {
        int level = atoi(loglevl.c_str());
        if (level < ::greenhat::vie::comms::proxy::LogEvent_Level_DEBUG) {
            level = ::greenhat::vie::comms::proxy::LogEvent_Level_DEBUG;
        } else if (level
                > ::greenhat::vie::comms::proxy::LogEvent_Level_ERROR) {
            level = ::greenhat::vie::comms::proxy::LogEvent_Level_ERROR;
        }
        config.loglevel_ =
                (::greenhat::vie::comms::proxy::LogEvent_Level) level;
    } else {
        config.loglevel_ = ::greenhat::vie::comms::proxy::LogEvent_Level_INFO;
    }
 
    string observlevl = parms.getOptionValue("OBSERVATIONLEVEL");
    if (observlevl.length() > 0) {
        config.observ_ = (RIT_OBSERV_LEVEL) atoi(observlevl.c_str());
    } else {
        config.observ_ = LEVEL_RESOURCES;
    }
 
    string keyring = parms.getOptionValue("KEYRING");
    if (keyring.length() > 0) {
        config.gsk_keyring_ring_ = keyring;
        char useridBuffer[LOGIN_NAME_MAX];
        std::fill(&useridBuffer[0], &useridBuffer[LOGIN_NAME_MAX - 2], ' ');
        useridBuffer[LOGIN_NAME_MAX - 1] = '\0';
        if (__getuserid(useridBuffer, sizeof(useridBuffer)) == 0) {
            string useridEdc = useridBuffer;
        //  string userid;
        //  ebc2asc(useridEdc, userid);
            string userid = useridEdc ;
            userid.append("/");
            config.gsk_keyring_ring_ = userid + config.gsk_keyring_ring_;
        }
    } else if (config.server_url_.find("https") == 0) {
        FPRINTF(stdout,
                "KEYRING must be defined when RTCPURL starts with \"https\".\n"); //$NON-NLS-1$
        return -1;
    } else {
        config.gsk_keyring_ring_ = "";
    }
 
    char* envvar = NULL;
    envvar = getenv("RTCP_MAX_ERRNUM");
    if (envvar) {
        config.rtcpMaxErrnum_ = atoi(envvar);
        FPRINTF(stdout, "Getenv RTCP_MAX_ERRNUM=%s\n", envvar); //$NON-NLS-1$
    }
    if (config.rtcpMaxErrnum_ <= 1) {
        config.rtcpMaxErrnum_ = RTCP_MAX_ERROR_COUNT;
    }
 
    envvar = getenv("EXCI_MAX_ERRNUM");
    if (envvar) {
        config.exciMaxErrnum_ = atoi(envvar);
        FPRINTF(stdout, "Getenv EXCI_MAX_ERRNUM=%s\n", envvar); //$NON-NLS-1$
    }
    if (config.exciMaxErrnum_ <= 1) {
        config.exciMaxErrnum_ = EXCI_MAX_ERROR_COUNT;
    }
 
    envvar = getenv("DEBUG_STUB_CA");
    if (envvar) {
        config.debugStubCA_ = atoi(envvar);
        FPRINTF(stdout, "Getenv DEBUG_STUB_CA=%s\n", envvar); //$NON-NLS-1$
    } else {
        config.debugStubCA_ = 0;
    }
 
    char strLogLevel[16] = { 0 };
    switch (config.loglevel_) {
//case greenhat::vie::comms::proxy::LogEvent_Level_TRACE:
    case greenhat::vie::comms::proxy::LogEvent_Level_DEBUG:
        strcpy(strLogLevel, RIT_LogEvent_Level_DEBUG);
        break;
    case greenhat::vie::comms::proxy::LogEvent_Level_WARN:
        strcpy(strLogLevel, RIT_LogEvent_Level_WARN);
        break;
    case greenhat::vie::comms::proxy::LogEvent_Level_ERROR:
        strcpy(strLogLevel, RIT_LogEvent_Level_ERROR);
        break;
    case greenhat::vie::comms::proxy::LogEvent_Level_INFO:
    default:
        strcpy(strLogLevel, RIT_LogEvent_Level_INFO);
        break;
    }
 
    char strObservLevel[32] = { 0 };
    switch (config.observ_) {
    case LEVEL_ALL:
        strcpy(strObservLevel, RIT_OBSERV_LEVEL_ALL);
        break;
    case LEVEL_RESOURCES:
        strcpy(strObservLevel, RIT_OBSERV_LEVEL_RESOURCE);
        break;
    case LEVEL_NONE:
        strcpy(strObservLevel, RIT_OBSERV_LEVEL_NONE);
        break;
    case LEVEL_STATISTICS:
    default:
        strcpy(strObservLevel, RIT_OBSERV_LEVEL_STATISTICS);
        break;
    }
 
    FPRINTF(stdout,
            "HRVCCICS agent is starting.\n" //$NON-NLS-1$
                    "Applid: %s\n"//$NON-NLS-1$
                    "BindAddr: %s\n"//$NON-NLS-1$
                    "Port: %d\n"//$NON-NLS-1$
                    "Server_url: %s\n"//$NON-NLS-1$
                    "LogLevel: %s\n"//$NON-NLS-1$
                    "ObservationLevel: %s\n"//$NON-NLS-1$
                    "KeyRingName: %s\n",//$NON-NLS-1$
            config.applid_.c_str(), config.bindaddr_.c_str(), config.port_,
            config.server_url_.c_str(), strLogLevel, strObservLevel,
            config.gsk_keyring_ring_.c_str());
 
    if ((rc = checkBindAddr(config)) != 0) {
        return rc;
    }
 
    string ritFlag(RIT_CICS_TMP_PATH);
    ritFlag.append(config.applid_);
 
    strncpy(g_rit_fn, ritFlag.c_str(), 30);
 
    g_fd = open(g_rit_fn, O_RDWR | O_CREAT | O_EXCL, S_IRWXU);
    if (g_fd == -1) {
        if (errno == EEXIST) {
            g_fd = open(g_rit_fn, O_RDWR, S_IRWXU);
            if (g_fd == -1) {
                FPRINTF(stdout, "open() failed with errno=%d.\n", errno); //$NON-NLS-1$
            } else {
                char buf[_POSIX_HOST_NAME_MAX] = { 0 };
                if ((rc = lseek(g_fd, 0, SEEK_SET)) < 0) {
                    FPRINTF(stdout, "lseek error with errno=%d.\n", errno);
                } else if ((rc = read(g_fd, buf, strlen(g_hostname))) > 0) {
                    buf[rc] = 0;					
                    string lhostname(g_hostname);					
                    string lhost(buf);					
                    lowerString(lhostname);					              					                      					                    					                                                                                                     
                    string lowstr;
                    asc2ebc(lhost,lowstr);
                    lowerString(lowstr);
                    if (strncmp(lhostname.c_str(), lowstr.c_str(),
                       strlen(g_hostname)) == 0) {
                       //   strlen(g_hostname)) == NULL) {						   
                       // run hostname is same with the current hostname
                        if (lockf(g_fd, F_TLOCK, 0) == 0) {
                            return 0;
                        } else {
                            FPRINTF(stdout, "lockf failed with errno=%d.\n",
                                    errno); //$NON-NLS-1$
                        }
                    } else {
                    lowerString(lhost); 
                 //  FPRINTF(stdout, "lowstr=%s.\n",                 
                 //  lhost.c_str());
                    if (strncmp(lhostname.c_str(), lhost.c_str(),
                       strlen(g_hostname)) == 0) {
                       //   strlen(g_hostname)) == NULL) {						   
                       // run hostname is same with the current hostname
                        if (lockf(g_fd, F_TLOCK, 0) == 0) {
                            return 0;
                        } else {
                            FPRINTF(stdout, "lockf failed with errno=%d.\n",
                                    errno); //$NON-NLS-1$
                        }
                    }
                    }
                    // previous hostname is different with the current hostname
                    FPRINTF(stdout,
                            "RITAGNET for APPLID %s is already running in %s.\n" //$NON-NLS-1$
                                    "Please stop the previous instance before run again.\n"//$NON-NLS-1$
                            , config.applid_.c_str(), buf);
                    return -1;
                } else {
                    FPRINTF(stdout, "read() failed with rc=%d, errno=%d.\n", rc,
                            errno); //$NON-NLS-1$
                }
            }
 
            // previous hostname is different with the current hostname
            FPRINTF(stdout, "RITAGNET for APPLID %s is already running.\n" //$NON-NLS-1$
                            "Please stop the previous instance before run again.\n"//$NON-NLS-1$
            , config.applid_.c_str());
 
            FPRINTF(stdout, "If you are sure there is no RITAGENT running,\n" //$NON-NLS-1$
                            "please remove the file by 'rm %s' and try again.\n"//$NON-NLS-1$
            , g_rit_fn);
 
            return -1;
        } else {
            FPRINTF(stdout, "open() failed with errno=%d.\n", errno); //$NON-NLS-1$
            return -1;
        }
    } else {
        if (lockf(g_fd, F_LOCK, 0) == -1) {
            FPRINTF(stdout, "lockf failed with errno=%d.\n", errno); //$NON-NLS-1$
            return -1;
        } else {
            if ((rc = write(g_fd, g_hostname, _POSIX_HOST_NAME_MAX)) == -1) {
                FPRINTF(stdout, "write() error.\n");
            }
        }
    }
 
    return 0;
}
 
string & getStartInfo(string & startInfo) {
    char buff[512] = { 0 };
    snprintf(buff, 512,
            "HRVCCICS agent is starting.\n" //$NON-NLS-1$
                    "Applid: %s\n"//$NON-NLS-1$
                    "BindAddr: %s\n"//$NON-NLS-1$
                    "Port: %d\n"//$NON-NLS-1$
                    "Server_url: %s\n"//$NON-NLS-1$
                    "LogLevel: %d\n"//$NON-NLS-1$
                    "ObservationLevel: %d\n"//$NON-NLS-1$
                    "KeyRingName: %s\n",//$NON-NLS-1$
            g_reg->applid().c_str(), g_reg->bindAddr().c_str(), g_reg->port(),
            g_reg->serverUrl().c_str(), g_reg->logLevel(), g_reg->observLevel(),
            g_reg->gsk_keyring_ring().c_str());
    startInfo.assign(buff);
    return startInfo;
}
 
int checkBindAddr(CICSAgentConfig& config) {
    struct addrinfo hints;
    struct addrinfo *result, *localhost;
    int rc;
 
    char* envvar = NULL;
    envvar = getenv("RIT_FORCE_USE_BINDADDR");
    if (envvar) {
        FPRINTF(stdout, "Getenv RIT_FORCE_USE_BINDADDR=%s\n", envvar); //$NON-NLS-1$
        if (strcmp(envvar, "YES") == 0 || strcmp(envvar, "Y") == 0) {
 
            memset(&hints, 0, sizeof(struct addrinfo));
            hints.ai_family = AF_UNSPEC; /* Allow IPv4 and IPv6) */
            hints.ai_socktype = SOCK_STREAM;
            hints.ai_flags = AI_CANONNAME | AI_PASSIVE;
 
            rc = getaddrinfo(config.bindaddr_.c_str(), NULL, &hints, &result);
            if (rc == 0 && result->ai_canonname) {
                config.hostname_ = result->ai_canonname;
                FPRINTF(stdout, "RITAGENT will use the BINDADDR anyway.\n"); //$NON-NLS-1$
                FPRINTF(stdout, "Set RITAGENT hostname to '%s'.\n",
                        config.hostname_.c_str());
                freeaddrinfo(result);
                return 0;
            } else {
                FPRINTF(stdout,
                        "HRVCCICS look up bind address getaddrinfo: %s\n",
                        gai_strerror(rc));
            }
        }
    } // end if(envvar)
 
//default action is to set the bind address to hostname.
    if (gethostname(g_hostname, _POSIX_HOST_NAME_MAX)) {
        FPRINTF(stdout, "HRVCCICS gethostname error, errno=%d.\n", errno); //$NON-NLS-1$
        config.hostname_ = config.bindaddr_;
        return -1;
    } else {
        FPRINTF(stdout, "HRVCCICS got running short host name:'%s'.\n",
                g_hostname);
    }
 
    memset(&hints, 0, sizeof(struct addrinfo));
    hints.ai_family = AF_UNSPEC; /* Allow IPv4 and IPv6) */
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_CANONNAME | AI_PASSIVE;
    rc = getaddrinfo(g_hostname, NULL, &hints, &result);
    if (rc == 0 && result->ai_canonname) {
        config.hostname_ = result->ai_canonname;
        FPRINTF(stdout, "Set RITAGENT hostname to '%s'.\n",
                config.hostname_.c_str());
        string ipadr;
        ebc2asc(result->ai_canonname,ipadr);
        config.hostname_ = ipadr;
        freeaddrinfo(result);
        return 0;
    } else {
        if (rc == 0) {
            freeaddrinfo(result);
        }
        FPRINTF(stdout, "HRVCCICS getaddrinfo: %s\n", gai_strerror(rc));
        config.hostname_ = config.bindaddr_;
        FPRINTF(stdout, "Set RITAGENT hostname to '%s'.\n",
                config.hostname_.c_str()); //$NON-NLS-1$
        return -1;
    }
}
 
extern "C" void sig_int(int signo) {
    if (g_stop == 0) {
        LoggerFactory::getInstance()->getLogger("HRVCCiCS")->debug("Caught signal SIGINT"); //$NON-NLS-1$
        ritpost(&g_userparm->CANCLECB);
    }
}
 
extern "C" void sig_ioerr(int signo) {
    if (g_stop != 0)
        return;
    pthread_t thid = pthread_self();
    FPRINTF(stdout, "I/O error signal %d received in thread id %X.\n", signo, thid);
    FPRINTF(stdout, "errno=%d (%s)\n", errno, strerror(errno));
    if (pthread_mutex_trylock(&g_log_mutex) != 0) {
        if (errno == EAGAIN) {
            FPRINTF(stdout,
                    "The mutex could not be acquired because the maximum number of recursive locks for mutex has been exceeded.\n");
        } else if (errno == EBUSY) {
            FPRINTF(stdout,
                    "The mutex could not be acquired because it was already locked.\n");
        } else {
            FPRINTF(stdout,
                    "Call pthread_mutex_trylock failed with errno=%d.\n",
                    errno);
        }
        return; // other thread may already in this handler
    }
    FPRINTF(stdout, "A generic I/O error occurred. Details unavailable on this platform.\n");
 
        if (g_reg->status() > 1) { // main thread already in ritwait
            ritpost(g_userparm->AIOERECB); // to notify main thread
        } else {
            //should be before ritwait
            //we just wait to main thread to get ready and retry log again
            //do nothing this time.
        }
 
        if (pthread_mutex_unlock(&g_log_mutex) != 0) {
            FPRINTF(stdout, "pthread_mutex_unlock() error.\n");
            exit(2);
        }
    } // B37+D37+E37
 
extern "C" void sig_usr1(int signo) {
    if (g_stop == 0) {
        pthread_t thid = pthread_self();
        FPRINTF(stdout, "Caught signal SIGUSR1 in thread: %X.\n", thid); //$NON-NLS-1$
        LoggerFactory::getInstance()->getLogger("HRVCCICS")->
                debug("Caught signal SIGUSR1 in thread: %X.\n", thid); //$NON-NLS-1$
    }
}
 
extern "C" void sig_usr2(int signo) {
    if (g_stop == 0) {
        pthread_t thid = pthread_self();
        FPRINTF(stdout, "Caught signal SIGUSR2 in thread: %X.\n", thid); //$NON-NLS-1$
        LoggerFactory::getInstance()->getLogger("HRVCCICS")->
                debug("Caught signal SIGUSR2 in thread: %X.\n", thid); //$NON-NLS-1$
    }
    ritpost(&g_userparm->CANCLECB);
}
 
extern "C" void sig_pipe(int /* signo */) {
    if (g_stop == 0) {
        pthread_t thid = pthread_self();
        FPRINTF(stdout, "Caught signal SIGPIPE in thread: %X.\n", thid); //$NON-NLS-1$
        Logger* g_logger =LoggerFactory::getInstance()->getLogger("HRVCCiCS");
        g_logger->debug("Caught signal SIGPIPE in thread: %X.\n", thid); //$NON-NLS-1$
    }
}
 
extern "C" void rit_exit(void) {
    FPRINTF(stdout, "HRVCCICS exits.\n"); //$NON-NLS-1$
    if (g_fd != -1) {
        if (unlink(g_rit_fn) != 0) {
            FPRINTF(stdout, "unlink failed with errno=%d.\n", errno); //$NON-NLS-1$
        } else {
            //FPRINTF(stdout, "unlink file %s.\n", g_rit_fn); //$NON-NLS-1$
            g_fd = -1;
        }
    }
}
 
void CONSOLE(const char* message, ...) {
    Wto wto;
    /* we need to process a variable number of parameters
     * passed to messages */
    va_list args;
    va_start(args, message);
    vsnprintf(&wto.buffer[0], sizeof(wto.buffer), message, args);
    va_end(args);
 
    wto.lWTO = strlen(wto.buffer);
 // string ebcmsg;
    string ebcmsg = wto.buffer;
 // int rc = asc2ebc(wto.buffer, ebcmsg);
 // if (rc != 0) {
 //     FPRINTF(stdout, "asc2ebc for wtomsg error, rc=%d.\n", rc); //$NON-NLS-1$
 // }
    strncpy(wto.buffer, ebcmsg.c_str(), wto.lWTO);
    /* and issue the message itself                                 */
    wtovlen(wto);
}
 
/* the end */
