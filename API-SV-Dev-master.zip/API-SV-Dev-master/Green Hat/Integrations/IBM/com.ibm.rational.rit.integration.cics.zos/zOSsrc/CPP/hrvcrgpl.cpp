/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017.All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*******************************************************************************
 * regpoll.cpp
 * Class RegisterPoller:
 * 1> send registration message to RTCP every 30 seconds
 * 2> send enable message to CICS region after got the UUID from RTCP
 ******************************************************************************/
#pragma csect (CODE,"HRVCRGPL")
#include "regpoll.h"
#include "svrpoll.h"
#include "objxfer.h"
#include "ritlog.h"
#include "ritutil.h"
#include <pthread.h>
#include <signal.h>
#include <errno.h>
#include "rtcpset.h"
 
//#define DEBUG_REGPOLL 1
 
#define REGISTRATION_PATH       "rest/proxy/register" //$NON-NLS-1$
#define REGISTRATION_PATH_TH    "rest/spaces/Initial/virtualization/register"
 
using namespace std;
using namespace greenhat::vie::comms::proxy;
 
static void* regPollor(void * poller);
 
RegisterPoller* RegisterPoller::s_instance = NULL;
 
RegisterPoller* RegisterPoller::instance(CICSRegistration* reg){
    if(s_instance == NULL){
        s_instance = new RegisterPoller(reg);
    }
    return s_instance;
}
 
RegisterPoller::RegisterPoller(CICSRegistration* reg) :
    pReg_(reg), stop_(0)
{
    log_ = LoggerFactory::getInstance()->getLogger("RegisterPoller");//$NON-NLS-1$
 
    string username,version,name,os,ctg;
    ebc2asc(RIT_CICS_AGENT_USERNAME,username);
    ebc2asc(RIT_CICS_AGENT_VERSION,version);
    ebc2asc(reg->applid(),name);
    ebc2asc(RIT_CICS_AGENT_OS,os);
 
    reg_.set_host(reg->hostname());
 // reg_.set_username(RIT_CICS_AGENT_USERNAME);
    reg_.set_username(username);
 // reg_.set_version(RIT_CICS_AGENT_VERSION);
    reg_.set_version(version);
    reg_.set_type(CTG);
 // reg_.set_name(reg->applid());
    reg_.set_name(name);
 // reg_.set_osname(RIT_CICS_AGENT_OS);
    reg_.set_osname(os);
    reg_.set_initialobservationlevel(reg->observLevel());
    reg_.set_loglevel((::greenhat::vie::comms::proxy::LogEvent_Level)reg->logLevel());
 
    CTGRegistration* pctg = reg_.mutable_ctgregistration();
    pctg->set_recordingenabled(true);
    pctg->set_routingenabled(true);
    pctg->set_cicstype(CTGRegistration_CICSRegType_TS);
 
    int rc = pthread_rwlockattr_init(&rwlattr_);
    if (rc == -1) {
        log_->error("error in pthread_rwlockattr_init");//$NON-NLS-1$
        FPRINTF(stdout, "pthread_rwlockattr_init error, errno=%d. Exiting...\n",//$NON-NLS-1$
                errno);
        exit(EXIT_FAILURE);
    }
    rc = pthread_rwlockattr_setpshared(&rwlattr_, PTHREAD_PROCESS_PRIVATE);
    if (rc == -1) {
        log_->error("error in pthread_rwlockattr_setpshared");//$NON-NLS-1$
        FPRINTF(stdout,
                "pthread_rwlockattr_setpshared error, errno=%d. Exiting...\n",//$NON-NLS-1$
                errno);
        exit(EXIT_FAILURE);
    }
    rc = pthread_rwlock_init(&statuslock_, &rwlattr_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_init");//$NON-NLS-1$
        FPRINTF(stdout, "pthread_rwlock_init error, errno=%d. Exiting...\n",//$NON-NLS-1$
                errno);
        exit(EXIT_FAILURE);
    }
 
}
 
RegisterPoller::~RegisterPoller() {
    int i = getWaitTimeout();
    while(getStop() != 2 && i > 0){
        stop(1);
        i--;
        sleep(1);
    }
    if (pthread_rwlock_destroy(&statuslock_) == -1) {
        log_->error("error in pthread_rwlock_destroy loglvllock");//$NON-NLS-1$
    }
    if (pthread_rwlockattr_destroy(&rwlattr_) == -1) {
        log_->error("error in pthread_rwlockattr_destroy");//$NON-NLS-1$
    }
}
 
void RegisterPoller::start(pthread_attr_t* attr) {
    if (pthread_create(&thread_, attr, regPollor, (void*) this) != 0) {
        log_->error("pthread_create() error");//$NON-NLS-1$
    }
}
 
void RegisterPoller::stop(int status) {
    int rc = pthread_rwlock_wrlock(&statuslock_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_wrlock");//$NON-NLS-1$
    }
    stop_ = status;
    rc = pthread_rwlock_unlock(&statuslock_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_unlock");//$NON-NLS-1$
    }
    log_->info("RegisterPoller stopping ...\n");//$NON-NLS-1$
}
 
int RegisterPoller::getStop() {
    int rc = pthread_rwlock_rdlock(&statuslock_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_rdlock");//$NON-NLS-1$
    }
    int status = stop_;
    rc = pthread_rwlock_unlock(&statuslock_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_unlock");//$NON-NLS-1$
    }
    return status;
}
 
void* regPollor(void * poller) {
    RegisterPoller* pPoller = (RegisterPoller*) poller;
    CICSRegistration* cicsreg = pPoller->registration();
    Logger* log = pPoller->logger();
    //CHANGE
    string url;
    if (!rtcp_server) {
      url = cicsreg->serverUrl() + REGISTRATION_PATH_TH;
    }
    else {
      url = cicsreg->serverUrl() + REGISTRATION_PATH;
    }
 
    Registration* pReg = pPoller->getRegistration();
    Registration registration;
    ObjXfer xfer(url, cicsreg->gsk_keyring_ring());
    string id,idebc;
    bool bSetId = false;
    int count = 0;
    int errCntRTCP = 0;
    int maxErrCount = cicsreg->rtcpMaxErrnum();
    log->debug("Using RTCP maximum error count: %d.",
            maxErrCount);
    pthread_t thid = pthread_self();
    FPRINTF(stdout, "Register thread id is %X.\n", thid);
    log->info("Register thread id is %X.\n", thid);
    while (pPoller->getStop() == 0) {
        string uuid = cicsreg->uuid();
        if(bSetId == false || uuid.length() < UUID_LENGTH){
            registration.CopyFrom(*pReg);
            registration.set_id(id);
        }
        Registration* pMsg = xfer.postRegistration(&registration, log);
        if( NULL != pMsg){ // got valid registration object
            errCntRTCP = 0; // reset error count
            if (pMsg->has_id()) {
                id = pMsg->id();
#if DEBUG_REGPOLL
                FPRINTF(stdout, "Register Agent ID: %s\n", id.c_str());//$NON-NLS-1$
#endif // DEBUG_REGPOLL
 
                if((bSetId == false || uuid.length() < UUID_LENGTH) &&
                        id.length() == UUID_LENGTH ){
                    cicsreg->setId(id); // set agent id
                    asc2ebc(id,idebc);
                  //log->info("Set Agent ID: %s", id.c_str());//$NON-NLS-1$
                    log->info("Set Agent ID: %s", idebc.c_str());//$NON-NLS-1$
                    bSetId = true;
                }
            }
        } else {
            log->warn("Received null Registration," //$NON-NLS-1$
              " URL=%s", //$NON-NLS-1$
              url.c_str());
            errCntRTCP ++;
            cicsreg->setId("");
            bSetId = false;
            log->debug("Received registration failed %d times.",
                    errCntRTCP);
 
            if(errCntRTCP > maxErrCount){
                    log->error("Communication with RTCP failed.");//$NON-NLS-1$
//                    " HRVCCICS will exit now...");//$NON-NLS-1$
//                    log->debug("Raise SIGUSR1.");//$NON-NLS-1$
//                    raise(SIGUSR1);
            }
        }
        sleep(RegisterPoller::DEFAULT_REGISTRATION_POLL_INTERVAL);
    }
    pPoller->stop(2);
    pthread_exit(NULL);
    return NULL;
}
