/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017.All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
#pragma csect (CODE,"HRVCPROT")
#define OPEN_DEFAULT 1
#define OPEN_SYS_EXT 1
#define _LARGE_TIME_API 1
#define _OPEN_THREADS 3
#define  _XOPEN_SOURCE 600
#define _OPEN_SYS 1
#define _ISOC99_SROURCE 1
#define _XOPEN_SOURCE_EXTENDED 1
#define _POSIX_SOURCE 1
#define _POSIX_C_SOURCE 200112L
#define _OPEN_SYS_MUTEX_EXT 1
#define _OPEN_SYS_ITOA_EXT 1
#include "protocl.h"
#include "ritcomm.h"
#include <string>
 
ASCHeader::ASCHeader(const Header& header) {
    reqresp = header.reqresp;
    length = header.length;
    dataLength = header.dataLength;
    response = header.response;
 
    memset(progName, ' ', sizeof(progName));
    std::string sprogname;
    std::string eProgname(header.progName, sizeof(header.progName));
    ebc2asc(eProgname, sprogname);
    strncpy(progName, sprogname.c_str(), sizeof(progName));
    trimBlank(progName);
 
    memset(tranID, 0, sizeof(tranID));
    std::string stranid;
    std::string etranid(header.tranID, sizeof(header.tranID));
    ebc2asc(etranid, stranid);
    strncpy(tranID, stranid.c_str(), sizeof(tranID));
    trimBlank(tranID);
 
    memset(jobName, ' ', sizeof(jobName));
    std::string sjobname;
    std::string eJobname(header.jobName, sizeof(header.jobName));
    ebc2asc(eJobname, sjobname);
    strncpy(jobName, sjobname.c_str(), sizeof(jobName));
    trimBlank(jobName);
 
    memset(channelName, ' ', sizeof(channelName));
    std::string schannelName;
    std::string echannelName(header.channelName,
            sizeof(header.channelName));
    ebc2asc(echannelName, schannelName);
    strncpy(channelName,schannelName.c_str(),sizeof(channelName));
 
    toBcdStr(header.correl, correl, 4);
 
    if (strlen(header.abendCode) > 0) {
        std::string sAbendcode;
        std::string eAbendCode(header.abendCode,
                sizeof(header.abendCode));
        ebc2asc(eAbendCode, sAbendcode);
        strncpy(abendCode, sAbendcode.c_str(), sizeof(abendCode));
        trimBlank(abendCode);
    }
}
 
ASCCONTAINERHEADER::ASCCONTAINERHEADER(const CONTAINERHEADER& hdr) {
    this->length = hdr.length;
    std::string scontainerName;
    std::string econtainerName(hdr.containerName, 17);
    ebc2asc(econtainerName, scontainerName);
    memset(containerName,' ',sizeof(containerName));
    strncpy(containerName,scontainerName.c_str(),17);
}
 
ASCCONTAINERHEADER::ASCCONTAINERHEADER(const ASCCONTAINERHEADER& hdr) {
    this->length = hdr.length;
    memset(containerName, ' ', sizeof(containerName));
    strncpy(containerName,hdr.containerName,17);
}
 
ASCCONTAINERHEADER::ASCCONTAINERHEADER(const char* containerName,
        int length) {
    this->length=length;
    memset(this->containerName,' ',sizeof(this->containerName));
    strncpy(this->containerName,containerName,17);
}
 
void ASCCONTAINERHEADER::toContainerHeader(CONTAINERHEADER& hdr) {
    hdr.length = this->length;
    std::string scontainerName(this->containerName,17);
    std::string econtainerName;
    asc2ebc(scontainerName,econtainerName);
    memset(hdr.containerName,'\x40',sizeof(hdr.containerName));
    strncpy(hdr.containerName,econtainerName.c_str(),16);
    for(int i = 0; i < 16; i++) {
      if(hdr.containerName[i] == '\0' ||hdr.containerName[i] == ' '){
            hdr.containerName[i] = '\x40';
        }
    }
}
 
