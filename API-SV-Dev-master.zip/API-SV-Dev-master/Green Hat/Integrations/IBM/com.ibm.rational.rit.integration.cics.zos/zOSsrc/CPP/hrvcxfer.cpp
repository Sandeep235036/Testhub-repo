/*********************************************************************
 
 
 * Licensed Materials - Property of IBM and/or HCL
 
 
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 
 
 * Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 
 
 *
 
 
 * Note to U.S. Government Users Restricted Rights:
 
 
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 
 
 * Contract with IBM Corp.
 
 
 ********************************************************************/
 
/*******************************************************************************
 
 
 * objxfer.cpp
 
 
 * Class implementation
 
 
 ******************************************************************************/
 
#pragma csect(CODE, "HRVCXFER")
 
#define OPEN_DEFAULT 1
 
#define OPEN_SYS_EXT 1
 
#define _LARGE_TIME_API 1
 
#define _OPEN_THREADS 3
 
#define _XOPEN_SOURCE 600
 
#define _OPEN_SYS 1
 
#define _ISOC99_SROURCE 1
 
#define _XOPEN_SOURCE_EXTENDED 1
 
#define _POSIX_SOURCE 1
 
#define _POSIX_C_SOURCE 200112L
 
#define _OPEN_SYS_MUTEX_EXT 1
 
#define _OPEN_SYS_ITOA_EXT 1
 
#include <string>
 
#include <errno.h>
 
#include "objxfer.h"
 
#include "ritcomm.h"
 
#include "ritlog.h"
 
#include "google/protobuf/io/zero_copy_stream_impl_lite.h"
 
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <chrono>
#include "rtcpset.h"
#include "token.h"
 
// GSKit TLS 1.3 helpers (System SSL, GSKit v4)
// TLS 1.3 is controlled via GSK_PROTOCOL_TLSV1_3 and
// values like GSK_PROTOCOL_TLSV1_3_ON in gskssl.h.
 
// #define DEBUG_OBJXFER 1
 
// #define DEBUG_postObsrvMessage 1
 
// #define DEBUG_OBJXFER_REMOVE 1
 
// #define DEBUG_postLog 1
 
#include <iostream>
#include <string>
#include <cstdio>
#include <sstream>
 
using namespace std;
 
using namespace greenhat::vie::comms::proxy;
 
using namespace google::protobuf;
 
#define MAX_HEADER_SIZE 32
 
//CHANGE
std::string strip(const std::string &s)
{
    std::string str = s;
    // Remove leading spaces/tabs/newlines
    str.erase(str.begin(),
              std::find_if(str.begin(), str.end(),
                           [](unsigned char ch)
                           { return !std::isspace(ch); }));
    // Remove trailing spaces/tabs/newlines
    str.erase(std::find_if(str.rbegin(), str.rend(),
                           [](unsigned char ch)
                           { return !std::isspace(ch); })
                  .base(),
              str.end());
    return str;
}
 
ObjXfer::ObjXfer(const string &url, CURL *pcurl) : url_(url), pcurl_(pcurl)
{
}
 
ObjXfer::ObjXfer(const string &url, const string &keyring) : url_(url), keyring_(keyring)
{
    pcurl_ = curl_easy_init();
}
 
ObjXfer::~ObjXfer()
{
    curl_easy_cleanup(pcurl_);
}
/*
class TokenHandler {
public:
    // Static variables
    static std::string accessToken;
    static std::string bearerToken;
    // 1?? Set access token (updates accessToken only)
    static void setAccessToken(const std::string& token) {
        accessToken = token;
    }
        // 2?? Set bearer token (manually set full "Bearer <token>"
        static void setBearerToken(const std::string& token) {
            bearerToken = token;
        }
        // 3?? Clear access token (also clears bearer token)
        static void clearAccessToken() {
            accessToken.clear();
            bearerToken.clear();
        }
    };
    // Define static variables
    std::string TokenHandler::accessToken = "";
    std::string TokenHandler::bearerToken = "";
 */
 // define static members
 std::string TokenHandler::accessToken = "";
 std::string TokenHandler::bearerToken = "";
 void TokenHandler::setAccessToken(const std::string& token) {
     accessToken = token;
 }
 void TokenHandler::setBearerToken(const std::string& token) {
     bearerToken = token;
 }
 void TokenHandler::clearAccessToken() {
     accessToken.clear();
     bearerToken.clear();
 }
// Callback to capture response from curl
size_t writeCallback(void* contents, size_t size, size_t nmemb, void* userp) {
    std::string* str = static_cast<std::string*>(userp);
    str->append(static_cast<char*>(contents), size * nmemb);
    return size * nmemb;
}
 
// Function to refresh access token using refresh token
std::string getAccessToken(const std::string& serverUrl,const std::string& offtoken,Logger *log) {
    std::string accessToken;
 // std::cout << "offln token: '" << offtoken << "'" << std::endl;
    CURL* curl = curl_easy_init();
    if (!curl)
        log->error("Failed to init curl");
    string server ;
    ebc2asc(serverUrl,server);
 
    try {
        // Build POST body: refresh_token=<token>
        std::string postBody = "refresh_token=";
        postBody.append(offtoken);
   /*   postBody += "&client_id=my-app";            // Add
        postBody += "&grant_type=refresh_token"; */      // Add
   //   std::cout << "Final token: '" << offtoken << "'" << std::endl;
        std::string postbody;
        ebc2asc(postBody,postbody);
 
        // Build headers
        struct curl_slist* headers = nullptr;
        std::string contentType;
        ebc2asc("Content-Type: application/x-www-form-urlencoded", contentType);
        headers = curl_slist_append(headers, contentType.c_str());
 
    curl_easy_setopt(curl, CURLOPT_VERBOSE, 0);
        // Set curl options
      //curl_easy_setopt(curl, CURLOPT_URL, serverUrl.c_str());
        curl_easy_setopt(curl, CURLOPT_URL, server.c_str());
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_POST, 1L);
      //curl_easy_setopt(curl, CURLOPT_POSTFIELDS, postBody.c_str());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, postbody.c_str());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, postBody.size());
 
        // Optional SSL settings
    //  curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
    //  curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 2L);
       curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0);
       curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0);
 
        // Capture response
        std::string responseStr;
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseStr);
		      string err;
        CURLcode res = curl_easy_perform(curl);
    //			log->error("POST  res: : %s %d", res);
        if (res != CURLE_OK) {
			asc2ebc(curl_easy_strerror(res), err);
			log->error("POST failed: : %s %d",	err.c_str(), res);
        }
          string response;
          asc2ebc(responseStr,response);
     //			log->error("Responsestr: : %s",   	response.c_str());
        // Parse access_token from JSON
        std::string tokenField = "\"access_token\":\"";
        size_t start = response.find(tokenField);
        if (start != std::string::npos) {
            start += tokenField.size();
            size_t end = response.find("\"", start);
            accessToken = response.substr(start, end - start);
        } else {
            throw std::runtime_error("access_token not found in response");
			log->error("access_token not found in response");
        }
 
        curl_slist_free_all(headers);
        curl_easy_cleanup(curl);
    } catch (...) {
        curl_easy_cleanup(curl);
    }
 
    return accessToken;
}
 
 
//TIMER LOGIC
static std::chrono::steady_clock::time_point startTime =
    std::chrono::steady_clock::now();
 
bool isTwoMinutesPassed() {
    auto now = std::chrono::steady_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - startTime);
//  std::cout << "Elapsed time: " << static_cast<long long>(elapsed.count()) << " Seconds" << std::endl;
    return elapsed.count() >= 180; // 2 minutes = 120 seconds
}
Registration *
 
ObjXfer::postRegistration(const string &url, Registration *pMsg, Logger *log)
{
    string outstr;
//  std::cout << "Postregistration:Register url: " << url << std::endl;
    ebc2asc(url, outstr);
    struct ObjectToSend objSend;
    struct ObjectReceived objRecv;
    // objSend.sizeleft = (long) pMsg->ByteSize();
    objSend.sizeleft = (long)pMsg->ByteSizeLong();
    objSend.readptr = (char *)malloc(objSend.sizeleft);
    if (objSend.readptr == NULL)
    {
 
        FPRINTF(stdout, "Malloc error, errno=%d. Exiting...\n", errno); //$NON-NLS-1$
 
        exit(MEMORY_ALLOC_FAILURE);
    }
    ::google::protobuf::uint8 *output = (::google::protobuf::uint8 *)objSend.readptr;
    pMsg->SerializeWithCachedSizesToArray(output);
 

    if (!rtcp_server) {
    std::string token;
    if (TokenHandler::bearerToken.empty()) {
     // Token functionality to be picked from the dataset in job
     char buffer[1024];
     FILE *file = fopen("//DD:RITTOKEN", "rt");
     if (file != NULL)
     {
         while (fgets(buffer, sizeof(buffer), file))
         {
             std::string line = strip(buffer); // Trim spaces
             if (!line.empty())
             {
                 token += line; // Append trimmed line
             }
         }
     }
     fclose(file);
   //std::cout << "Final token: '" << token << "'" << std::endl;
    }
   	std::string serverUrl = "http://master-hcl.tp-k8s.nonprod.hclpnp.com:443/test/rest/tokens/"; // token endpoint
    std::string accesst;
    // Timer logic check
    bool twoMinPassed = isTwoMinutesPassed();
    //std::string refreshToken = token;
    if (TokenHandler::accessToken.empty() || twoMinPassed ) {
        if (twoMinPassed) {
        accesst = getAccessToken(serverUrl, TokenHandler::bearerToken, log);
        } else {
        accesst = getAccessToken(serverUrl, token, log);
        // Set bearer token (if needed separately)
        TokenHandler::setBearerToken(token);
        }
        if (!accesst.empty()) {
        //  std::cout << "Access token: '" << accesst << "'" << std::endl;
            TokenHandler::setAccessToken(accesst);
            //TIMER LOGIC
            startTime = std::chrono::steady_clock::now();
        } else {
            log->error("Failed to retrieve access token");
        }
    }
 
 // std::cout << "Postregistration:Access Token: " << TokenHandler::accessToken << std::endl;
 
 // std::cout << "Postregistration:Bearer Token: " << TokenHandler::bearerToken << std::endl;
 
	   token = TokenHandler::accessToken;
 // std::cout << "Copied token: '" << token << "'" << std::endl;
    struct curl_slist *http_headers = NULL;
    std::string final_auth_str, final_content_str;
    char ebc_buffer[2046];
    // 1. Build the header in a temporary EBCDIC buffer
    // This avoids mixing ASCII/EBCDIC inside snprintf
    snprintf(ebc_buffer, sizeof(ebc_buffer), "Authorization: Bearer %s",
    token.c_str());
  //std::string ebc_buffer = "Authorization: Bearer " + token;
 
    //Convert to ASCII using your specific function signature
    ebc2asc(ebc_buffer, final_auth_str);
  //ebc2asc(ebc_buffer.c_str(), final_auth_str);
    // 3. Convert Content-Type to ASCII as well
    ebc2asc("Content-Type: application/x-protobuf",
    final_content_str);
    //4. Append to the curl list
    // .c_str() provides the pointer curl needs
    http_headers = curl_slist_append(http_headers,
    final_content_str.c_str());
 
    std::string final_header;
    // Accept headers
    ebc2asc("Accept: application/x-protobuf", final_header);
    http_headers = curl_slist_append(http_headers,
 
    final_header.c_str());
    ebc2asc("Accept-Language: en-US", final_header);
 
    http_headers = curl_slist_append(http_headers,
    final_header.c_str());
 
    http_headers = curl_slist_append(http_headers,
    final_auth_str.c_str());
 
    // Set headers for curl
    curl_easy_setopt(pcurl_, CURLOPT_HTTPHEADER, http_headers);
 
    // Keep these as they are
    curl_easy_setopt(pcurl_, CURLOPT_SSL_VERIFYPEER, 0);
    curl_easy_setopt(pcurl_, CURLOPT_SSL_VERIFYHOST, 0);
    }
    // First set the URL that is about to receive our POST.
    // curl_easy_setopt(pcurl_, CURLOPT_URL, url.c_str());
    curl_easy_setopt(pcurl_, CURLOPT_URL, outstr.c_str());
    curl_easy_setopt(pcurl_, CURLOPT_VERBOSE, 0);
    curl_easy_setopt(pcurl_, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_WHATEVER);
    // Now specify we want to POST data
    curl_easy_setopt(pcurl_, CURLOPT_POST, 1L);
    curl_easy_setopt(pcurl_, CURLOPT_NOSIGNAL, 1L);
    curl_easy_setopt(pcurl_, CURLOPT_CONNECTTIMEOUT, getConnTimeout());
//    curl_easy_setopt(pcurl_, CURLOPT_LOW_SPEED_TIME, getLowSpeedTime());
//    curl_easy_setopt(pcurl_, CURLOPT_LOW_SPEED_LIMIT, getLowSpeedLimit());
    // we want to use our own read function
    curl_easy_setopt(pcurl_, CURLOPT_READFUNCTION, record_read);
    // pointer to pass to our read function
    curl_easy_setopt(pcurl_, CURLOPT_READDATA, &objSend);
    curl_easy_setopt(pcurl_, CURLOPT_WRITEFUNCTION, record_write);
    curl_easy_setopt(pcurl_, CURLOPT_WRITEDATA, &objRecv);
 
    // Set the expected POST size. If you want to POST large amounts of data,
    // consider CURLOPT_POSTFIELDSIZE_LARGE/
    //curl_easy_setopt(pcurl_, CURLOPT_POSTFIELDSIZE,
    //        (curl_off_t) objSend.sizeleft);
	curl_easy_setopt(pcurl_, CURLOPT_POSTFIELDSIZE,
            (long) objSend.sizeleft);

    // Set key ring for gskssl
    string keyring;
    if (rtcp_server) {
    if(keyring_.size() != 0){
       ebc2asc(keyring_, keyring);
      //  curl_easy_setopt(pcurl_,CURLOPT_CAINFO,keyring_.c_str());
        curl_easy_setopt(pcurl_,CURLOPT_CAINFO,keyring.c_str());
        curl_easy_setopt(pcurl_,CURLOPT_SSL_VERIFYHOST, 0);
    }
    }

    // Perform the request, res will get the return code
    CURLcode res = curl_easy_perform(pcurl_);
 
    // Check for errors
    string err;
    if (res != CURLE_OK) {
        asc2ebc(curl_easy_strerror(res),err);
     // log->error("ObjXfer::postRegistration failed: %s",//$NON-NLS-1$
     //         curl_easy_strerror(res));
        log->error("ObjXfer::postRegistration failed: %s",//$NON-NLS-1$
                err.c_str());            
        return NULL;
    }
    long httpCode = 0;
 
    res = curl_easy_getinfo(pcurl_, CURLINFO_RESPONSE_CODE, &httpCode);
 
    if (res != CURLE_OK)
    {
 
        asc2ebc(curl_easy_strerror(res), err);
        // log->error("ObjXfer::postRegistration failed: %s",//$NON-NLS-1$
        //         curl_easy_strerror(res));
        log->error("ObjXfer::postRegistration failed: %s", //$NON-NLS-1$
                   err.c_str());
        return NULL;
    }
 
#ifdef DEBUG_OBJXFER
 
    FPRINTF(stdout, "HTTP RESPONSE CODE AFTER POST: %d\n", httpCode); //$NON-NLS-1$
 
#endif // DEBUG_OBJXFER
 
    if (200 != httpCode)
    {
 
        log->error("ObjXfer::postRegistration failed: httpCode=%d", //$NON-NLS-1$
                   httpCode);
        return NULL;
    }
    string parsedStr(objRecv.ptr);
    pMsg->ParseFromString(parsedStr);
    return pMsg;
}
 
Configuration *
ObjXfer::getObj(const string &url, Logger *log)
{
    struct ObjectReceived objRecv;
    if (!rtcp_server) {
    std::string urlebc;
    asc2ebc(url,urlebc);
 // std::cout << "GetObj:Configer url: " << urlebc << std::endl;
    std::string auth = "Authorization: Bearer " +
    TokenHandler::accessToken;
//  std::cout << "GetObj:Configer access token" << TokenHandler::accessToken << std::endl;
    std::string final_auth;
 
    struct curl_slist* headers = nullptr;
 
  //std::string accept;
  //ebc2asc("Accept: application/json", accept);
  //headers = curl_slist_append(headers, accept.c_str());
    std::string contentType;
    ebc2asc("Content-Type: application/x-protobuf", contentType);
    headers = curl_slist_append(headers, contentType.c_str());
    ebc2asc(auth, final_auth);
    headers = curl_slist_append(headers, final_auth.c_str());
    curl_easy_setopt(pcurl_, CURLOPT_HTTPHEADER, headers);
    }
    // First set the URL that is about to receive our POST.
    curl_easy_setopt(pcurl_, CURLOPT_URL, url.c_str());
    curl_easy_setopt(pcurl_, CURLOPT_VERBOSE, 0);
    curl_easy_setopt(pcurl_, CURLOPT_WRITEFUNCTION, record_write);
    curl_easy_setopt(pcurl_, CURLOPT_WRITEDATA, &objRecv);
    curl_easy_setopt(pcurl_, CURLOPT_NOSIGNAL, 1L);
    curl_easy_setopt(pcurl_, CURLOPT_CONNECTTIMEOUT, getConnTimeout());
    //    curl_easy_setopt(pcurl_, CURLOPT_LOW_SPEED_TIME, getLowSpeedTime());
    //    curl_easy_setopt(pcurl_, CURLOPT_LOW_SPEED_LIMIT, getLowSpeedLimit());
    // Perform the request, res will get the return code

    // Set key ring for gskssl
    string keyring;
    if (rtcp_server) {
    if(keyring_.size() != 0){
       ebc2asc(keyring_, keyring);
        curl_easy_setopt(pcurl_,CURLOPT_CAINFO,keyring.c_str());
        //curl_easy_setopt(pcurl_,CURLOPT_CAINFO,keyring_.c_str());
        curl_easy_setopt(pcurl_,CURLOPT_SSL_VERIFYHOST, 0);
    }
   }
    CURLcode res = curl_easy_perform(pcurl_);
    // Check for errors
    string err;
    if (res != CURLE_OK) {
        asc2ebc(curl_easy_strerror(res),err);
     // log->error("ObjXfer::getObj failed: %s",//$NON-NLS-1$
     //         curl_easy_strerror(res));
        log->error("ObjXfer::getObj failed: %s",//$NON-NLS-1$
                err.c_str());            
        return NULL;
    }
    long httpCode = 0;
    res = curl_easy_getinfo(pcurl_, CURLINFO_RESPONSE_CODE, &httpCode);
    if (res != CURLE_OK)
    {
        asc2ebc(curl_easy_strerror(res), err);
        // log->error("ObjXfer::getObj failed: %s",//$NON-NLS-1$
        //        curl_easy_strerror(res));
        log->error("ObjXfer::getObj failed: %s", //$NON-NLS-1$
                   err.c_str());
        return NULL;
    }
 
    if (200 != httpCode)
    {
        log->error("ObjXfer::getObj failed: httpCode=%d", //$NON-NLS-1$
                   httpCode);
        return NULL;
    }
    ::google::protobuf::io::CodedInputStream input((const uint8 *)objRecv.ptr, (int)objRecv.len);
    Configuration* object = new Configuration();
    object->MergePartialFromCodedStream(&input);
    return object;
}
 
int ObjXfer::postLog(const string &url, LogEventSet *eventSet, Logger *log)
{
    time64_t ltime;
    time64(&ltime);
    eventSet->set_transmittimestamp(ltime);
    // int size = eventSet->ByteSize();
    int size = eventSet->ByteSizeLong();
    char header[MAX_HEADER_SIZE] = {0};
    ::google::protobuf::io::ArrayOutputStream arrOutHdr(header, size);
    ::google::protobuf::io::CodedOutputStream codedOSHdr(&arrOutHdr);
    codedOSHdr.WriteVarint32(size);

    int hdrLen = strlen(header);
 
#ifdef DEBUG_postLog
 
    char headerT[MAX_HEADER_SIZE * 3] = {0};
    log->debug("ObjXfer::postLog, WriteVarint32, size=%d arrOutHdr=\n%s", //$NON-NLS-1$
               hdrLen, header);
    for (int i = 0; i < hdrLen; i++)
    {
        sprintf(headerT, "%2.2X ", header[i]); //$NON-NLS-1$
    }
    log->debug("ObjXfer::postLog, WriteVarint32, arrOutHdr_HEX=\n%s", //$NON-NLS-1$
               headerT);
 
#endif
 
    char *buffer = (char *)malloc(size + hdrLen + 1);
    if (buffer == NULL)
    {
        FPRINTF(stdout, "Malloc error, errno=%d. Exiting...\n", errno); //$NON-NLS-1$
        exit(MEMORY_ALLOC_FAILURE);
    }
 
    memset(buffer, 0, size + hdrLen);
    memcpy(buffer, header, hdrLen);
    struct ObjectToSend objSend;
    ::google::protobuf::io::ArrayOutputStream arrOut(buffer + hdrLen, size);
    ::google::protobuf::io::CodedOutputStream codedOS(&arrOut);
    eventSet->SerializeWithCachedSizes(&codedOS);
    objSend.sizeleft = (long)(size + hdrLen);
    objSend.readptr = buffer;
    buffer[size + hdrLen] = '\0';
 
    string outstr;
    ebc2asc(url, outstr);
    if (!rtcp_server) {
        return 0;
    }
 /* std::cout << "Postlog:postobsr url: " << url << std::endl;
    std::string auth = "Authorization: Bearer " +
    TokenHandler::accessToken;
    std::string final_auth;
 
    struct curl_slist* headers = nullptr;
    ebc2asc(auth, final_auth);
    headers = curl_slist_append(headers, final_auth.c_str());
 
 // std::string accept;
 // ebc2asc("Accept: application/x-protobuf", accept);
 // headers = curl_slist_append(headers, accept.c_str());
    std::string contentType;
    ebc2asc("Content-Type: application/x-protobuf", contentType);
    headers = curl_slist_append(headers, contentType.c_str());
    curl_easy_setopt(pcurl_, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(pcurl_, CURLOPT_SSL_VERIFYPEER, 0);
    curl_easy_setopt(pcurl_, CURLOPT_SSL_VERIFYHOST, 0);
    */
    // First set the URL that is about to receive our POST.
    curl_easy_setopt(pcurl_, CURLOPT_URL, outstr.c_str());
    curl_easy_setopt(pcurl_, CURLOPT_VERBOSE, 0);
 
    // Now specify we want to POST data
    curl_easy_setopt(pcurl_, CURLOPT_POST, 1L);
    curl_easy_setopt(pcurl_, CURLOPT_NOSIGNAL, 1L);
    curl_easy_setopt(pcurl_, CURLOPT_CONNECTTIMEOUT, getConnTimeout());
    //    curl_easy_setopt(pcurl_, CURLOPT_LOW_SPEED_TIME, getLowSpeedTime());
    //    curl_easy_setopt(pcurl_, CURLOPT_LOW_SPEED_LIMIT, getLowSpeedLimit());
    // we want to use our own read function
    curl_easy_setopt(pcurl_, CURLOPT_READFUNCTION, record_read);
 
    // pointer to pass to our read function
    curl_easy_setopt(pcurl_, CURLOPT_READDATA, &objSend);
 
    // Set the expected POST size. If you want to POST large amounts of data,
    // consider CURLOPT_POSTFIELDSIZE_LARGE/
    // curl_easy_setopt(pcurl_, CURLOPT_POSTFIELDSIZE,
    //        (curl_off_t) objSend.sizeleft);
 
    curl_easy_setopt(pcurl_, CURLOPT_POSTFIELDSIZE,
                     (long)objSend.sizeleft);
 
    // Set key ring for gskssl
    string keyring;
    if (keyring_.size() != 0)
    {
        ebc2asc(keyring_, keyring);
        curl_easy_setopt(pcurl_, CURLOPT_CAINFO, keyring.c_str());
        // curl_easy_setopt(pcurl_,CURLOPT_CAINFO,keyring_.c_str());
        curl_easy_setopt(pcurl_, CURLOPT_SSL_VERIFYHOST, 0);
    }
 
    // Perform the request, res will get the return code
    CURLcode res = curl_easy_perform(pcurl_);
 
    // Check for errors
    string err;
    if (res != CURLE_OK)
    {
        asc2ebc(curl_easy_strerror(res), err);
        log->error("ObjXfer::postLog failed: %s", //$NON-NLS-1$
                   err.c_str());
        // log->error("ObjXfer::postLog failed: %s",//$NON-NLS-1$
        //         curl_easy_strerror(res));
        return -1;
    }
 
    long httpCode = 0;
    res = curl_easy_getinfo(pcurl_, CURLINFO_RESPONSE_CODE, &httpCode);
    if (res != CURLE_OK)
    {
        asc2ebc(curl_easy_strerror(res), err);
        log->error("ObjXfer::postLog failed: %s", //$NON-NLS-1$
                   err.c_str());
        //  log->error("ObjXfer::postLog failed: %s",//$NON-NLS-1$
        //          curl_easy_strerror(res));
        return -1;
    }
 
#ifdef DEBUG_postLog
 
    FPRINTF(stdout, "HTTP RESPONSE CODE AFTER POST: %d\n", //$NON-NLS-1$
            httpCode);
 
#endif // DEBUG_OBJXFER
 
    if (200 != httpCode)
    {
        log->error("ObjXfer::postLog httpCode=%d", //$NON-NLS-1$
                   httpCode);
        return -1;
    }
    return 0;
}
 
int ObjXfer::postObsrvMessage(const string &url, const string &message,
                              Logger *log)
{
 
#ifdef DEBUG_postObsrvMessage
 
    FPRINTF(stdout, ">>>Entering ObjXfer::postObsrvMessage: " //$NON-NLS-1$
                    "Line=%d, Length=%d, StringToSend=%s \n", //$NON-NLS-1$
            __LINE__, message.length(), message.c_str());
 
#endif
 
    struct ObjectToSend objSend;
    objSend.sizeleft = (long)message.length();
    objSend.readptr = (char *)malloc(objSend.sizeleft);
    if (objSend.readptr == NULL)
    {
        FPRINTF(stdout, "Malloc error, errno=%d. Exiting...\n", errno); //$NON-NLS-1$
        exit(MEMORY_ALLOC_FAILURE);
    }
 
    memcpy((void *)objSend.readptr, (const void *)message.c_str(),
           message.length());
 
    objSend.readptr[message.length() - 1] = '\0';
    struct curl_slist *http_headers = NULL;
    if (!rtcp_server) {
       return 0;
    }
 
    /*
    http_headers = curl_slist_append(http_headers,
                                     RIT_JSON_HTTP_HEADER_CONTENT_TYPE);
    std::string urlebc;
    asc2ebc(url,urlebc);
    std::cout << "postObsrvMessage url: " << urlebc << std::endl;
    std::string auth = "Authorization: Bearer " +
    TokenHandler::accessToken;
    std::cout << "postObsrvMessage access token" << TokenHandler::accessToken << std::endl;
    std::string final_auth;
 
    struct curl_slist* headers = nullptr;
 
  //std::string accept;
  //ebc2asc("Accept: application/json", accept);
  //headers = curl_slist_append(headers, accept.c_str());
    std::string contentType;
    ebc2asc("Content-Type: application/x-protobuf", contentType);
    headers = curl_slist_append(headers, contentType.c_str());
    ebc2asc(auth, final_auth);
    headers = curl_slist_append(headers, final_auth.c_str());
    */
    http_headers = curl_slist_append(http_headers,
            RIT_JSON_HTTP_HEADER_CONTENT_TYPE);
    curl_easy_setopt(pcurl_, CURLOPT_HTTPHEADER, http_headers);
 
    // First set the URL that is about to receive our POST.
    curl_easy_setopt(pcurl_, CURLOPT_URL, url.c_str());
    curl_easy_setopt(pcurl_, CURLOPT_VERBOSE, 0);
 
    // Now specify we want to POST data
    curl_easy_setopt(pcurl_, CURLOPT_POST, 1L);
    curl_easy_setopt(pcurl_, CURLOPT_NOSIGNAL, 1L);
    curl_easy_setopt(pcurl_, CURLOPT_CONNECTTIMEOUT, getConnTimeout());
    //    curl_easy_setopt(pcurl_, CURLOPT_LOW_SPEED_TIME, getLowSpeedTime());
    //    curl_easy_setopt(pcurl_, CURLOPT_LOW_SPEED_LIMIT, getLowSpeedLimit());
 
    // we want to use our own read function
    curl_easy_setopt(pcurl_, CURLOPT_READFUNCTION, record_read);
 
    // pointer to pass to our read function
    curl_easy_setopt(pcurl_, CURLOPT_READDATA, &objSend);
 
    // Set the expected POST size. If you want to POST large amounts of data,
    // consider CURLOPT_POSTFIELDSIZE_LARGE/
    // curl_easy_setopt(pcurl_, CURLOPT_POSTFIELDSIZE,
    //        (curl_off_t) objSend.sizeleft);
    curl_easy_setopt(pcurl_, CURLOPT_POSTFIELDSIZE,
                     (long)objSend.sizeleft);
 
    // Set key ring for gskssl
    string keyring;
    if (keyring_.size() != 0)
    {
        ebc2asc(keyring_, keyring);
        curl_easy_setopt(pcurl_, CURLOPT_CAINFO, keyring.c_str());
        //  curl_easy_setopt(pcurl_,CURLOPT_CAINFO,keyring_.c_str());
        curl_easy_setopt(pcurl_, CURLOPT_SSL_VERIFYHOST, 0);
    }
 
    // Perform the request, res will get the return code
    CURLcode res = curl_easy_perform(pcurl_);
 
    // Check for errors
    string err;
    if (res != CURLE_OK)
    {
        asc2ebc(curl_easy_strerror(res), err);
        log->error("ObjXfer::postObsrvMessage failed: %s", //$NON-NLS-1$
                   err.c_str());
 
        //  log->error("ObjXfer::postObsrvMessage failed: %s",//$NON-NLS-1$
        //          curl_easy_strerror(res));
        return -1;
    }
 
    long httpCode = 0;
    res = curl_easy_getinfo(pcurl_, CURLINFO_RESPONSE_CODE, &httpCode);
    if (res != CURLE_OK)
    {
        asc2ebc(curl_easy_strerror(res), err);
        log->error("ObjXfer::postObsrvMessage failed: %s", //$NON-NLS-1$
                   err.c_str());
        //  log->error("ObjXfer::postObsrvMessage failed: %s",//$NON-NLS-1$
        //          curl_easy_strerror(res));
        return -1;
    }
 
#ifdef DEBUG_postObsrvMessage
 
    FPRINTF(stdout, "HTTP RESPONSE CODE AFTER POST: %d\n", httpCode); //$NON-NLS-1$
 
#endif // DEBUG_OBJXFER
 
    if (200 != httpCode)
    {
        log->error("ObjXfer::postObsrvMessage failed: httpCode=%d", //$NON-NLS-1$
                   httpCode);
        return NULL;
    }
    return 0;
}
 
bool ObjXfer::remove(const string &url, Logger *log)
{
 
#ifdef DEBUG_OBJXFER_REMOVE
 
    FPRINTF(stdout, ">>> Entering ObjXfer::remove\n");           //$NON-NLS-1$
    FPRINTF(stdout, "The URL to be removed: %s\n", url.c_str()); //$NON-NLS-1$
 
#endif
 
    string delstr;
    ebc2asc("DELETE", delstr);
    struct ObjectReceived objRecv;
    curl_easy_setopt(pcurl_, CURLOPT_CUSTOMREQUEST, delstr.c_str());
    curl_easy_setopt(pcurl_, CURLOPT_WRITEFUNCTION, record_write);
    curl_easy_setopt(pcurl_, CURLOPT_WRITEDATA, &objRecv);
    curl_easy_setopt(pcurl_, CURLOPT_URL, url.c_str());
    curl_easy_setopt(pcurl_, CURLOPT_NOSIGNAL, 1L);
    curl_easy_setopt(pcurl_, CURLOPT_VERBOSE, 0);
    curl_easy_setopt(pcurl_, CURLOPT_CONNECTTIMEOUT, getConnTimeout());
    //    curl_easy_setopt(pcurl_, CURLOPT_LOW_SPEED_TIME, getLowSpeedTime());
    //    curl_easy_setopt(pcurl_, CURLOPT_LOW_SPEED_LIMIT, getLowSpeedLimit());
 
    // Set key ring for gskssl
    if (keyring_.size() != 0)
    {
        curl_easy_setopt(pcurl_, CURLOPT_CAINFO, keyring_.c_str());
        curl_easy_setopt(pcurl_, CURLOPT_SSL_VERIFYHOST, 0);
    }
 
    CURLcode res = curl_easy_perform(pcurl_);
 
    string err;
    if (res != CURLE_OK)
    {
        asc2ebc(curl_easy_strerror(res), err);
        log->error("ObjXfer::remove failed: %s", //$NON-NLS-1$
                   err.c_str());
        // log->error("ObjXfer::remove failed: %s",//$NON-NLS-1$
        //         curl_easy_strerror(res));
        return false;
    }
    else
    {
#ifdef DEBUG_OBJXFER_REMOVE
 
        FPRINTF(stdout, "ObjXfer::remove received data: %s\n", //$NON-NLS-1$
                (const char *)objRecv.ptr);
 
#endif
 
        log->info("ObjXfer::remove rules: %s", url.c_str()); //$NON-NLS-1$
        log->debug("ObjXfer::remove received data: %s",      //$NON-NLS-1$
                   (const char *)objRecv.ptr);
    }
    return true;
}
