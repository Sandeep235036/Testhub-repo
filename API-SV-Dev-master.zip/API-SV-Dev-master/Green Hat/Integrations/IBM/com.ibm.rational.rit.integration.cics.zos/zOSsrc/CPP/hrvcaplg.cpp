/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*
 * ritlog.cpp
 */
#pragma csect (CODE,"HRVCAPLG")
#define OPEN_DEFAULT 1
#define OPEN_SYS_EXT 1
#define _LARGE_TIME_API 1
#define _OPEN_THREADS 3
#define  _XOPEN_SOURCE 600
#define _OPEN_SYS 1
#define _ISOC99_SROURCE 1
#define _XOPEN_SOURCE_EXTENDED 1
#define _POSIX_SOURCE 1
#define _POSIX_C_SOURCE 200112L
#define _OPEN_SYS_MUTEX_EXT 1
#define _OPEN_SYS_ITOA_EXT 1
#include "ritlog.h"
#include <errno.h>
#include <signal.h>
#include <fcntl.h>
#include <string.h>
//#define DEBUG_RITLOG
LOGEVENT::LOGEVENT(const string& name,
        greenhat::vie::comms::proxy::LogEvent_Level level,
        const string& logMessage, const map<string, string> & context,
        long timestamp) :
        level_(level), timestamp_(timestamp) {
    name_.assign(name);
    message_.assign(logMessage);
    if (context.size() > 0) {
        map<string, string>::const_iterator it = context.begin();
        for (; it != context.end(); it++) {
            context_[(*it).first] = (*it).second;
        }
    }
}
 
Logger::Logger(const string & name, LogRouter* router) :
        name_(name), router_(router) {
}
 
Logger::Logger(const char* name, LogRouter* router) :
        name_(name), router_(router) {
}
 
int Logger::log(greenhat::vie::comms::proxy::LogEvent_Level level,
        const string & message) {
    time64_t ltime;
    time64(&ltime);
    LOGEVENT logEvent(name_, level, message, context_, ltime);
    return fireEvent(logEvent);
}
 
int Logger::log(greenhat::vie::comms::proxy::LogEvent_Level level,
        const char* message, ...) {
    char buf[MAX_LOG_MESSAGE_LEN] = { 0 };
    va_list nextArg;
    va_start(nextArg, message);
    vsnprintf(buf, MAX_LOG_MESSAGE_LEN - 1, message, nextArg);
    va_end(nextArg);
    string msg(buf);
    return log(level, msg);
}
 
int Logger::log(greenhat::vie::comms::proxy::LogEvent_Level level,
        const map<string, string> & context, const char* message, ...) {
    char buf[MAX_LOG_MESSAGE_LEN] = { 0 };
    va_list nextArg;
    va_start(nextArg, message);
    vsnprintf(buf, MAX_LOG_MESSAGE_LEN - 1, message, nextArg);
    va_end(nextArg);
    string msg(buf);
    return log(level, msg, context);
}
 
int Logger::log(greenhat::vie::comms::proxy::LogEvent_Level level,
        const string & message, const map<string, string> & context) {
    time64_t ltime;
    time64(&ltime);
    LOGEVENT logEvent(name_, level, message, context, ltime);
    return fireEvent(logEvent);
}
 
int Logger::debug(const char* message, ...) {
    char buf[MAX_LOG_MESSAGE_LEN] = { 0 };
    va_list nextArg;
    va_start(nextArg, message);
    vsnprintf(buf, MAX_LOG_MESSAGE_LEN - 1, message, nextArg);
    va_end(nextArg);
    string msg(buf);
    return log(greenhat::vie::comms::proxy::LogEvent_Level_DEBUG, msg);
}
 
int Logger::debug(const map<string, string> & context,
        const char* message, ...) {
    char buf[MAX_LOG_MESSAGE_LEN] = { 0 };
    va_list nextArg;
    va_start(nextArg, message);
    vsnprintf(buf, MAX_LOG_MESSAGE_LEN - 1, message, nextArg);
    va_end(nextArg);
    string msg(buf);
    return log(greenhat::vie::comms::proxy::LogEvent_Level_DEBUG, msg,
            context);
}
 
int Logger::info(const char* message, ...) {
    char buf[MAX_LOG_MESSAGE_LEN] = { 0 };
    va_list nextArg;
    va_start(nextArg, message);
    vsnprintf(buf, MAX_LOG_MESSAGE_LEN - 1, message, nextArg);
    va_end(nextArg);
    string msg(buf);
    return log(greenhat::vie::comms::proxy::LogEvent_Level_INFO, msg);
}
 
int Logger::info(const map<string, string> & context,
        const char* message, ...) {
    char buf[MAX_LOG_MESSAGE_LEN] = { 0 };
    va_list nextArg;
    va_start(nextArg, message);
    vsnprintf(buf, MAX_LOG_MESSAGE_LEN - 1, message, nextArg);
    va_end(nextArg);
    string msg(buf);
    return log(greenhat::vie::comms::proxy::LogEvent_Level_DEBUG, msg,
            context);
}
 
int Logger::warn(const char * message, ...) {
    char buf[MAX_LOG_MESSAGE_LEN] = { 0 };
    va_list nextArg;
    va_start(nextArg, message);
    vsnprintf(buf, MAX_LOG_MESSAGE_LEN - 1, message, nextArg);
    va_end(nextArg);
    string msg(buf);
    return log(greenhat::vie::comms::proxy::LogEvent_Level_WARN, msg);
}
 
int Logger::warn(const map<string, string> & context,
        const char * message, ...) {
    char buf[MAX_LOG_MESSAGE_LEN] = { 0 };
    va_list nextArg;
    va_start(nextArg, message);
    vsnprintf(buf, MAX_LOG_MESSAGE_LEN - 1, message, nextArg);
    va_end(nextArg);
    string msg(buf);
    return log(greenhat::vie::comms::proxy::LogEvent_Level_WARN, msg,
            context);
}
 
int Logger::error(const char* message, ...) {
    char buf[MAX_LOG_MESSAGE_LEN] = { 0 };
    va_list nextArg;
    va_start(nextArg, message);
    vsnprintf(buf, MAX_LOG_MESSAGE_LEN - 1, message, nextArg);
    va_end(nextArg);
    string msg(buf);
    return log(greenhat::vie::comms::proxy::LogEvent_Level_ERROR, msg);
}
 
int Logger::error(const map<string, string> & context,
        const char* message, ...) {
    char buf[MAX_LOG_MESSAGE_LEN] = { 0 };
    va_list nextArg;
    va_start(nextArg, message);
    vsnprintf(buf, MAX_LOG_MESSAGE_LEN - 1, message, nextArg);
    va_end(nextArg);
    string msg(buf);
    return log(greenhat::vie::comms::proxy::LogEvent_Level_ERROR, msg,
            context);
}
 
int Logger::fireEvent(const LOGEVENT & logEvent) {
    if (router_ != NULL) {
        return router_->logEvent(logEvent);
    }
    return 0;
}
 
bool Logger::isTraceEnabled() {
    if (router_ == NULL) {
        return false;
    }
    return router_->accepts(
            ::greenhat::vie::comms::proxy::LogEvent_Level_DEBUG);
}
 
/**
 * Check if debug logging is enabled.
 *
 * @return True if Level.DEBUG is enabled in the Logger
 */
bool Logger::isDebugEnabled() {
    if (router_ == NULL) {
        return false;
    }
    return router_->accepts(
            greenhat::vie::comms::proxy::LogEvent_Level_DEBUG);
}
 
/**
 * Check if info logging is enabled.
 *
 * @return True if Level.INFO is enabled in the Logger
 */
bool Logger::isInfoEnabled() {
    if (router_ == NULL) {
        return false;
    }
    return router_->accepts(
            greenhat::vie::comms::proxy::LogEvent_Level_INFO);
}
 
/**
 * Check if warning logging is enabled.
 *
 * @return True if Level.WARNING is enabled in the Logger
 */
bool Logger::isWarningEnabled() {
    if (router_ == NULL) {
        return false;
    }
    return router_->accepts(
            greenhat::vie::comms::proxy::LogEvent_Level_WARN);
}
 
/**
 * Check if error logging is enabled.
 *
 * @return True if Level.ERROR is enabled in the Logger
 */
bool Logger::isErrorEnabled() {
    if (router_ == NULL) {
        return false;
    }
    return router_->accepts(
            greenhat::vie::comms::proxy::LogEvent_Level_ERROR);
}
 
/*
 * Methods for adding contextual data
 */
/**
 * Adds key-value pair to the logger's contextual data.
 *
 * @param key
 * @param value
 */
void Logger::putContextData(const string & key, const string & value) {
    context_[key] = value;
}
 
/**
 * Returns the value associated with the key from the contextual data.
 *
 * @param key
 * @return string, or NULL if the key does not exist.
 */
int Logger::getContextData(const string & key, string & value) {
    map<string, string>::iterator it = context_.find(key);
    if (it == context_.end()) {
        return -1;
    }
    value = (*it).second;
    return 0;
}
 
/**
 * Deletes the key and value from the contextual data
 *
 * @param key
 * @return 1 if it existed, or 0 if it didn't.
 */
int Logger::deleteContextData(const string & key) {
    return context_.erase(key);
}
 
/**
 * Clears all contextual data for this logger instance.
 */
void Logger::clearContextData() {
    context_.clear();
}
 
const map<string, string> & Logger::getContext() {
    return context_;
}
 
 
ThreadScopeMutexGuard::ThreadScopeMutexGuard(pthread_mutex_t* ptr)
{
    this->mutex_ptr_=ptr;
    int rc = pthread_mutex_lock(this->mutex_ptr_);
    if(rc != 0) {
        while(rc !=0 && errno == EAGAIN) {
            rc= pthread_mutex_lock(this->mutex_ptr_);
        }
        if(rc == 0 ){
            return;
        }
     // throw string("lock mutex failed.");
        std::cerr << "lock mutex failed\n";
    }
    return;
}
 
ThreadScopeMutexGuard::~ThreadScopeMutexGuard()
{
    int rc =pthread_mutex_unlock(this->mutex_ptr_);
    if(rc != 0){
     // throw string("unlock mutex failed");
        std::cerr << "unlock mutex failed\n";
    }
}
 
//**************************FileLogAppender*************************//
FileLogAppender::FileLogAppender(const vector<string> fileNames, int clearFlag) :
        currentLogFile_(NULL),clearFlag_(clearFlag), errorFlag_(0), currentFileIndex_(-1) {
    int rc = pthread_mutexattr_init(&mutexattr_);
    if (rc == -1) {
        FPRINTF(stdout, "pthread_mutexattr_init error, errno=%d. Exiting...\n", //$NON-NLS-1$
                errno);
        exit (EXIT_FAILURE);
    }
    rc = pthread_mutexattr_setkind_np(&mutexattr_, __MUTEX_RECURSIVE + __MUTEX_NODEBUG);
    if (rc == -1) {
        FPRINTF(stdout,
                "pthread_mutexattr_setkind_np error, errno=%d. Exiting...\n", //$NON-NLS-1$
                errno);
        exit (EXIT_FAILURE);
    }
    rc = pthread_mutex_init(&mutex_, &mutexattr_);
    if (rc == -1) {
        FPRINTF(stdout, "pthread_mutex_init error, errno=%d. Exiting...\n", //$NON-NLS-1$
                errno);
        exit (EXIT_FAILURE);
    }
 
    fileNameList_=fileNames;
    pthread_mutex_lock(&mutex_);
    getNextAvailableFile();
    pthread_mutex_unlock(&mutex_);
}
 
 
FileLogAppender::~FileLogAppender() {
    pthread_mutex_lock(&mutex_);
    closeCurrentFile();
    pthread_mutex_unlock(&mutex_);
    pthread_mutex_destroy(&mutex_);
    pthread_mutexattr_destroy(&mutexattr_);
}
 
int FileLogAppender::flush() {
    ThreadScopeMutexGuard guard(&mutex_);
    time64_t ltime;
    time64(&ltime);
    FPRINTF(stdout, "Clear log file %s %s\n",
            fileNameList_[currentFileIndex_].c_str(), ctime64(&ltime));
 
    closeCurrentFile();
 
    std::string fname ;
    fname = std::string("//") + fileNameList_[currentFileIndex_];
 
  // currentLogFile_ = fopen(fileNameList_[currentFileIndex_].c_str(),
  //          "at,lrecl=256,recfm=V");
    currentLogFile_ = freopen(fname.c_str(), "at", stdout);
    if(currentLogFile_ == NULL) {
     // throw string("Failed to open log file.");
        std::cerr << "Failed to open log file.\n";
    }
    return 0;
}
 
void FileLogAppender::closeCurrentFile() {
    //close current log file first
    if (this->currentLogFile_ != NULL) {
        int rc = fclose(currentLogFile_);
        if (rc != 0) {
            FPRINTF(stdout, "Error in fclose(), errno=%d %s, LINE=%d.\n",
                    errno, strerror(errno), __LINE__);
        }
        this->currentLogFile_ = NULL;
    }
}
 
void FileLogAppender::getNextAvailableFile() {
    closeCurrentFile();
    int rc = -1;
    int fileListSize = fileNameList_.size();
 
    if (fileListSize> 0 ) {
        FILE* file =NULL;
        for(int times=1; times <= fileListSize; times ++){
            int index = (this->currentFileIndex_+times)%fileListSize;
            std::string fname ;
            fname = std::string("//") + fileNameList_[index];
        //  file = fopen(fileNameList_[index].c_str(),
        //          "wt,lrecl=256,recfm=V");
            file = freopen(fname.c_str(), "wt", stdout);
            if(file != NULL) {
                this->currentFileIndex_ = index;
                this->currentLogFile_=file;
                break;
            } else {
                FPRINTF(stdout, "Error in fopen() errno=%d %s.\n",
                    errno, strerror(errno));
            }
        }
        if(file == NULL) {
            this->currentFileIndex_=0;
            this->currentLogFile_=NULL;
            throw string("Failed to open log file.");
        }
    }
}
 
int FileLogAppender::log(const LOGEVENT & event) {
    ThreadScopeMutexGuard guard(&mutex_);
    int rc = -1;
    if (currentLogFile_ == NULL) {
        FPRINTF(stdout, "FILE handler invalid\n");
        return rc;
    }
    char strtime[RITLOG_TIME_LEN + 1] = { 0 };
    strncpy(strtime, ctime(&(event.timestamp_)), RITLOG_TIME_LEN);
    char strLevel[16] = { 0 };
    switch (event.level_) {
        case greenhat::vie::comms::proxy::LogEvent_Level_DEBUG:
            strcpy(strLevel, RIT_LogEvent_Level_DEBUG);
            break;
        case greenhat::vie::comms::proxy::LogEvent_Level_WARN:
            strcpy(strLevel, RIT_LogEvent_Level_WARN);
            break;
        case greenhat::vie::comms::proxy::LogEvent_Level_ERROR:
            strcpy(strLevel, RIT_LogEvent_Level_ERROR);
            break;
        case greenhat::vie::comms::proxy::LogEvent_Level_INFO:
        default:
            strcpy(strLevel, RIT_LogEvent_Level_INFO);
            break;
    }
 
    int msgLen = event.message_.length() + RITLOG_LOGGERNAME_MAX_LEN
            + RITLOG_TIME_LEN + 5;
    char* buffer = new char[msgLen];
    memset(buffer, 0, msgLen);
    sprintf(buffer, "%s %s-%s:\n%s\n", strtime,
            event.name_.c_str(), strLevel, event.message_.c_str());
    string msg;
    msg = buffer;
  /*if (asc2ebc(buffer, msg) != 0) {
        FPRINTF(stdout, "asc2ebc failed with errno=%d\n",
                errno);
    }*/
  //DELETE(buffer);
    delete[] buffer;
    int wroteLen = 0;
    if (currentLogFile_ == NULL) {
        getNextAvailableFile();
        if(currentLogFile_ == NULL){
            return -1;
        }
    }
    if (logWrite(msg) == -1) return -1;
    string logMsg;
    if (!event.context_.empty()) {
        logMsg.append(" [");
        bool first = true;
        map<string, string>::const_iterator it = event.context_.begin();
        for (; it != event.context_.end(); it++) {
            if (first) {
                first = false;
            } else {
                logMsg.append(", ");
            }
            logMsg.append((*it).first).append(" = \"");
            logMsg.append((*it).second).append("\"");
        }
        logMsg.append("]");
    }
    if (!event.trace_.empty()) {
        logMsg.append(" ").append(event.trace_);
    }
    if (!logMsg.empty()) {
        msg.clear();
        msg = logMsg;
    /*  if (asc2ebc(logMsg, msg) != 0) {
            FPRINTF(stdout, "asc2ebc failed with errno=%d\n",
                    errno);
        } */
        if (currentLogFile_ == NULL) {
            return -1;
        }
        if (logWrite(msg) == -1) return -1;
    }
 
    if (currentLogFile_ == NULL) {
        return -1;
    }
    if ((rc = fflush(currentLogFile_)) != 0) {
        return (-1);
    }
    return 0;
}
 
int FileLogAppender::logWrite(string msg) {
 
    int wroteLen = 0;
    int previousFileIndex = currentFileIndex_;
    if ((wroteLen = fwrite(msg.c_str(), sizeof(char), msg.length(),
         currentLogFile_)) != msg.length()) {
        FPRINTF(stdout, "Write to RITLOGxx unsuccessful. Switching to next log file.\n");
        pthread_t thid = pthread_self();
        // Don't continue unless the switch to the next log
        // file has occurred or until 4 seconds has elapsed.
        for (int times = 0; times < 4; times++) {
            sleep(1);
            if (previousFileIndex != currentFileIndex_) {
                // Now that the switch has occurred, retry the write.
                FPRINTF(stdout, "Retrying write to RITLOGxx\n");
                if((wroteLen = fwrite(msg.c_str(), sizeof(char), msg.length(),
                currentLogFile_)) == msg.length()) {
                    break;
                } else {
                    // If it failed writing to the new log file,
                    // give up.
                    FPRINTF(stdout, "Failure writing to RITLOGxx. \n");
                    return -1;
                }
            }
        }
    }
    return 0;
}
 
//*************************LogRouter********************************//
 
LogRouter::LogRouter(list<LogAppender*> & appenders,
        ::greenhat::vie::comms::proxy::LogEvent_Level level) :
        appenders_(appenders),
        maxLevel_(level){
 
}
 
LogRouter::~LogRouter() {
 
}
 
int LogRouter::logEvent(const LOGEVENT & event) {
    int rc = -1;
    if (appenders_.size() < 1) {
        return rc;
    }
    LogAppender* appender = appenders_.front();
    if (appender != NULL) {
        rc = appender->log(event);
    }
    return rc;
}
 
void LogRouter::setMaxLogLevel(
        ::greenhat::vie::comms::proxy::LogEvent_Level level) {
    this->maxLevel_ = level;
}
 
/**
 * Tests whether any of the appenders will accept events
 *  at the given log level
 *
 * @param level
 * @return bool
 */
bool LogRouter::accepts(
        greenhat::vie::comms::proxy::LogEvent_Level level) {
    return (level >= maxLevel_);
}
 
//*************************LogFactory********************************//
LoggerFactory* LoggerFactory::s_instance_ = NULL;
 
LoggerFactory::LoggerFactory() {
    this->logrouter_ = NULL;
    this->init();
}
 
LoggerFactory::~LoggerFactory() {
 
    if (loggers_.size()) {
        map<string, Logger*>::iterator it = loggers_.begin();
        for (; it != loggers_.end(); it++) {
            Logger* pLogger = (*it).second;
            DELETE(pLogger);
        }
    }
    if (logrouter_) {
        DELETE(logrouter_);
    }
    if (appenders_.size()) {
        list<LogAppender*>::iterator it = appenders_.begin();
        for (; it != appenders_.end(); it++) {
            LogAppender* appender = *it;
            DELETE(appender);
        }
        appenders_.clear();
    }
}
 
LoggerFactory* LoggerFactory::getInstance() {
    if (s_instance_ == NULL) {
        s_instance_ = new LoggerFactory();
    }
    return s_instance_;
}
 
void LoggerFactory::setLogLevel(
        ::greenhat::vie::comms::proxy::LogEvent_Level loglevel) {
    this->logrouter_->setMaxLogLevel(loglevel);
}
 
void LoggerFactory::destroy() {
    if (s_instance_) {
        DELETE(s_instance_);
    }
}
 
Logger* LoggerFactory::getLogger(const char* name) {
    string strLog(name);
    if (loggers_.empty()) {
        Logger* pLog = new Logger(strLog, this->logrouter_);
        loggers_.insert(std::pair<string, Logger*>(strLog, pLog));
        return pLog;
    }
    map<string, Logger*>::iterator it = loggers_.find(strLog);
    if (it == loggers_.end()) {
        Logger* pLog = new Logger(strLog, this->logrouter_);
        loggers_.insert(std::pair<string, Logger*>(strLog, pLog));
        return pLog;
    }
    return (*it).second;
}
 
void LoggerFactory::init() {
    vector<string> filelist;
    filelist.push_back(RITLOG_FILE_NAME1);
    filelist.push_back(RITLOG_FILE_NAME2);
    LogAppender* appender = new FileLogAppender(filelist);
 
    appenders_.push_back(appender);
    logrouter_ = new LogRouter(appenders_);
}
 
void LoggerFactory::flush() {
    if (appenders_.size()) {
        list<LogAppender*>::iterator it = appenders_.begin();
        for (; it != appenders_.end(); it++) {
            LogAppender* appender = *it;
            appender->flush();
        }
    }
}
 
/*
   While parts of this code were written to handle multiple
   LogAppenders, LoggerFactory only instantiates one
   FileLogAppender. This function only invokes getNextAvailableFile
   for that FileAppender. If LoggerFactory is ever updated to
   use multiple FileLogAppenders, this function will also
   need to be updated.
*/
void LoggerFactory::firstAppenderGetNextAvailableFile() {
   if (appenders_.size()) {
       LogAppender* appender = appenders_.front();
       appender->getNextAvailableFile();
   }
}
