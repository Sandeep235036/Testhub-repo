/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017.All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*******************************************************************************
 * ritcomm.cpp
 ******************************************************************************/
#pragma csect (CODE,"HRVCCOMM")
#define OPEN_DEFAULT 1
#define OPEN_SYS_EXT 1
#define _LARGE_TIME_API 1
#define _OPEN_THREADS 3
#define  _XOPEN_SOURCE 600
#define _OPEN_SYS 1
#define _ISOC99_SROURCE 1
#define _XOPEN_SOURCE_EXTENDED 1
#define _POSIX_SOURCE 1
#define _POSIX_C_SOURCE 200112L
#define _OPEN_SYS_MUTEX_EXT 1
#define _OPEN_SYS_ITOA_EXT 1
#include <sys/time.h>
#include <time.h>
#include <iconv.h>
 
#include "ritcomm.h"
#include "ritlog.h"
 
//#define DEBUG_RITCOMM  1
#define ICONV_EXTRA_SIZE 64
 
long g_lConnTimeOut = 0;
long g_lWaitTimeOut = 0;
long g_lLosSpeedTime = 0;
long g_lLosSpeedLimit = 0;
long g_TransferRetry = 0;
 
long getConnTimeout() {
    Logger* g_logger= LoggerFactory::getInstance()->getLogger("HRVCCICS");
    if(g_lConnTimeOut > 0){
        return g_lConnTimeOut;
    }
    char* envvar = NULL;
    envvar = getenv("RIT_CONNECT_TIMEOUT");
    if(envvar){
        FPRINTF(stdout, "Getenv RIT_CONNECT_TIMEOUT=%s\n", envvar);//$NON-NLS-1$
        if(g_logger){
            g_logger->info("Getenv RIT_CONNECT_TIMEOUT=%s", envvar);
        }
        g_lConnTimeOut = strtol(envvar, NULL, 10);
    }
    if(g_lConnTimeOut < RIT_DEFAULT_CONNECT_TIMEOUT){
        g_lConnTimeOut = RIT_DEFAULT_CONNECT_TIMEOUT;
    }
    return g_lConnTimeOut;
}
 
long getTranferRetry(){
    Logger* g_logger= LoggerFactory::getInstance()->getLogger("HRVCCICS");
    if(g_TransferRetry > 0){
        return g_TransferRetry;
    }
    char* envvar = NULL;
    envvar = getenv("RIT_TRANSFER_RETRY");
    if(envvar){
        FPRINTF(stdout, "Getenv RIT_TRANSFER_RETRY=%s\n", envvar);//$NON-NLS-1$
        g_TransferRetry = strtol(envvar, NULL, 10);
        if(g_logger){
            g_logger->info("Getenv RIT_TRANSFER_RETRY=%s", envvar);
        }
    }
    if(g_TransferRetry < RIT_DEFAULT_TRANSFER_RETRY){
        g_TransferRetry = RIT_DEFAULT_TRANSFER_RETRY;
    }
    return g_TransferRetry;
}
 
long getLowSpeedTime(){
    Logger* g_logger= LoggerFactory::getInstance()->getLogger("HRVCCICS");
    if(g_lLosSpeedTime > 0){
        return g_lLosSpeedTime;
    }
    char* envvar = NULL;
    envvar = getenv("RIT_LOW_SPEED_TIME");
    if(envvar){
        FPRINTF(stdout, "Getenv RIT_LOW_SPEED_TIME=%s\n", envvar);//$NON-NLS-1$
        g_lLosSpeedTime = strtol(envvar, NULL, 10);
        if(g_logger){
            g_logger->info("Getenv RIT_LOW_SPEED_TIME=%s", envvar);
        }
    }
    if(g_lLosSpeedTime < RIT_DEFAULT_LOW_SPEED_TIME){
        g_lLosSpeedTime = RIT_DEFAULT_LOW_SPEED_TIME;
    }
    return g_lLosSpeedTime;
}
 
long getLowSpeedLimit(){
    Logger* g_logger= LoggerFactory::getInstance()->getLogger("HRVCCICS");
 
    if(g_lLosSpeedLimit > 0){
        return g_lLosSpeedLimit;
    }
    char* envvar = NULL;
    envvar = getenv("RIT_LOW_SPEED_LIMIT");
    if(envvar){
        FPRINTF(stdout, "Getenv RIT_LOW_SPEED_LIMIT=%s\n", envvar);//$NON-NLS-1$
        g_lLosSpeedLimit = strtol(envvar, NULL, 10);
        if(g_logger){
            g_logger->info("Getenv RIT_LOW_SPEED_LIMIT=%s", envvar);
        }
    }
    if(g_lLosSpeedLimit < RIT_DEFAULT_LOW_SPEED_LIMIT){
        g_lLosSpeedLimit = RIT_DEFAULT_LOW_SPEED_LIMIT;
    }
    return g_lLosSpeedLimit;
 
}
 
long getWaitTimeout() {
    if(g_lWaitTimeOut > 0){
        return g_lWaitTimeOut;
    }
    char* envvar = NULL;
    envvar = getenv("RIT_WAIT_TIMEOUT");
    if(envvar){
        FPRINTF(stdout, "Getenv RIT_WAIT_TIMEOUT=%s\n", envvar);//$NON-NLS-1$
        g_lWaitTimeOut = strtol(envvar, NULL, 10);
    }
    if(g_lWaitTimeOut < RIT_DEFAULT_WAIT_TIMEOUT){
        g_lWaitTimeOut = RIT_DEFAULT_WAIT_TIMEOUT;
    }
    return g_lWaitTimeOut;
}
 
MutexGuard::MutexGuard(pthread_mutex_t * pMtx, Logger* log)
:pMutex_(pMtx), log_(log){
    if (pthread_mutex_lock(pMutex_) != 0) {
        log_->error("Error in pthread_mutex_lock");//$NON-NLS-1$
    }
}
 
MutexGuard::~MutexGuard(){
    if (pthread_mutex_unlock(pMutex_) != 0) {
        log_->error("Error in pthread_mutex_unlock");//$NON-NLS-1$
    }
}
 
CICSRegistration* CICSRegistration::s_instance = NULL;
 
CICSRegistration::CICSRegistration(const string & applid,
        const string & bindaddr,
        const string & hostname,
        int   port,
        const string & serverurl,
        greenhat::vie::comms::proxy::LogEvent_Level loglevel,
        RIT_OBSERV_LEVEL observLevel,
        int   rtcpMaxErrnum,
        int   exciMaxErrnum,
        const string & gsk_keyring_ring,
        int   debugStubCA)
: applid_(applid),
  bindaddr_(bindaddr),
  hostname_(hostname),
  port_(port),
  server_url_(serverurl),
  loglevel_(loglevel),
  observ_(observLevel),
  rtcpMaxErrnum_(rtcpMaxErrnum),
  exciMaxErrnum_(exciMaxErrnum),
  enabled_(0),
  uuid_(""),
  gsk_keyring_ring_(gsk_keyring_ring),
  debugStubCA_(debugStubCA)
{
    log_ = LoggerFactory::getInstance()->getLogger("CICSRegistration");//$NON-NLS-1$
 
    int rc = pthread_rwlockattr_init(&rwlattr_);
    if (rc == -1) {
        log_->error("Error in pthread_rwlockattr_init");//$NON-NLS-1$
        FPRINTF(stdout, "pthread_rwlockattr_init error, errno=%d. Exiting...\n", errno);
        exit(EXIT_FAILURE);
    }
    rc = pthread_rwlockattr_setpshared(&rwlattr_, PTHREAD_PROCESS_PRIVATE);
    if (rc == -1) {
        log_->error("Error in pthread_rwlockattr_setpshared");//$NON-NLS-1$
        FPRINTF(stdout, "pthread_rwlockattr_setpshared error, errno=%d. Exiting...\n", errno);
        exit(EXIT_FAILURE);
    }
    rc = pthread_rwlock_init(&loglvllock_, &rwlattr_);
    if (rc == -1) {
        log_->error("Error in pthread_rwlock_init");//$NON-NLS-1$
        FPRINTF(stdout, "pthread_rwlock_init error, errno=%d. Exiting...\n", errno);//$NON-NLS-1$
        exit(EXIT_FAILURE);
    }
    rc = pthread_rwlock_init(&obsvlvllock_, &rwlattr_);
    if (rc == -1) {
        log_->error("Error in pthread_rwlock_init");//$NON-NLS-1$
        FPRINTF(stdout, "pthread_rwlock_init error, errno=%d. Exiting...\n", errno);//$NON-NLS-1$
        exit(EXIT_FAILURE);
    }
    rc = pthread_rwlock_init(&uuidlock_, &rwlattr_);
    if (rc == -1) {
        log_->error("Error in pthread_rwlock_init");//$NON-NLS-1$
        FPRINTF(stdout, "pthread_rwlock_init error, errno=%d. Exiting...\n", errno);//$NON-NLS-1$
        exit(EXIT_FAILURE);
    }
    rc = pthread_rwlock_init(&statuslock_, &rwlattr_);
    if (rc == -1) {
        log_->error("Error in pthread_rwlock_init");//$NON-NLS-1$
        FPRINTF(stdout, "pthread_rwlock_init error, errno=%d. Exiting...\n", errno);//$NON-NLS-1$
        exit(EXIT_FAILURE);
    }
    if (pthread_mutex_init(&mtxCorrel_, NULL) != 0) {
        log_->error("Error in pthread_mutex_init");//$NON-NLS-1$
        FPRINTF(stdout, "pthread_mutex_init error, errno=%d. Exiting...\n", errno);//$NON-NLS-1$
        exit(EXIT_FAILURE);
    }
    char *initstate(unsigned seed, char *state, size_t size);
 
}
 
CICSRegistration::~CICSRegistration() {
    if (pthread_rwlock_destroy(&obsvlvllock_) == -1) {
        log_->error("Error in pthread_rwlock_destroy obsvlvllock_");//$NON-NLS-1$
    }
    if (pthread_rwlock_destroy(&loglvllock_) == -1) {
        log_->error("Error in pthread_rwlock_destroy loglvllock_");//$NON-NLS-1$
    }
    if (pthread_rwlock_destroy(&uuidlock_) == -1) {
        log_->error("Error in pthread_rwlock_destroy uuidlock_");//$NON-NLS-1$
    }
    if (pthread_rwlock_destroy(&statuslock_) == -1) {
        log_->error("Error in pthread_rwlock_destroy statuslock_");//$NON-NLS-1$
    }
    if (pthread_rwlockattr_destroy(&rwlattr_) == -1) {
        log_->error("Error in pthread_rwlockattr_destroy");//$NON-NLS-1$
    }
}
 
CICSRegistration* CICSRegistration::instance(CICSAgentConfig* config) {
    if (s_instance == NULL) {
        s_instance = new CICSRegistration(config->applid_,
                config->bindaddr_,
                config->hostname_,
                config->port_,
                config->server_url_,
                config->loglevel_,
                config->observ_,
                config->rtcpMaxErrnum_,
                config->exciMaxErrnum_,
                config->gsk_keyring_ring_,
                config->debugStubCA_);
    }
    return s_instance;
}
 
CICSRegistration* CICSRegistration::getInstance() {
    return s_instance;
}
 
string CICSRegistration::uuid(){
    int rc = pthread_rwlock_rdlock(&uuidlock_);
    if (rc == -1) {
        log_->error("Error in pthread_rwlock_rdlock");//$NON-NLS-1$
    }
    string id = uuid_;
    rc = pthread_rwlock_unlock(&uuidlock_);
    if (rc == -1) {
        log_->error("Error in pthread_rwlock_unlock");//$NON-NLS-1$
    }
    return id;
}
 
int CICSRegistration::status(){
    return enabled_;
//    int rc = pthread_rwlock_rdlock(&statuslock_);
////    if (rc == -1) {
////        log_->error("Error in pthread_rwlock_rdlock");//$NON-NLS-1$
////    }
//    int status = enabled_;
//    rc = pthread_rwlock_unlock(&statuslock_);
////    if (rc == -1) {
////        log_->error("Error in pthread_rwlock_unlock");//$NON-NLS-1$
////    }
//    return status;
}
 
greenhat::vie::comms::proxy::LogEvent_Level CICSRegistration::logLevel() {
    int rc = pthread_rwlock_rdlock(&loglvllock_);
    if (rc == -1) {
        log_->error("Error in pthread_rwlock_rdlock");//$NON-NLS-1$
    }
    greenhat::vie::comms::proxy::LogEvent_Level lvl = loglevel_;
    rc = pthread_rwlock_unlock(&loglvllock_);
    if (rc == -1) {
        log_->error("Error in pthread_rwlock_unlock");//$NON-NLS-1$
    }
    return lvl;
}
 
void CICSRegistration::setLogLevel(greenhat::vie::comms::proxy::LogEvent_Level level) {
    int rc = pthread_rwlock_wrlock(&loglvllock_);
    if (rc == -1) {
        log_->error("Error in pthread_rwlock_wrlock");//$NON-NLS-1$
    }
    loglevel_ = level;
    rc = pthread_rwlock_unlock(&loglvllock_);
    if (rc == -1) {
        log_->error("Error in pthread_rwlock_unlock");//$NON-NLS-1$
    }
}
RIT_OBSERV_LEVEL CICSRegistration::observLevel() {
    int rc = pthread_rwlock_rdlock(&obsvlvllock_);
    if (rc == -1) {
        log_->error("Error in pthread_rwlock_rdlock");//$NON-NLS-1$
    }
    RIT_OBSERV_LEVEL lvl = observ_;
    rc = pthread_rwlock_unlock(&obsvlvllock_);
    if (rc == -1) {
        log_->error("Error in pthread_rwlock_unlock");//$NON-NLS-1$
    }
    return lvl;
}
 
void CICSRegistration::setObservLevel(RIT_OBSERV_LEVEL level) {
    int rc = pthread_rwlock_wrlock(&obsvlvllock_);
    if (rc == -1) {
        log_->error("Error in pthread_rwlock_wrlock");//$NON-NLS-1$
    }
    observ_ = level;
    rc = pthread_rwlock_unlock(&obsvlvllock_);
    if (rc == -1) {
        log_->error("Error in pthread_rwlock_unlock");//$NON-NLS-1$
    }
}
 
void CICSRegistration::setId(const string & id) {
    int rc = pthread_rwlock_wrlock(&loglvllock_);
    if (rc == -1) {
        log_->error("Error in pthread_rwlock_wrlock");//$NON-NLS-1$
    }
    uuid_.assign(id);
    rc = pthread_rwlock_unlock(&loglvllock_);
    if (rc == -1) {
        log_->error("Error in pthread_rwlock_unlock");//$NON-NLS-1$
    }
}
 
void CICSRegistration::setStatus(int status) {
    int rc = pthread_rwlock_wrlock(&statuslock_);
    if (rc == -1) {
        log_->error("Error in pthread_rwlock_wrlock");//$NON-NLS-1$
    }
    enabled_ = status;
    rc = pthread_rwlock_unlock(&statuslock_);
    if (rc == -1) {
        log_->error("Error in pthread_rwlock_unlock");//$NON-NLS-1$
    }
}
 
string & CICSRegistration::getCorrelID(const char* inCorrel){
    MutexGuard mtxGuard(&mtxCorrel_, log_);
    map<string,string>::iterator it = correlMap_.find(inCorrel);
    if(it != correlMap_.end()){
        currCorel_ = correlMap_[inCorrel];
        correlMap_.erase(it);
        return currCorel_;
    }
 
    struct timeval64 ltimeval;
    int rc = gettimeofday64(&ltimeval, NULL);
    if(rc != 0){
        log_->error("Error in gettimeofday64");//$NON-NLS-1$
    }else{
        srandom(ltimeval.tv_sec);
        int rand1 = random();
        srandom(ltimeval.tv_usec);
        int rand2 = random();
        char buffer[17] = {0};
        sprintf(buffer, "%8.8X%8.8X", rand1, rand2);
        correlMap_[inCorrel] = buffer;
    }
    return correlMap_[inCorrel];
}
 
char* trimBlank(char* str){
    int len = strlen(str);
    int i = 0;
    for (; i < len; i++) {
        if (str[i] != ' ') {
            break;
        }
    }
    if(i == 0){
        return trimTailBlank(str);
    } else {
        strncpy(str, str + i, len - i);
        str[len - i] = 0;
        return trimTailBlank(str);
    }
}
 
string& trimString(string& str){
    char* pBuf = new char[str.length() + 1];
    memset(pBuf, 0, str.length() + 1);
    strcpy(pBuf, str.c_str());
    trimBlank(pBuf);
    str.assign(pBuf);
 // delete(pBuf);
    delete[] pBuf;
    return str;
}
 
char* trimPreBlank(char* str){
    int len = strlen(str);
    int i = 0;
    for (; i < len; i++) {
        if (str[i] != ' ') {
            break;
        }
    }
    if(i == 0)
        return str;
    strncpy(str, str + i, len - i);
    str[len - i] = 0;
    return str;
}
 
char* trimTailBlank(char* str) {
    int len = strlen(str);
    for (int i = len - 1 ; i >= 0; i--) {
        if (str[i] == ' ') {
            str[i] = '\0';//$NON-NLS-1$
        }else{
            break;
        }
    }
    return str;
}
 
int convert(const char* fromCode, const char* toCode, const char* from,
        size_t inlen, char** to, size_t* outlen) {
    iconv_t cd; /* conversion descriptor          */
    size_t inleft; /* number of bytes left in inbuf  */
    int rc; /* return code of iconv()         */
    if ((cd = iconv_open(toCode, fromCode)) == (iconv_t)(-1)) {
        return (-1001);
    }
    inleft = inlen;
    *outlen = inlen + ICONV_EXTRA_SIZE;
    char* inptr = (char*) from;
 
    *to = new char[*outlen];
    if (*to != 0) {
        memset(*to, 0, *outlen);
    } else {
        *to = 0;
        return (-1003);
    }
    char* outptr = (char*) *to;
    rc = iconv(cd, &inptr, &inleft, &outptr, outlen);
    if (rc == -1) {
        delete (*to);
        *to = 0;
        return (-1002);
    }
    iconv_close(cd);
    (*to)[inlen] = 0;
    return 0;
}
 
int asc2ebc(const char* from, size_t inlen, char** to, size_t* outlen) {
    const char* fromCode = "ISO8859-1";//$NON-NLS-1$
    const char* toCode = "IBM-1047";//$NON-NLS-1$
    return convert(fromCode, toCode, from, inlen, to, outlen);
}
 
int ebc2asc(const char* from, size_t inlen, char** to, size_t* outlen) {
    const char* fromCode = "IBM-1047";//$NON-NLS-1$
    const char* toCode = "ISO8859-1";//$NON-NLS-1$
    return convert(fromCode, toCode, from, inlen, to, outlen);
}
 
int utf2ebc(const char* from, size_t inlen, char** to, size_t* outlen) {
    const char* fromCode = "IBM-1208";//$NON-NLS-1$
    const char* toCode = "IBM-1047";//$NON-NLS-1$
    return convert(fromCode, toCode, from, inlen, to, outlen);
}
 
int ebc2utf(const char* from, size_t inlen, char** to, size_t* outlen) {
    const char* fromCode = "IBM-1047";//$NON-NLS-1$
    const char* toCode = "IBM-1208";//$NON-NLS-1$
    return convert(fromCode, toCode, from, inlen, to, outlen);
}
 
int ebc2asc(const char* inStr, string & out) {
    char* from = (char*) inStr;
    size_t inlen = strlen(inStr);
    char* to = 0;
    size_t outlen = 0;
    int rc = ebc2asc(from, inlen, &to, &outlen);
    if (rc == 0) {
        out.clear();
        out.append(to);
    }
    delete (to);
    return rc;
}
 
int ebc2asc(const string& inStr, string& out) {
    char* from = (char*) inStr.c_str();
    size_t inlen = inStr.length();
    char* to = 0;
    size_t outlen = 0;
    int rc = ebc2asc(from, inlen, &to, &outlen);
    if (rc == 0) {
        out.clear();
        out.append(to);
    }
    delete (to);
    return rc;
}
 
int ebc2utf(const char* inStr, string& out) {
    char* from = (char*) inStr;
    size_t inlen = strlen(inStr);
    char* to = 0;
    size_t outlen = 0;
    int rc = ebc2utf(from, inlen, &to, &outlen);
    if (rc == 0) {
        out.clear();
        out.append(to);
    }
    delete (to);
    return rc;
}
 
int ebc2utf(const string& inStr, string& out) {
    char* from = (char*) inStr.c_str();
    size_t inlen = inStr.length();
    char* to = 0;
    size_t outlen = 0;
    int rc = ebc2utf(from, inlen, &to, &outlen);
    if (rc == 0) {
        out.clear();
        out.append(to);
    }
    delete (to);
    return rc;
}
 
int asc2ebc(const char* inStr, string& out) {
    char* from = (char*) inStr;
    size_t inlen = strlen(inStr);
    char* to = 0;
    size_t outlen = 0;
    int rc = asc2ebc(from, inlen, &to, &outlen);
    if (rc == 0) {
        out.clear();
        out.append(to);
    }
    delete (to);
    return rc;
}
 
int asc2ebc(const string& inStr, string& out) {
    char* from = (char*) inStr.c_str();
    size_t inlen = inStr.length();
    char* to = 0;
    size_t outlen = 0;
    int rc = asc2ebc(from, inlen, &to, &outlen);
    if (rc == 0) {
        out.clear();
        out.append(to);
    //  (to, strlen(to));
        (strlen(to));
    }
    delete (to);
    return rc;
}
 
int utf2ebc(const char* inStr, string& out) {
    char* from = (char*) inStr;
    size_t inlen = strlen(inStr);
    char* to = 0;
    size_t outlen = 0;
    int rc = utf2ebc(from, inlen, &to, &outlen);
    if (rc == 0) {
        out.clear();
        out.append(to);
    }
    delete (to);
    return rc;
}
 
int utf2ebc(const string& inStr, string & out) {
    char* from = (char*) inStr.c_str();
    size_t inlen = inStr.length();
    char* to = 0;
    size_t outlen = 0;
    int rc = utf2ebc(from, inlen, &to, &outlen);
    if (rc == 0) {
        out.clear();
        out.append(to);
    }
    delete (to);
    return rc;
}
 
 #include <functional>
string & lowerString(string & inStr) {
  //transform(inStr.begin(), inStr.end(), inStr.begin(), tolower);
  transform(inStr.begin(), inStr.end(), inStr.begin(), ::tolower);
    return inStr;
}
 
 
string & upperString(string & inStr) {
 // transform(inStr.begin(), inStr.end(), inStr.begin(), toupper);
    transform(inStr.begin(), inStr.end(), inStr.begin(), ::toupper);
    return inStr;
}
 
/*  Convert a string to BCD string
 *  the len is the from string len
 *  the size of the toStr should large then 2 * len
 */
char* toBcdStr(const char* fromStr, char* toStr, int len){
    for(int i = 0; i < len; i++){
        char pt = (char)fromStr[i];
        sprintf(toStr + i * 2, "%2X", pt);
    }
    toStr[len * 2 + 1] = 0;
    return toStr;
}
 
size_t record_read(void *ptr, size_t size, size_t nmemb, void *userp) {
 
    struct ObjectToSend *objSend = (struct ObjectToSend *) userp;
 
    if (size * nmemb < 1)
        return 0;
 
    if (objSend->sizeleft) {
        *(char *) ptr = objSend->readptr[0];
        objSend->readptr++;
        objSend->sizeleft--;
        return 1;
    }
 
    return 0;
}
 
size_t stub_read(void *ptr, size_t size, size_t nmemb, void *userp) {
 
    struct ObjectToSend *objSend = (struct ObjectToSend *) userp;
 
    size_t sendSize = size*nmemb;
    if (sendSize==0)
        return 0;
 
    size_t bytesToSend;
    if (objSend->sizeleft>=sendSize) bytesToSend=sendSize;
    else bytesToSend=objSend->sizeleft;
 
    memcpy(ptr,objSend->readptr,bytesToSend);
    objSend->readptr=objSend->readptr+bytesToSend;
    objSend->sizeleft=objSend->sizeleft-bytesToSend;
 
    return bytesToSend;
}
 
size_t record_write(void *buffer, size_t size, size_t nmemb, void *userp) {
    Logger* log = LoggerFactory::getInstance()->getLogger("ritcomm");//$NON-NLS-1$
 
    ObjectReceived* pRecv = (ObjectReceived*) userp;
 
    size_t len = size * nmemb;
    size_t newLen = len + pRecv->len;
    pRecv->ptr = (char*) realloc(pRecv->ptr, newLen + 1);
    if (pRecv->ptr == NULL) {
        log->error("record_write realloc() failed\n");//$NON-NLS-1$
        FPRINTF(stdout, "realloc error, errno=%d. Exiting...\n", errno);//$NON-NLS-1$
        exit(MEMORY_ALLOC_FAILURE);
    }
    memcpy(pRecv->ptr + pRecv->len, buffer, len);
    pRecv->ptr[newLen] = '\0';//$NON-NLS-1$
    pRecv->len = newLen;
 
    return len;
}
 
size_t header_write(void *buffer, size_t size, size_t nmemb, void *userdata) {
    Logger* log = LoggerFactory::getInstance()->getLogger("ritcomm");//$NON-NLS-1$
 
    ObjectReceived* pRecv = (ObjectReceived*) userdata;
 
    size_t len = size * nmemb;
    size_t newLen = len + pRecv->len;
    pRecv->ptr = (char*) realloc(pRecv->ptr, newLen + 1);
    if (pRecv->ptr == NULL) {
        log->error("header_write realloc() failed\n");//$NON-NLS-1$
        FPRINTF(stdout, "realloc error, errno=%d. Exiting...\n", errno);//$NON-NLS-1$
        exit(MEMORY_ALLOC_FAILURE);
    }
    memcpy(pRecv->ptr + pRecv->len, buffer, len);
    pRecv->ptr[newLen] = '\0';
    pRecv->len = newLen;
 
    return len;
}
 
int getHeaderField(const ObjectReceived & http_resp_header, const char * header,
        string & value) {
    char* token = strtok(http_resp_header.ptr, "\r\n");//$NON-NLS-1$
    do {
        string PASS_THROUGH;
        ebc2asc(RIT_HTTP_HEADER_PASS_THROUGH,PASS_THROUGH);
      /*if (strstr(token, RIT_HTTP_HEADER_PASS_THROUGH) == NULL) {
            continue;
        } */
        if (strstr(token, PASS_THROUGH.c_str()) == NULL) {
            continue;
        }
        token += strlen(RIT_HTTP_HEADER_PASS_THROUGH);
        value.assign(token, strlen(token));
        return 0;
    } while((token = strtok(NULL, "\r\n")));//$NON-NLS-1$
    return -1;
}
 
int enableRit(CICSRegistration* cicsreg, Logger* log, int cmd)
{
    int rc;
    string applid;
    string ebcAddr;
  /*if ((rc = asc2ebc(cicsreg->bindAddr(), ebcAddr)) != 0){
        log->error("asc2ebc for bind address error, rc=%d", rc);//$NON-NLS-1$
    }
    if ((rc = asc2ebc(cicsreg->applid(), applid)) != 0) {
        log->error("asc2ebc for applid error, rc=%d", rc);//$NON-NLS-1$
    } */
 
    applid = cicsreg->applid();
    RITMCOMM commArea;
    strncpy(commArea.bindaddr, cicsreg->bindAddr().c_str(),
        RIT_MAX_BIND_ADDR_LEN);
    memset((void*)(&commArea), 0, sizeof(commArea));
    commArea.port = cicsreg->port();
    commArea.command = cmd;
 // strncpy(commArea.bindaddr, ebcAddr.c_str(),
 //     RIT_MAX_BIND_ADDR_LEN);
 
    log->debug("Calling enabcrit() to %s HRVCEXIT",//$NON-NLS-1$
            cmd == RIT_DISABLE_CMD ? "disable" :
            cmd == RIT_ENABLE_CMD ? "enable" : "connect");//$NON-NLS-1$
    rc = enabcrit(&commArea, applid.c_str());
    if (rc != 0) {
        log->error("Call enabcrit failed. Return code is: %d", rc);//$NON-NLS-1$
        FPRINTF(stdout, "Call enabcrit failed. Return code is: %d\n", rc);//$NON-NLS-1$
        FPRINTF(stdout,
        "Please check CICS region and the RIT resources are active.\n");//$NON-NLS-1$
        // exit(EXIT_FAILURE);
    }else{
        cicsreg->setStatus(commArea.status);
        if(commArea.status == RIT_ENABLE_CMD){
            string eSysid, aSysid;
            eSysid.assign(commArea.sysid, 4);
            ebc2asc(eSysid, aSysid);
         // log->debug("Set SYSID to '%s'", aSysid.c_str());
            log->debug("Set SYSID to '%s'", eSysid.c_str());
         // FPRINTF(stdout, "Got SYSID: '%s'.\n", aSysid.c_str());//$NON-NLS-1$
            FPRINTF(stdout, "Got SYSID: '%s'.\n", eSysid.c_str());//$NON-NLS-1$
 
         // cicsreg->setSYSID(aSysid);
            cicsreg->setSYSID(eSysid);
 
            string eJobname, aJobname;
            eJobname.assign(commArea.jobname, 8);
            ebc2asc(eJobname, aJobname);
            log->debug("Set JOBNAME to '%s'", eJobname.c_str());
        //  log->debug("Set JOBNAME to '%s'", aJobname.c_str());
            FPRINTF(stdout, "Got JOBNAME: '%s'.\n", eJobname.c_str());//$NON-NLS-1$
        //  FPRINTF(stdout, "Got JOBNAME: '%s'.\n", aJobname.c_str());//$NON-NLS-1$
 
         // cicsreg->setJOBNAME(aJobname);
            cicsreg->setJOBNAME(eJobname);
        }
        log->info("Call enabcrit succeeds. HRVCCICS agent is now %s.",//$NON-NLS-1$
                commArea.status == RIT_ENABLE_CMD ? "enabled" :
                commArea.status == RIT_TESTCONN_CMD ? "connected" : "disabled");//$NON-NLS-1$
    }
    return commArea.status;
}
 
 
int fprintf_mvs(FILE* stream,  const char * format, ...){
    char     buf[MAX_LOG_MESSAGE_LEN] = {0};
    va_list         nextArg;
    va_start(nextArg, format);
    vsnprintf(buf, MAX_LOG_MESSAGE_LEN, format, nextArg);
    va_end(nextArg);
  //string msg;
    std::string msg = buf;
 /* if(asc2ebc(buf, msg) != 0){
        fprintf(stdout, "asc2ebc error. Errno=%d, file=%s, line=%d",
                errno, __FILE__, __LINE__);
    }*/
    int rc = fputs(msg.c_str(), stream);
    fflush(stream);
    return rc;
  //return fprintf(stream, msg.c_str());
}
