/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017.All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*
 * sockthmg.cpp
 *
 *  Created on: 2016-5-24
 *      Author: martin
 */
#pragma csect (CODE,"HRVCTHMG")
#define OPEN_DEFAULT 1
#define OPEN_SYS_EXT 1
#define _LARGE_TIME_API 1
#define _OPEN_THREADS 3
#define  _XOPEN_SOURCE 600
#define _OPEN_SYS 1
#define _ISOC99_SROURCE 1
#define _XOPEN_SOURCE_EXTENDED 1
#define _POSIX_SOURCE 1
#define _POSIX_C_SOURCE 200112L
#define _OPEN_SYS_MUTEX_EXT 1
#define _OPEN_SYS_ITOA_EXT 1
#include "sockthmg.h"
 
SockThreadManager::SockThreadManager(void* (*handler)(int)) {
    int rc = 0;
    this->logger_ = LoggerFactory::getInstance()->getLogger(
            "SockThreadManager");
 
    rc = pthread_mutexattr_init(&mutexattr_);
    if (rc != 0) {
        logger_->error("Failed to initialize mutexattr. %s",
                strerror(errno));
        throw string("Failed to initialize SockThreadManager");
    }
    rc = pthread_mutexattr_setkind_np(&mutexattr_,
            __MUTEX_RECURSIVE + __MUTEX_NODEBUG);
    if (rc != 0) {
        logger_->error("Failed to set attribute for mutexattr. %s",
                strerror(errno));
        throw string("Failed to initialize SockThreadManager");
    }
    rc = pthread_mutexattr_setpshared(&mutexattr_,PTHREAD_PROCESS_SHARED );
    if (rc != 0) {
        logger_->error("Failed to set attribute for mutexattr. %s",
                strerror(errno));
        throw string("Failed to initialize SockThreadManager");
    }
    rc = pthread_mutex_init(&mutex_, &mutexattr_);
    if (rc != 0) {
        logger_->error("Failed to initialize mutex. %s",
                strerror(errno));
        throw string("Failed to initialize SockThreadManager");
    }
    rc = pthread_condattr_init(&cond_attr_);
    if (rc != 0) {
        logger_->error("Failed to initialize thread condition. %s",
                strerror(errno));
        throw string("Failed to initialize SockThreadManager");
    }
    rc = pthread_condattr_setpshared(&cond_attr_,PTHREAD_PROCESS_SHARED);
    if ( rc != 0) {
        logger_->error("Failed to initialize thread condition. %s",
                strerror(errno));
        throw string("Failed to initialize SockThreadManager");
    }
    rc = pthread_condattr_setkind_np(&cond_attr_, __COND_NODEBUG);
    if ( rc != 0) {
        logger_->error("Failed to initialize thread condition. %s",
                strerror(errno));
        throw string("Failed to initialize SockThreadManager");
    }
    rc = pthread_cond_init(&cond_, &cond_attr_);
    if (rc != 0) {
        logger_->error("Failed to initialize thread condition. %s",
                strerror(errno));
        throw string("Failed to initialize SockThreadManager");
    }
    rc = pthread_attr_init(&thread_attr_);
    if (rc != 0) {
        logger_->error("Failed to initialize thread attribute. %s",
                strerror(errno));
        throw string("Failed to initialize SockThreadManager");
    }
    this->handler = handler;
    seq_=0;
}
 
SockThreadManager::~SockThreadManager() {
    stopWorker();
    for (std::deque<int>::iterator it = eventQueue_.begin();
            it != eventQueue_.end(); ++it) {
        close(*it);
    }
    pthread_cond_destroy(&cond_);
    pthread_condattr_destroy(&cond_attr_);
    pthread_mutex_destroy(&mutex_);
    pthread_mutexattr_destroy(&mutexattr_);
    pthread_attr_destroy(&thread_attr_);
}
 
int SockThreadManager::scheduleTask(int fd) {
    int rc = pthread_mutex_lock(&mutex_);
    if (rc != 0) {
        throw string("lock mutex failed.");
    }
    eventQueue_.push_back(seq_++);
    eventQueue_.push_back(fd);
    if (pthread_cond_signal(&cond_) != 0) {
        throw string("send signal failed");
    }
    rc = pthread_mutex_unlock(&mutex_);
    if (rc != 0) {
        throw string("unlock mutex failed");
    }
 
    return 0;
}
 
int SockThreadManager::consumeTask() {
    int fd=-1;
    int rc = pthread_mutex_lock(&mutex_);
    if (rc != 0) {
        throw string("lock mutex failed.");
    }
    while (eventQueue_.size() == 0 || rc ==-1) {
        errno =0  ;
        int recreson=0;
        rc =pthread_cond_wait(&cond_, &mutex_);
        if(rc != 0){
            int reccode = errno;
            recreson = __errno2();
            if (errno == EINVAL) {
                throw string("cond wait failed.");
            }else if (errno == EPERM)
                throw string("cond wait failed.");
        }
 
    }
    int seq = eventQueue_.front();
    eventQueue_.pop_front();
    fd = eventQueue_.front();
    eventQueue_.pop_front();
    rc = pthread_mutex_unlock(&mutex_);
    if (rc != 0) {
        throw string("unlock mutex failed");
    }
    return fd;
}
 
int SockThreadManager::startWorker(int workers) {
    int rc = 0;
    for (int times = 0; times < workers; times++) {
        pthread_t pid;
        rc = pthread_create(&pid, &thread_attr_,
                &workerThread, this);
        if (rc == 0) {
            this->workerpool_.push_back(pid);
        }
    }
    return workerpool_.size();
}
 
void SockThreadManager::stopWorker() {
    int size = workerpool_.size();
    int rc = 0;
    for (int index = 0; index < size; index++) {
        rc = pthread_kill(workerpool_[index], 0);
        if (rc == 0) {
            pthread_cancel(workerpool_[index]);
            pthread_join(workerpool_[index], NULL);
            logger_->debug("Worker Thread %lu is canceled.",
                    workerpool_[index]);
        }
    }
 
}
 
void* workerThread(void* ptr) {
    SockThreadManager* manager = reinterpret_cast<SockThreadManager*>(ptr);
    Logger* logger = LoggerFactory::getInstance()->getLogger(
            "WorkerThread");
    logger->info("Worker thread is started. Thread id is %lu.\n",
            pthread_self());
    while (true) {
        int fd = manager->consumeTask();
        if (fd > 0) {
            SocketHandler handler = manager->getHandler();
            (*handler)(fd);
        }
        pthread_testcancel();
    }
    return NULL;
}
