/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017.All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*******************************************************************************
 * cndtion.cpp
 ******************************************************************************/
#pragma csect (CODE,"HRVCCNDT")
#include "cndtion.h"
#include "ritlog.h"
#include "proxy.h"
#include <vector>
#include <string>
 
using namespace std;
 
// #define DEBUG_CNDTION 1
 
CICSAgentCondition::CICSAgentCondition(const string & url,
        const string & activityId, bool isRouting) :
        url_(url), activityId_(activityId), isRouting_(isRouting), isTS_(false) {
    log_ = LoggerFactory::getInstance()->getLogger(
            "CICSAgentCondition"); //$NON-NLS-1$
}
 
bool CICSAgentCondition::matches(const AscHeader& header) const {
    string pgmName,tranID,pName,tID;
    asc2ebc(header.progName,pgmName);
    asc2ebc(header.tranID,tranID);
    pName = pgmName;
    tID   = tranID;
#ifdef DEBUG_CNDTION
    FPRINTF(stdout, ">>> CICSAgentCondition::matches\n"); //$NON-NLS-1$
    FPRINTF(stdout, "Header program=%s tranID=%s\n",
        header.progName, header.tranID);//$NON-NLS-1$
#endif
    if (filter_.size() < 1) {
        return true; // if filter=null, we think that's to record all
    }
    char currProgram[9] = "";
 // strncpy(currProgram, header.progName, 8);
    strncpy(currProgram, pName.c_str(), 8);
    trimBlank(currProgram);
    bool programMatch = false;
    bool tranidMatch = false;
    char * token = 0;
    int len = strlen(currProgram);
    if (ignProgs_.find(currProgram) != ignProgs_.end()) {
        log_->debug("Ignore programs filtered out program: %s", currProgram); //$NON-NLS-1$
        return false;
    }
 
    vector<string>::const_iterator itr = filter_.begin();
 
    // put record rules 1st to keep it as the lower priority
    for (; itr != filter_.end(); itr++) {
        char programName[RIT_PROGRAM_RULE_LEN];
        strcpy(programName, (*itr).substr(0, 8).c_str());
        trimBlank(programName);
#ifdef DEBUG_CNDTION
    FPRINTF(stdout, "Current program rule=%s\n", programName);//$NON-NLS-1$
#endif
        char * currProgRule = programName;
        if (strlen(currProgRule) < 2) { // only 1 char
            if (strcmp(currProgRule, "*") == 0) { //*//$NON-NLS-1$
                programMatch = true;
            } else if (!strcmp(currProgram, currProgRule)) {
                programMatch = true;
            }
        } else if (currProgRule[0] == '*'
                && currProgRule[strlen(currProgRule) - 1] == '*') { //*ABCE* or **
                // Match middle of strings
            string prog(currProgRule);
            string sub = prog.substr(1, prog.length() - 2);
            if (sub.length() > 0) {
                if (strstr(currProgram, sub.c_str()) != NULL) {
                    programMatch = true;
                }
            } else {               //**
                programMatch = true;
            }
        } else if (currProgRule[0] == '*') {               //*ABC or *A
            currProgRule++; //currProgRule=ABC, program=XYZ12ABC
            if (strncmp(currProgram + strlen(currProgram) - strlen(currProgRule), currProgRule,
                    strlen(currProgRule)) == 0) {
                programMatch = true;
            }
        } else if (currProgRule[strlen(currProgRule) - 1] == '*') { //ABCDE* or B*
            // remove the last *  //currProgRule=ABCDE, program=ABCDE1XY
            currProgRule[strlen(currProgRule) - 1] = 0; // change to ABCDE or B
            if (strncmp(currProgram, currProgRule, strlen(currProgRule)) == 0) {
                programMatch = true;
            }
        } else if (!strcmp(currProgram, currProgRule)) { //currProgRule="XYZ", no *
            programMatch = true;
        }
#ifdef DEBUG_CNDTION
        FPRINTF(stdout, "programMatch=%s\n",programMatch?"true":"false");//$NON-NLS-1$
#endif
        if (programMatch == false){
            continue; // we continue to check next rule (program name + tranID)
        }
        // currProgram name matched, check the tranID now
        char tranId[RIT_TRANSACTION_RULE_LEN];
        strcpy(tranId, (*itr).substr(8, 4).c_str());
        trimBlank(tranId);
#ifdef DEBUG_CNDTION
        FPRINTF(stdout, "Current transaction rule=%s\n", tranId);//$NON-NLS-1$
#endif
        char * currID = tranId;
        if (strlen(tranId) < 2) { // only 1 char
            if (strcmp(tranId, "*") == 0) { //*//$NON-NLS-1$
                tranidMatch = true;
            } else if (!strcmp(tID.c_str(), tranId)) {
                tranidMatch = true;
            }
        } else if (currID[0] == '*'
                && currID[strlen(currID) - 1] == '*') { //*AB* or **
                // Match middle of strings
            string id(currID);
            string sub = id.substr(1, id.length() - 2);
            if (sub.length() > 0) {
                if (strstr(tranID.c_str(), sub.c_str()) != NULL) {
                    tranidMatch = true;
                }
            } else {               //**
                tranidMatch = true;
            }
        } else if (currID[0] == '*') {               //*ABC or *A
            currID++; //currProgRule=ABC, currProgram=XYZ12ABC
            if (strncmp(tranID.c_str() + strlen(tranID.c_str()) - strlen(currID), currID,
                    strlen(currID)) == 0) {
                tranidMatch = true;
            }
        } else if (currID[strlen(currID) - 1] == '*') { //ABC* or B*
            currID[strlen(currID) - 1] = 0; // change to ABC or B
            if (strncmp(tranID.c_str(), currID, strlen(currID)) == 0) {
                tranidMatch = true;
            }
        } else if (!strcmp(tID.c_str(), currID))   { //currProgRule="XYZ", no *
            tranidMatch = true;
        }
#ifdef DEBUG_CNDTION
        FPRINTF(stdout, "tranidMatch=%s\n",tranidMatch?"true":"false");//$NON-NLS-1$
#endif
        if(tranidMatch == true){
            return true;
        }
        // continue to check next rule
    }
 
    return false;
}
 
void CICSAgentCondition::setCondition(const Condition& condition) {
#ifdef DEBUG_CNDTION
    FPRINTF(stdout, "Entering CICSAgentCondition::setCondition\n");//$NON-NLS-1$
#endif
    if (condition.has_type()) {
        switch (condition.type()) {
        case Condition::SYSID:
            if (condition.has_stringcondition()) {
                sysid_ = condition.stringcondition();
            //  sysid_ = trimString(sysid_);
                std::string sysid;
                asc2ebc(sysid_.c_str(), sysid);
                sysid_ = trimString(sysid);
#ifdef DEBUG_CNDTION
                FPRINTF(stdout, "set sysid=%s\n", sysid_.c_str());//$NON-NLS-1$
#endif
            }
            break;
        case Condition::APPLID:
            if (condition.has_stringcondition()) {
                applid_ = condition.stringcondition();
            //  applid_ = trimString(applid_);
                std::string applid;
                asc2ebc(applid_.c_str(), applid);
                applid_ = trimString(applid);
#ifdef DEBUG_CNDTION
                FPRINTF(stdout, "set applid=%s\n", applid_.c_str());//$NON-NLS-1$
#endif
            }
            break;
        case Condition::JOBNAME:
            if (condition.has_stringcondition()) {
                jobname_ = condition.stringcondition();
            //  jobname_ = trimString(jobname_);
                std::string jobname;
                asc2ebc(jobname_.c_str(), jobname);
                jobname_ = trimString(jobname);
#ifdef DEBUG_CNDTION
                FPRINTF(stdout, "set jobname=%s\n", jobname_.c_str());//$NON-NLS-1$
#endif
            }
            break;
        case Condition::AND:
            if(isSingleFilter(condition.firstcondition())){
                string filter;
                if(getFilterStr(condition.firstcondition(), filter) == 0){
                    std::string afilter;
                    asc2ebc(filter,afilter);
                    filter_.push_back(afilter);
                //  filter_.push_back(filter);
#ifdef DEBUG_CNDTION
                    FPRINTF(stdout, "set filter=%s\n", filter.c_str());//$NON-NLS-1$
#endif
                }
                setCondition(condition.secondcondition());
                break;
            }else if(isSingleFilter(condition.secondcondition())){
                string filter;
                if(getFilterStr(condition.secondcondition(), filter) == 0){
                    std::string afilter;
                    asc2ebc(filter,afilter);
                    filter_.push_back(afilter);
                //  filter_.push_back(filter);
#ifdef DEBUG_CNDTION
                    FPRINTF(stdout, "set filter=%s\n", filter.c_str());//$NON-NLS-1$
#endif
                }
                setCondition(condition.firstcondition());
                break;
            }
            setCondition(condition.firstcondition());
            setCondition(condition.secondcondition());
            break;
        case Condition::OR:
            if (string("TS").compare(findCICSType(condition.firstcondition())) //$NON-NLS-1$
            == 0) {
                setCondition(condition.firstcondition());
                break;
            }
            if (string("TS").compare(findCICSType(condition.secondcondition())) //$NON-NLS-1$
            == 0) {
                setCondition(condition.secondcondition());
                break;
            }
            if(isSingleFilter(condition.firstcondition())){
                string filter;
                if(getFilterStr(condition.firstcondition(), filter) == 0){
                    std::string afilter;
                    asc2ebc(filter,afilter);
                    filter_.push_back(afilter);
                 // filter_.push_back(filter);
#ifdef DEBUG_CNDTION
                    FPRINTF(stdout, "set filter=%s\n", filter.c_str());//$NON-NLS-1$
#endif
                }
            }else if(isOrFilter(condition.firstcondition())){
                setCondition(condition.firstcondition());
            }
            if(isSingleFilter(condition.secondcondition())){
                string filter;
                if(getFilterStr(condition.secondcondition(), filter) == 0){
                    std::string afilter;
                    asc2ebc(filter,afilter);
                    filter_.push_back(afilter);
               //   filter_.push_back(filter);
#ifdef DEBUG_CNDTION
                    FPRINTF(stdout, "set filter=%s\n", filter.c_str());//$NON-NLS-1$
#endif
                }
            }else if(isOrFilter(condition.secondcondition())){
                setCondition(condition.secondcondition());
            }
            break;
   /*   case Condition::CICS_TYPE:
            if (condition.has_stringcondition()) {
                if (string("TS").compare(condition.stringcondition())) {
                    log_->warn("CICS_TYPE error, in file %s line %d", //$NON-NLS-1$
                            __FILE__, __LINE__);
                    isTS_ = false;
                } else {
                    isTS_ = true;
                } */
        case Condition::CICS_TYPE:
            if (condition.has_stringcondition()) {
            // Compare the string condition to "TS"
                const std::string &condStr = condition.stringcondition();
                std::string condebc;
                asc2ebc(condStr.c_str(), condebc);
            if (std::string("TS") != condebc) {
                log_->warn("CICS_TYPE error, in file %s line %d",
                           __FILE__, __LINE__);
                isTS_ = false;  // Only set false if the string !="TS"
            } else {
                isTS_ = true;   // explicitly mark true if it matches
            }
#ifdef DEBUG_CNDTION
                FPRINTF(stdout, "set CICS_TYPE=%s\n", isTS_?"TS":"TG");//$NON-NLS-1$
#endif
            }
            break;
        default:
            break;
        }
    }
}
 
string CICSAgentCondition::findCICSType(const Condition & condition) {
    if (condition.has_type()) {
        switch (condition.type()) {
        case Condition::CICS_TYPE:{
            if (condition.has_stringcondition()) {
                string tempstr;
                asc2ebc(condition.stringcondition().c_str(),tempstr);
#ifdef DEBUG_CNDTION
                FPRINTF(stdout, "findCICSType: %s\n", condition.stringcondition().c_str());//$NON-NLS-1$
#endif
             // return condition.stringcondition();
                return tempstr;
            }
            break;
        }
        case Condition::AND: {
            string s = findCICSType(condition.firstcondition());
            if (s.length() > 0) {
                return s;
            }
            return findCICSType(condition.secondcondition());
        }
        default:
            break;
        }
    }
    return string();
}
 
bool CICSAgentCondition::isSingleFilter(const Condition & condition) {
    if (condition.type() != Condition::AND) {
        return false;
    }
    if(condition.firstcondition().type() == Condition::PROGRAM_NAME &&
            condition.secondcondition().type() == Condition::TRANSACTION){
        return true;
    }
    return false;
}
 
bool CICSAgentCondition::isOrFilter(const Condition & condition){
    if (condition.type() != Condition::OR) {
        return false;
    }
    if(isSingleFilter(condition.firstcondition())){
        return true;
    }
    if(isSingleFilter(condition.secondcondition())){
        return true;
    }
    if(isOrFilter(condition.secondcondition())){
        return true;
    }
    if(isOrFilter(condition.firstcondition())){
        return true;
    }
    return false;
}
 
int CICSAgentCondition::getFilterStr(const Condition & condition,
        string& filterStr){
    if(isSingleFilter(condition) == false){
        return -1;
    }
    string blank8("        ");
    string ablank8;
    ebc2asc(blank8,ablank8);
    blank8 = ablank8;
    string program = condition.firstcondition().stringcondition();
    string transaction = condition.secondcondition().stringcondition();
    program = (program + blank8).substr(0, 8);
    transaction = (transaction + blank8).substr(0, 4);
    filterStr = program + transaction;
    return 0;
}
 
