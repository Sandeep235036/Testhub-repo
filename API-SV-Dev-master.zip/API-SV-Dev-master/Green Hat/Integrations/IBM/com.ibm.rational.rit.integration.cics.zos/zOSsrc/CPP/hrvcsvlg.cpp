/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017.All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*******************************************************************************
 * serverlog.cpp
 ******************************************************************************/
#pragma csect (CODE,"HRVCSVLG")
#include "servlog.h"
#include "ritlog.h"
#include "objxfer.h"
#include <signal.h>
#include <pthread.h>

ServerLogger* ServerLogger::s_instance = NULL;

ServerLogger::ServerLogger(CICSRegistration* reg) :
        pReg_(reg), stop_(0), logLevel_(::greenhat::vie::comms::proxy::LogEvent_Level_INFO) {
    log_ = LoggerFactory::getInstance()->getLogger("ServerLogger"); //$NON-NLS-1$

    if (pthread_mutexattr_init(&attr_) == -1) {
        log_->error("mutexattr_init error"); //$NON-NLS-1$
    }

    if (pthread_mutex_init(&mutex_, &attr_) == -1) {
        log_->error("mutex_init error"); //$NON-NLS-1$
    }

    int rc = pthread_rwlockattr_init(&rwlattr_);
    if (rc == -1) {
        log_->error("error in pthread_rwlockattr_init");
        FPRINTF(stdout, "pthread_rwlockattr_init error, errno=%d. Exiting...\n", //$NON-NLS-1$
                errno);
        exit (EXIT_FAILURE);
    }
    rc = pthread_rwlockattr_setpshared(&rwlattr_, PTHREAD_PROCESS_PRIVATE);
    if (rc == -1) {
        log_->error("error in pthread_rwlockattr_setpshared"); //$NON-NLS-1$
        FPRINTF(stdout,
                "pthread_rwlockattr_setpshared error, errno=%d. Exiting...\n", //$NON-NLS-1$
                errno);
        exit (EXIT_FAILURE);
    }
    rc = pthread_rwlock_init(&statuslock_, &rwlattr_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_init"); //$NON-NLS-1$
        FPRINTF(stdout, "pthread_rwlock_init error, errno=%d. Exiting...\n", //$NON-NLS-1$
                errno);
        exit (EXIT_FAILURE);
    }
    rc = pthread_rwlock_init(&levellock_, &rwlattr_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_init"); //$NON-NLS-1$
        FPRINTF(stdout, "pthread_rwlock_init error, errno=%d. Exiting...\n", //$NON-NLS-1$
                errno);
        exit (EXIT_FAILURE);
    }
}

ServerLogger* ServerLogger::instance(CICSRegistration* reg) {
    if (s_instance == NULL) {
        s_instance = new ServerLogger(reg);
    }
    return s_instance;
}

ServerLogger* ServerLogger::instance() {
    if (s_instance == NULL) {
        s_instance = new ServerLogger(CICSRegistration::getInstance());
    }
    return s_instance;
}

ServerLogger::~ServerLogger() {
    int i = getWaitTimeout();
    while (getStop() != 2 && i > 0) {
        stop(1);
        i--;
        sleep(1);
    }
    if (pthread_mutexattr_destroy(&attr_) != 0) {
        log_->error("pthread_mutex_attr_destroy() error"); //$NON-NLS-1$
    }
    if (pthread_mutex_destroy(&mutex_) != 0) {
        log_->error("pthread_mutex_destroy() error"); //$NON-NLS-1$
    }

    if (pthread_rwlock_destroy(&statuslock_) == -1) {
        log_->error("error in pthread_rwlock_destroy statuslock"); //$NON-NLS-1$
    }
    if (pthread_rwlock_destroy(&levellock_) == -1) {
        log_->error("error in pthread_rwlock_destroy levellock"); //$NON-NLS-1$
    }
    if (pthread_rwlockattr_destroy(&rwlattr_) == -1) {
        log_->error("error in pthread_rwlockattr_destroy"); //$NON-NLS-1$
    }
}

extern "C" void* server_log_send(void* arg);

void ServerLogger::start(pthread_attr_t* attr) {
    if (pthread_create(&thread_, attr, server_log_send, (void*) this) != 0) {
        log_->error("pthread_create() error, errno=%d\n", errno); //$NON-NLS-1$
    }
}

void ServerLogger::stop(int status) {
    int rc = pthread_rwlock_wrlock(&statuslock_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_wrlock"); //$NON-NLS-1$
    }
    stop_ = status;
    rc = pthread_rwlock_unlock(&statuslock_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_unlock"); //$NON-NLS-1$
    }
    log_->info("ServerLogger stopping ...\n"); //$NON-NLS-1$//$NON-NLS-1$
}

int ServerLogger::getStop() {
    int rc = pthread_rwlock_rdlock(&statuslock_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_rdlock"); //$NON-NLS-1$//$NON-NLS-1$
    }
    int status = stop_;
    rc = pthread_rwlock_unlock(&statuslock_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_unlock"); //$NON-NLS-1$
    }
    return status;
}

string& ServerLogger::truncate(string & str) {
    if (str.length() > MAX_MESSAGE_LENGTH) {
        str.assign(str.substr(0, MAX_MESSAGE_LENGTH));
    }
    return str;
}

void ServerLogger::truncateValues(map<string, string>* context) {
    if (context != NULL && context->size()) {
        map<string, string>::iterator it = context->begin();

        for (; it != context->end(); it++) {
            string value = (*it).second;
            value = truncate(value);
            (*context)[(*it).first] = value;
        }
    }
}

void ServerLogger::guardedLog(::greenhat::vie::comms::proxy::LogEvent_Level level, string & message,
        map<string, string>* context) {
    if (isLoggable(level)) {
        string sMsg = truncate(message);
        truncateValues(context);
        logImpl(level, sMsg, context);
    }
}

void ServerLogger::setLevel(::greenhat::vie::comms::proxy::LogEvent_Level level) {
    int rc = pthread_rwlock_wrlock(&levellock_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_wrlock"); //$NON-NLS-1$
    }
    logLevel_ = level;
    rc = pthread_rwlock_unlock(&levellock_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_unlock"); //$NON-NLS-1$
    }
    log_->info("Set diagnostic log level to %d\n", level); //$NON-NLS-1$
    char msg[RIT_BUFFER_LEN_80] = {0};
    sprintf(msg, "Set diagnostic log level to %d", level);
    info(msg);
}

bool ServerLogger::isLoggable(::greenhat::vie::comms::proxy::LogEvent_Level level) {
//    int rc = pthread_rwlock_rdlock(&levellock_);
//    if (rc == -1) {
//        log_->error("error in pthread_rwlock_rdlock");//$NON-NLS-1$
//    }
//    ::greenhat::vie::comms::proxy::LogEvent_Level lvl = logLevel_;
//    rc = pthread_rwlock_unlock(&levellock_);
//    if (rc == -1) {
//        log_->error("error in pthread_rwlock_unlock");//$NON-NLS-1$
//    }
//    return level >= lvl;
    return level >= logLevel_;
}

void ServerLogger::logImpl(::greenhat::vie::comms::proxy::LogEvent_Level level, const string & message,
        map<string, string>* context) {

    ::com::ibm::greenhat::logging::LogEvent *event =
            new ::com::ibm::greenhat::logging::LogEvent();
    struct timeval64 ltimeval;
    int rc = gettimeofday64(&ltimeval, NULL);
    if(rc != 0){
        time64_t ltime;
        time64(&ltime);
        event->set_timestamp(ltime * 1000);
    }else{
        event->set_timestamp(ltimeval.tv_sec * 1000 +
                ltimeval.tv_usec / 1000);
    }
    event->set_level((::com::ibm::greenhat::logging::LogEvent_Level)level);
    event->set_sourceuuid(pReg_->uuid());
    event->set_loggername("HRVCCICS"); //$NON-NLS-1$
    // add context
    if (context != NULL && context->size()) {
        map<string, string>::iterator it = context->begin();
        for (; it != context->end(); it++) {
            LogEvent_ContextData* contextData = event->add_context();
            contextData->set_key((*it).first);
            contextData->set_value((*it).second);
        }
    }
    event->set_message(message);
    if (pthread_mutex_lock(&mutex_) != 0) {
        log_->error("mutex_lock error");    //$NON-NLS-1$
    }
    container_.push(event);
    if (container_.size() > MAX_LOGEVENT_NUMBER) {
        container_.pop();
    }
    if (pthread_mutex_unlock(&mutex_) != 0) {
        log_->error("mutex_unlock error");    //$NON-NLS-1$
    }
}

void* server_log_send(void* arg) {
    sleep(3);
    ServerLogger* svrLogger = (ServerLogger*) arg;
    CICSRegistration* cicsreg = svrLogger->registration();
    Logger* log = svrLogger->logger();
    string baseurl = cicsreg->serverUrl() + SERVERLOG_PATH;
    ObjXfer xfer(baseurl,cicsreg->gsk_keyring_ring());
    int count = 0;
    pthread_t thid = pthread_self();
    FPRINTF(stdout, "ServerLog thread id is %X.\n", thid);
    log->info("ServerLog thread id is %X.\n", thid);

    while(svrLogger->getStop() == 0){
        if (!svrLogger->container().empty()){
            string uuid = cicsreg->uuid();
            if (uuid.length() == UUID_LENGTH) {
                list< ::com::ibm::greenhat::logging::LogEvent*> eventList;

                if (pthread_mutex_lock(svrLogger->mutex()) != 0) {
                    log->error("mutex_lock error");    //$NON-NLS-1$
                }

                for (int i = 0;
                        i < ServerLogger::DEFAULT_SERVER_LOG_SEND_NUMBER; i++) {

                    if (svrLogger->container().empty()) {
                        break;
                    }
                    ::com::ibm::greenhat::logging::LogEvent* event = svrLogger->container().front();
                    svrLogger->container().pop();
                    eventList.push_back(event);
                }

                if (pthread_mutex_unlock(svrLogger->mutex()) != 0) {
                    log->error("mutex_unlock error");    //$NON-NLS-1$
                }
                LogEventSet eventSet;

                list< ::com::ibm::greenhat::logging::LogEvent*>::iterator it = eventList.begin();
                if(eventList.size()){
                    for (; it != eventList.end(); it++) {
                        ::com::ibm::greenhat::logging::LogEvent* event = *it;

                        ::com::ibm::greenhat::logging::LogEvent* eventCopy = eventSet.add_events();
                        eventCopy->CopyFrom(*event);

                        DELETE(event);
                    }
                }

                if (eventSet.events_size() > 0) {
                    int rc = xfer.postLog(&eventSet, log);
                    if (rc != 0) {
                        log->error("server_log_send logevent error"); //$NON-NLS-1$
                    }
                    eventSet.clear_events();
                }

                eventList.clear();
            } // uuid
        } // if (!svrLogger->container().empty())
        sleep(ServerLogger::DEFAULT_SERVER_LOG_XMIT_INTERVAL);
    } // while
    svrLogger->stop(2);
    pthread_exit(NULL);
    return NULL;
}
