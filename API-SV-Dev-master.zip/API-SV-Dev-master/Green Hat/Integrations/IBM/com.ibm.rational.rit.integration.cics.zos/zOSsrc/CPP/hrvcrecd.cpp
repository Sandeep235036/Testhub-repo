/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017.All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*******************************************************************************
 * record.cpp
 ******************************************************************************/
#pragma csect (CODE,"HRVCRECD")
#include <pthread.h>
#include <ctime>
#include <curl/curl.h>
#include <set>
#include "record.h"
#include "svrpoll.h"
#include "ritcomm.h"
#include "ritlog.h"
#include "observ.h"
#include "servlog.h"
#include "cndtion.h"
 
//#define RECORD_DEBUG 1
//#define RECORD_DEBUG_HANDLER 1
//#define DEBUG_RECORD
 
#define RECORDER_ERROR 1200
 
static void *
record_send_event(void* arg) {
    Logger* log = LoggerFactory::getInstance()->getLogger("Recorder"); //$NON-NLS-1$
    ServerLogger* serverLogger = ServerLogger::instance(
            CICSRegistration::getInstance());
    CURL *curl = curl_easy_init();
 
    Posted_Event* pe = (Posted_Event*) arg;
 
    struct ObjectToSend objSend;
    struct ObjectReceived objRecv;
 
  //objSend.sizeleft = (long) pe->event_->ByteSize();
    objSend.sizeleft = (long) pe->event_->ByteSizeLong();
    objSend.readptr = (char*) malloc(objSend.sizeleft);
    if (objSend.readptr == NULL) {
        FPRINTF(stdout, "Malloc error, errno=%d. Exiting...\n", errno); //$NON-NLS-1$
        exit(MEMORY_ALLOC_FAILURE);
    }
    ::google::protobuf::uint8* output =
            (::google::protobuf::uint8*) objSend.readptr;
    pe->event_->SerializeWithCachedSizesToArray(output);
 
    string HTTP_CTYPE,RIT_AID,RIT_CID,RIT_HTIME;
    ebc2asc(RIT_HTTP_HEADER_CONTENT_TYPE,HTTP_CTYPE);
    ebc2asc(RIT_HTTP_HEADER_ACTIVITYID,RIT_AID);
    ebc2asc(RIT_HTTP_CorrelationID,RIT_CID);
    ebc2asc(RIT_HTTP_TIMESTAMP,RIT_HTIME);
    struct curl_slist *http_headers = NULL;
    char buffer[128] = "";
    http_headers = curl_slist_append(http_headers,
            HTTP_CTYPE.c_str());
  //        RIT_HTTP_HEADER_CONTENT_TYPE);
  //snprintf(buffer, 127, "%s%s", RIT_HTTP_HEADER_ACTIVITYID,
  //        pe->act_.c_str());
    snprintf(buffer, 127, "%s%s",  RIT_AID.c_str(),
            pe->act_.c_str());
    http_headers = curl_slist_append(http_headers, buffer);
  //snprintf(buffer, 127, "%s%s", RIT_HTTP_CorrelationID,
  //        pe->correl_.c_str());
    snprintf(buffer, 127, "%s%s",  RIT_CID.c_str(),
            pe->correl_.c_str());
    http_headers = curl_slist_append(http_headers, buffer);
  //time64_t ltime;
  //time64(&ltime);
    std::time_t ltime;
    ltime = std::time(nullptr);
 // snprintf(buffer, 127, "%s%d", RIT_HTTP_TIMESTAMP, ltime);
    snprintf(buffer, 127, "%s%ld", RIT_HTIME.c_str(), ltime);
    http_headers = curl_slist_append(http_headers, buffer);
    int retry = getTranferRetry();
    CURLcode res = CURLE_OK;
    do {
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, http_headers);
        curl_easy_setopt(curl, CURLOPT_URL, pe->url_.c_str());
        // Now specify we want to POST data
        curl_easy_setopt(curl, CURLOPT_POST, 1L);
        curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
        // we want to use our own read function
        curl_easy_setopt(curl, CURLOPT_READFUNCTION, record_read);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, record_write);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &objRecv);
        // pointer to pass to our read function
        curl_easy_setopt(curl, CURLOPT_READDATA, &objSend);
        curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT,
                getConnTimeout());
//        curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, getLowSpeedTime());
//        curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, getLowSpeedLimit());
 
// Set the expected POST size. If you want to POST large amounts of data,
// consider CURLOPT_POSTFIELDSIZE_LARGE/
        curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, objSend.sizeleft);
        // Perform the request, res will get the return code
        res = curl_easy_perform(curl);
        // Check for errors
        string err;
        if (res != CURLE_OK) {
            asc2ebc(curl_easy_strerror(res),err);
            log->error("record_send_event() failed: %s",   //$NON-NLS-1$
                    err.c_str());
        //  log->error("record_send_event() failed: %s",   //$NON-NLS-1$
        //          curl_easy_strerror(res));
            FPRINTF(stdout, "record_send_event() failed: %s.\n", //$NON-NLS-1$
                    err.c_str());
        //  FPRINTF(stdout, "record_send_event() failed: %s.\n", //$NON-NLS-1$
        //          curl_easy_strerror(res));
        }
    } while ((res != CURLE_OK) && ((retry--) > 0));
 
    if (res != CURLE_OK) {
        map<string, string> contextMap;
        contextMap[ACTIVITY_ID_PROPERTY] = pe->act_;
        string msg(
                "WARNING: IBM Rational Integration Tester has stopped listening on "); //$NON-NLS-1$
        msg += pe->url_;
        serverLogger->warn(msg, &contextMap);
        FPRINTF(stdout, "%s.\n", msg.c_str());        //$NON-NLS-1$
        ServerPoller* pSvrPoller = ServerPoller::instance(
                CICSRegistration::getInstance());
        string act;
        asc2ebc(pe->act_,act);
        if (pSvrPoller->suspendRule(pe->act_) != true) {
            log->error("Remove the rule <%s> failed",      //$NON-NLS-1$
                    act.c_str());
         // log->error("Remove the rule <%s> failed",      //$NON-NLS-1$
         //         pe->act_.c_str());
            FPRINTF(stdout, "ERROR: Remove the rule <%s> failed.\n", //$NON-NLS-1$
                    pe->act_.c_str());
        } else {
            log->info("Remove the rule <%s> successfully", //$NON-NLS-1$
                    act.c_str());
        //  log->info("Remove the rule <%s> successfully", //$NON-NLS-1$
        //          pe->act_.c_str());
        }
        curl_easy_cleanup(curl);
        pthread_exit(NULL);
        return NULL;
    }
    string urlebc,err;
    long httpCode = 0;
    res = curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &httpCode);
    if (res != CURLE_OK) {
        asc2ebc(curl_easy_strerror(res),err);
    //  log->error("curl_easy_getinfo() failed: %s\n",     //$NON-NLS-1$
    //          curl_easy_strerror(res));
        log->error("curl_easy_getinfo() failed: %s\n",     //$NON-NLS-1$
                err.c_str());
        curl_easy_cleanup(curl);
        pthread_exit(NULL);
        return NULL;
    } else {
        asc2ebc(pe->url_.c_str(),urlebc);
        const CTGRecordedEvent& ctg = pe->event_->ctgrecordedevent();
     // log->debug("Recorder send event to %s",        //$NON-NLS-1$
     //         pe->url_.c_str());
        log->debug("Recorder send event to %s",        //$NON-NLS-1$
                urlebc.c_str());
    }
 
    curl_easy_cleanup(curl);
    pthread_exit(NULL);
    return NULL;
}
 
Recorder* Recorder::s_instance = NULL;
 
Recorder* Recorder::instance(CICSRegistration* reg) {
    if (s_instance == NULL) {
        s_instance = new Recorder(reg);
    }
    return s_instance;
}
 
Recorder::Recorder(CICSRegistration* reg) :
        pReg_(reg) {
    log_ = LoggerFactory::getInstance()->getLogger("Recorder"); //$NON-NLS-1$
    serverLogger_ = ServerLogger::instance(reg);
    int rc = pthread_rwlockattr_init(&rwlattr_);
    if (rc == -1) {
        log_->error("error in pthread_rwlockattr_init");   //$NON-NLS-1$
        FPRINTF(stdout,
                "pthread_rwlockattr_init error, errno=%d. Exiting...\n",
                errno);        //$NON-NLS-1$
        exit(RECORDER_ERROR + 1);
    }
    rc = pthread_rwlockattr_setpshared(&rwlattr_,
            PTHREAD_PROCESS_PRIVATE);
    if (rc == -1) {
        log_->error("error in pthread_rwlockattr_setpshared"); //$NON-NLS-1$
        FPRINTF(stdout,
                "pthread_rwlockattr_setpshared error, errno=%d. Exiting...\n",
                errno);        //$NON-NLS-1$
        exit(RECORDER_ERROR + 2);
    }
    rc = pthread_rwlock_init(&rwlock_, &rwlattr_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_init");       //$NON-NLS-1$
        FPRINTF(stdout,
                "pthread_rwlock_init error, errno=%d. Exiting...\n",
                errno);        //$NON-NLS-1$
        exit(RECORDER_ERROR + 3);
    }
}
 
Recorder::~Recorder() {
    if (pthread_rwlock_destroy(&rwlock_) == -1) {
        log_->error("error in pthread_rwlock_destroy");    //$NON-NLS-1$
    }
    if (pthread_rwlockattr_destroy(&rwlattr_) == -1) {
        log_->error("error in pthread_rwlockattr_destroy"); //$NON-NLS-1$
    }
}
 
/**
 * Update the recording RIT vector according to latest Configuration,
 * it will be called in ConfigPoller::cfgChanged()
 */
void Recorder::configureRecording(Configuration* pCfg) {
#ifdef RECORD_DEBUG
    FPRINTF(stdout, ">>>Enter Recorder::configureRecording\n"); //$NON-NLS-1$
#endif
    if (pCfg == NULL) {
        return;
    }
    // Find all of the recorders, and make sure that we are sending
    // notifications to them all.
 
    // Keep track of the activity ids, so that we can send log messages to any
    // recorders that are listening.
    set<string> currentActivityIds;
    set<string> oldActivityIds;
 
    vector<string> recordingURLs;
    vector<CICSAgentCondition*> newRecorders;
    vector<CICSAgentCondition*> ignoreList;
 
    const RepeatedPtrField<Rule>& recorders = pCfg->recorders();
 
    RepeatedPtrField<Rule>::const_iterator it = recorders.begin();
    for (; recorders.size() && it != recorders.end(); it++) {
    const Rule& recorder = *it;
    const RepeatedPtrField<Activity>& activities =
        recorder.activities();
 
    RepeatedPtrField<Activity>::const_iterator ita = activities.begin();
    for (; activities.size() && ita != activities.end(); ita++) {
        const Activity& activity = *ita;
        const RecordingActivity& rec = activity.recording();
        if (rec.has_url() && rec.has_id()) {
        const string& url = rec.url();
        const string& id = rec.id();
 
        CICSAgentCondition *condition = new CICSAgentCondition(
            url, id);
        condition->setCondition(recorder.condition());
 
        std::string urle;
        std::string applide;
        std::string syside;
        std::string jobnamee;
        std::string ide;
        std::string cics_typ;
        std::string applidr;
        std::string sysidr;
        std::string jobnamer;
        std::string idr;
        applide = condition->getAPPLID();
        syside = condition->getSYSID();
        jobnamee = condition->getJOBNAME();
        asc2ebc(url,urle);
        asc2ebc(id,ide);
        asc2ebc(id,idr);
        applidr = pReg_->applid().c_str();
        sysidr  = pReg_->sysid().c_str();
        jobnamer = pReg_->jobname().c_str();
                // ignore rules that don't apply
                // to this region
      /*        if (condition->getAPPLID().length() > 0
                        && pReg_->applid().compare(
                                condition->getAPPLID())
                        || condition->getSYSID().length() > 0
                                && pReg_->sysid().compare(
                                        condition->getSYSID())
                        || condition->getJOBNAME().length() > 0
                                && pReg_->jobname().compare(
                                        condition->getJOBNAME())
                        || (condition->isTS() == false)) { */
                if (applide.length() > 0
                    && applidr.compare(applide)
                    || syside.length() > 0
                        && sysidr.compare(syside)
                    || jobnamee.length() > 0
                        && jobnamer.compare(jobnamee)
                    || (condition->isTS() == false)) {
                    ignoreList.push_back(condition);
 
                    log_->debug("Ignore recorder below:"); //$NON-NLS-1$
            //      log_->debug("RecordingActivity url is: %s", //$NON-NLS-1$
            //              url.c_str());
                    log_->debug("RecordingActivity url is: %s", //$NON-NLS-1$
                            urle.c_str());
            //      log_->debug("RecordingActivity id is: %s", //$NON-NLS-1$
            //              id.c_str());
                    log_->debug("RecordingActivity id is: %s", //$NON-NLS-1$
                            ide.c_str());
            //      log_->debug("Recorder applid is:%s",   //$NON-NLS-1$
            //              condition->getAPPLID().c_str());
                    log_->debug("Recorder applid is:%s",   //$NON-NLS-1$
                            applide.c_str());
            //      log_->debug("Recorder sysid is:%s",    //$NON-NLS-1$
            //              condition->getSYSID().c_str());
                    log_->debug("Recorder sysid is:%s",    //$NON-NLS-1$
                            syside.c_str());
            //      log_->debug("Recorder jobname is:%s",  //$NON-NLS-1$
            //              condition->getJOBNAME().c_str());
                    log_->debug("Recorder jobname is:%s",  //$NON-NLS-1$
                            jobnamee.c_str());
                    log_->debug("Recorder type is TS:%s",  //$NON-NLS-1$
                            condition->isTS() ? "true" : "false"); //$NON-NLS-1$
                    continue;
                }
 
                currentActivityIds.insert(id);
                recordingURLs.push_back(url);
                newRecorders.push_back(condition);
            }
        }
    }
 
    vector<CICSAgentCondition*> oldRecorders;
    int rc = pthread_rwlock_wrlock(&rwlock_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_wrlock");     //$NON-NLS-1$
    }
    oldRecorders = recorders_;
    recorders_ = newRecorders;
    rc = pthread_rwlock_unlock(&rwlock_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_unlock");     //$NON-NLS-1$
    }
 
    vector<CICSAgentCondition*>::iterator itc = oldRecorders.begin();
    for (; !oldRecorders.empty() && itc != oldRecorders.end(); itc++) {
        CICSAgentCondition* oldCondition = *itc;
        oldActivityIds.insert(oldCondition->getActivityId());
    }
 
    // Find which activities are really new and log them
    map<string, string> context;
    set<string>::iterator ita = currentActivityIds.begin();
    for (;
            !currentActivityIds.empty()
                    && ita != currentActivityIds.end(); ita++) {
        const string& activity = *ita;
        if (oldActivityIds.find(activity) == oldActivityIds.end()) {
            map<string, string> contextMap;
            contextMap[ACTIVITY_ID_PROPERTY] = activity;
            serverLogger_->info("CICS TS Agent started recording", //$NON-NLS-1$
                    &contextMap);
        }
    }
 
    // Find which activities have ended and log them
    set<string>::iterator ito = oldActivityIds.begin();
    for (; !oldActivityIds.empty() && ito != oldActivityIds.end();
            ito++) {
        const string & activity = *ito;
        if (currentActivityIds.find(activity)
                == currentActivityIds.end()) {
            map<string, string> contextMap;
            contextMap[ACTIVITY_ID_PROPERTY] = activity;
            serverLogger_->info("CICS TS Agent stopped recording", //$NON-NLS-1$
                    &contextMap);
        }
    }
 
    vector<CICSAgentCondition*>::iterator itg = ignoreList.begin();
    for (; !ignoreList.empty() && itg != ignoreList.end(); itg++) {
        CICSAgentCondition* pCond = *itg;
        DELETE(pCond);
    }
 
    vector<CICSAgentCondition*>::iterator itor = oldRecorders.begin();
    for (; !oldRecorders.empty() && itor != oldRecorders.end();
            itor++) {
        CICSAgentCondition* pCond = *itor;
        DELETE(pCond);
    }
 
    setFilterList();
 
#ifdef RECORD_DEBUG
    FPRINTF(stdout, "<<<Exit Recorder::configureRecording\n"); //$NON-NLS-1$
#endif
}
 
void Recorder::handleInvocation(const AscHeader& header,
        const struct CONTAINER* pContainer) {
    Observation::instance(pReg_)->addRecordedCount();
 
    map<string, string> activityMap;
    checkRecorder(header, activityMap);
    if (activityMap.empty()) {
        return;
    }
    string correlator = registration()->uuid() + ":"
            + pReg_->getCorrelID(header.correl);
    RecordedEvent event;
    event.set_type(CTG);
    struct timeval ltimeval;
    int rc = gettimeofday(&ltimeval, NULL);
    if (rc != 0) {
        std::time_t ltime;
        ltime = std::time(nullptr);
        event.set_timestamp(ltime * 1000);
    } else {
        event.set_timestamp(
                ltimeval.tv_sec * 1000 + ltimeval.tv_usec / 1000);
    }
    CTGRecordedEvent* pCTG = event.mutable_ctgrecordedevent();
    if (header.reqresp == INT_BeforeLink)
        pCTG->set_type(CTGRecordedEvent_Type_REQUEST);
    else
        pCTG->set_type(CTGRecordedEvent_Type_RESPONSE);
    pCTG->set_program(header.progName, strlen(header.progName));
    pCTG->set_tranname(header.tranID, strlen(header.tranID));
    pCTG->set_jobname(header.jobName,strlen(header.jobName));
    pCTG->set_sysid(pReg_->sysid());
    pCTG->set_applid(pReg_->applid());
    pCTG->set_cicstype(CTGRecordedEvent_CICSType_TS);
 
    CTGRecordedEvent_Channel* channel = pCTG->mutable_channel();
    channel->set_name(header.channelName,strlen(header.channelName));
    for (const Container* ptr = pContainer; ptr != NULL; ptr =
            ptr->next) {
        CTGRecordedEvent_Container* container =
                channel->add_containers();
        container->set_name(ptr->header.containerName,
                strlen(ptr->header.containerName));
        container->set_bitdata(ptr->dataarea,ptr->header.length);
    }
 
    broadcast(activityMap, correlator, event);
}
 
/**
 * Update the filter vector according to the result of
 * configureRecording(), the CICSAgentConditon in recorders_
 */
void Recorder::setFilterList() {
    int rc = pthread_rwlock_wrlock(&rwlock_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_wrlock");     //$NON-NLS-1$
    }
    filterList_.clear();
    vector<CICSAgentCondition*>::iterator it = recorders_.begin();
        std::string applide;
        std::string syside;
        std::string jobnamee;
        std::string applidr;
        std::string sysidr;
        std::string jobnamer;
    for (; recorders_.size() && it != recorders_.end(); it++) {
        CICSAgentCondition* condition = *it;
        applide = condition->getAPPLID();
        syside = condition->getSYSID();
        jobnamee = condition->getJOBNAME();
        applidr = pReg_->applid().c_str();
        sysidr  = pReg_->sysid().c_str();
        jobnamer = pReg_->jobname().c_str();
        // If we have system information, ignore rules that don't apply to this
        // region
    /*  if (condition->getAPPLID().length() > 0
                && pReg_->applid().compare(condition->getAPPLID())
                || condition->getSYSID().length() > 0
                        && pReg_->sysid().compare(condition->getSYSID())
                || condition->getJOBNAME().length() > 0
                        && pReg_->jobname().compare(
                                condition->getJOBNAME()) */
        if (applide.length() > 0
            && applidr.compare(applide)
            || syside.length() > 0
                && sysidr.compare(syside)
            || jobnamee.length() > 0
                && jobnamer.compare(jobnamee)
                || (condition->isTS() == false)) {
            continue;
        }
        const vector<string> & filters = condition->getFilter();
        vector<string>::const_iterator citr = filters.begin();
        for (; citr != filters.end(); citr++) {
            string prefix("+");
            filterList_.push_back(prefix + (*citr));
        }
    }
    rc = pthread_rwlock_unlock(&rwlock_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_unlock");     //$NON-NLS-1$
    }
}
 
void Recorder::checkRecorder(const AscHeader& header,
        map<string, string> & pMap) {
    if (recorders_.empty()) {
        return;
    }
    int rc = pthread_rwlock_wrlock(&rwlock_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_wrlock");     //$NON-NLS-1$
    }
 
    vector<CICSAgentCondition*>::iterator it = recorders_.begin();
    for (; recorders_.size() && it != recorders_.end(); it++) {
        CICSAgentCondition* condition = *it;
        if (condition == NULL) {
            continue;
        }
        if (condition->matches(header)) {
            const string & url = condition->getUrl();
            const string & activity = condition->getActivityId();
            if (url.empty() || activity.empty()) {
                continue;
            }
            map<string, string>::iterator itm = pMap.find(url);
            if (itm == pMap.end()) {
                pMap[url] = activity;
            }
            /**
             *  comment it out since the combined activity will get 404 error.
             *  if the 1st activity match, we will use it.
             else{
             string activityIds = pMap[url];
             pMap[url] = activityIds + ":" + activity;
             }
             */
        } else { // if (condition->matches(header))
            string pgmname,tid;
            asc2ebc(header.progName,pgmname);
            asc2ebc(header.tranID,tid);
            log_->debug(
                    "Current program name: %s transaction name: %s doesn't match filter %s...", //$NON-NLS-1$
                    pgmname.c_str(),tid.c_str(),
                    condition->getFilter().at(0).c_str());
        //  log_->debug(
        //          "Current program name: %s transaction name: %s doesn't match filter %s...", //$NON-NLS-1$
        //          header.progName, header.tranID,
        //          condition->getFilter().at(0).c_str());
        }
    } // for
 
    rc = pthread_rwlock_unlock(&rwlock_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_unlock"); //$NON-NLS-1$
    }
}
 
void Recorder::broadcast(map<string, string> activityMap,
        const string& correlator, RecordedEvent& event) {
    int rc = 0;
    map<string, string>::iterator it = activityMap.begin();
    int recNumber = activityMap.size();
    pthread_t* workers = new pthread_t[recNumber];
    Posted_Event* postedEvents = new Posted_Event[recNumber];
    int error = 0;
    for (int i = 0; it != activityMap.end(); it++, i++) {
        postedEvents[i].url_ = (*it).first;
        postedEvents[i].act_ = (*it).second;
        postedEvents[i].correl_ = correlator;
        postedEvents[i].event_ = &event;
 
        int nice = 1;
        do {
            /* reset errno2 and errno to zero */
            errno = 0;
            *__err2ad() = 0x0;
            error = pthread_create(&workers[i], NULL, record_send_event,
                    (void*) (postedEvents + i));
            if (error != 0) {
                /* an error occurred during the pthread_create() */
                int errorNo = errno;
                int errorNo2 = __errno2();
                char strerrBuf[ERR_BUF_LEN] = { 0 };
                rc = strerror_r(errorNo, strerrBuf, ERR_BUF_LEN);
                if (rc != 0) {
                    FPRINTF(stdout, "strerror_r return %d\n", rc);
                }
                pthread_t thid = pthread_self();
                log_->error(
                        "pthread_create error, errno=%08x, __errno2=%08x, %s in thread:%X\n",
                        errno, errorNo2, strerrBuf, thid); //$NON-NLS-1$
                if (pReg_->logLevel() < 2) {
                    FPRINTF(stdout,
                            "pthread_create error, errno=%08x, __errno2=%08x, %s in thread: %X\n",
                            errno, errorNo2, strerrBuf, thid); //$NON-NLS-1$
                }
                if (errno == EAGAIN || errno == ENOMEM) {
                    sleep(nice);
                    nice = nice * 2;
                } else {
                    raise(SIGUSR1);
                    sleep(10);
                    break;
                }
            } else {
                nice = 1;
            }
        } while (error != 0);
    }
    // now wait for all workers to terminate
    for (int i = 0; i < recNumber; i++) {
        error = pthread_join(workers[i], NULL);
    }
    delete[] postedEvents;
    delete[] workers;
}
 
void Recorder::handleInvocation(const AscHeader& header,
        const COMMAREA* pCommArea) {
    Observation::instance(pReg_)->addRecordedCount();
 
    map<string, string> activityMap;
    checkRecorder(header, activityMap);
    if (activityMap.empty()) {
        return;
    }
    string correlator = registration()->uuid() + ":"
            + pReg_->getCorrelID(header.correl);
    RecordedEvent event;
    event.set_type(CTG);
    struct timeval ltimeval;
    int rc = gettimeofday(&ltimeval, NULL);
    if (rc != 0) {
        std::time_t ltime;
        ltime = std::time(nullptr);
        event.set_timestamp(ltime * 1000);
    } else {
        event.set_timestamp(
                ltimeval.tv_sec * 1000 + ltimeval.tv_usec / 1000);
    }
    CTGRecordedEvent* pCTG = event.mutable_ctgrecordedevent();
    if (header.reqresp == INT_BeforeLink)
        pCTG->set_type(CTGRecordedEvent_Type_REQUEST);
    else
        pCTG->set_type(CTGRecordedEvent_Type_RESPONSE);
    pCTG->set_program(header.progName, strlen(header.progName));
    pCTG->set_tranname(header.tranID, strlen(header.tranID));
    char jobname[10] = { 0 };
    strncpy(jobname, header.jobName, 8);
    strcat(jobname, " ");
    pCTG->set_jobname(jobname);
    pCTG->set_sysid(pReg_->sysid());
    pCTG->set_applid(pReg_->applid());
    pCTG->set_cicstype(CTGRecordedEvent_CICSType_TS);
 
    pCTG->set_commarealength(header.length);
    pCTG->set_payload((const void*) pCommArea->pCommarea,
            pCommArea->len);
    pCTG->set_payloadlength(pCommArea->len);
 
    if (pReg_->isDebugStubCA()) {
        log_->debug("Send COM-AREA to RIT recorder:");
        char* p = pCommArea->pCommarea;
        char buff[241] = { 0 };
        for (int i = 0; i < pCommArea->len; i += 120) {
            int maxNum = pCommArea->len - i;
            maxNum = maxNum > 120 ? 120 : maxNum;
            for (int j = 0; j < maxNum; j++) {
                sprintf(buff + 2 * j, "%2.2X", *(p + i + j));
            }
            log_->debug(buff);
        }
    }
 
    broadcast(activityMap, correlator, event);
}
