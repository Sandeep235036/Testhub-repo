/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017.All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*******************************************************************************
 * observ.cpp
 * Class
 ******************************************************************************/
#pragma csect (CODE,"HRVCOBVR")
#include "observ.h"
#include "svrpoll.h"
#include "objxfer.h"
#include "ritlog.h"
#include <pthread.h>
#include <signal.h>
#include <errno.h>
#include <stdlib.h>
#include "rtcpset.h"
 
//#define DEBUG_OBSERVATION 1
 
using namespace std;
using namespace greenhat::vie::comms::proxy;
 
Observation* Observation::s_instance = NULL;
 
Observation::Observation(CICSRegistration* reg)
:pReg_(reg), stop_(0)
{
    log_ = LoggerFactory::getInstance()->getLogger("Observation");//$NON-NLS-1$
 
    int rc = pthread_rwlockattr_init(&rwlattr_);
    if (rc == -1) {
        log_->error("error in pthread_rwlockattr_init");//$NON-NLS-1$
    }
    rc = pthread_rwlockattr_setpshared(&rwlattr_, PTHREAD_PROCESS_PRIVATE);
    if (rc == -1) {
        log_->error("error in pthread_rwlockattr_setpshared");//$NON-NLS-1$
    }
    rc = pthread_rwlock_init(&statslock_, &rwlattr_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_init statslock_");//$NON-NLS-1$
    }
 
    rc = pthread_rwlock_init(&statuslock_, &rwlattr_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_init");//$NON-NLS-1$
        FPRINTF(stdout, "pthread_rwlock_init error, errno=%d. Exiting...\n",//$NON-NLS-1$
                errno);
        raise(SIGUSR1);
    }
}
 
Observation* Observation::instance(CICSRegistration* reg) {
    if (s_instance == NULL) {
        s_instance = new Observation(reg);
    }
    return s_instance;
}
 
Observation::~Observation() {
    int i = getWaitTimeout();
    while(getStop() != 2 && i > 0){
        stop(1);
        i--;
        sleep(1);
    }
    if (pthread_rwlock_destroy(&statslock_) == -1) {
        log_->error("error in pthread_rwlock_destroy statslock_");//$NON-NLS-1$
    }
    if (pthread_rwlockattr_destroy(&rwlattr_) == -1) {
        log_->error("error in pthread_rwlockattr_destroy");//$NON-NLS-1$
    }
    if (pthread_rwlock_destroy(&statuslock_) == -1) {
        log_->error("error in pthread_rwlock_destroy loglvllock");//$NON-NLS-1$
    }
}
 
void Observation::addRequestCount(const char* progname) {
    if (observationLevel() >= LEVEL_STATISTICS) {
        int rc = pthread_rwlock_wrlock(&statslock_);
        if (rc == -1) {
            log_->error("error in pthread_rwlock_wrlock statslock_");//$NON-NLS-1$
        }
        ++requestCount_;
        requestMap_[progname] ++;
        rc = pthread_rwlock_unlock(&statslock_);
        if (rc == -1) {
            log_->error("error in pthread_rwlock_unlock statslock_");//$NON-NLS-1$
        }
    }
}
 
void Observation::addRecordedCount() {
    if (observationLevel() >= LEVEL_STATISTICS) {
        int rc = pthread_rwlock_wrlock(&statslock_);
        if (rc == -1) {
            log_->error("error in pthread_rwlock_wrlock statslock_");//$NON-NLS-1$
        }
        ++recordedCount_;
        rc = pthread_rwlock_unlock(&statslock_);
        if (rc == -1) {
            log_->error("error in pthread_rwlock_unlock statslock_");//$NON-NLS-1$
        }
    }
}
 
void Observation::addRoutingCount() {
    if (observationLevel() >= LEVEL_STATISTICS) {
        int rc = pthread_rwlock_wrlock(&statslock_);
        if (rc == -1) {
            log_->error("error in pthread_rwlock_wrlock statslock_");//$NON-NLS-1$
        }
        ++routedCount_;
        rc = pthread_rwlock_unlock(&statslock_);
        if (rc == -1) {
            log_->error("error in pthread_rwlock_unlock statslock_");//$NON-NLS-1$
        }
    }
}
extern "C" void* observation_send(void* arg);
 
void Observation::start(pthread_attr_t* attr) {
    if (pthread_create(&thread_, attr, observation_send, (void*) this) != 0) {
        log_->error("pthread_create() error, errno=%d\n", errno);//$NON-NLS-1$
    }
}
 
void Observation::stop(int status) {
    int rc = pthread_rwlock_wrlock(&statuslock_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_wrlock");//$NON-NLS-1$
    }
    stop_ = status;
    rc = pthread_rwlock_unlock(&statuslock_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_unlock");//$NON-NLS-1$
    }
    log_->info("Observation stopping ...\n");//$NON-NLS-1$
}
 
int Observation::getStop() {
    int rc = pthread_rwlock_rdlock(&statuslock_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_rdlock");//$NON-NLS-1$
    }
    int status = stop_;
    rc = pthread_rwlock_unlock(&statuslock_);
    if (rc == -1) {
        log_->error("error in pthread_rwlock_unlock");//$NON-NLS-1$
    }
    return status;
}
 
/**
 * Build the JSON-LD message content from the stats and resources for the
 * current period. Resource data is drained and stats are reset each time
 * this is called
 */
void Observation::getMessagePayload(string & messageBuf) {
    // The context section
    string contextBuf;
    // The statistics section
    string statsBuf;
    // The resources section
    string resourcesBuf;
 
    contextBuf.append(
"\"@context\": {\n\"intercept\":\"http://jazz.net/ns/qm/rtcp/intercept#\", \n").append(//$NON-NLS-1$
"\"cics\":\"http://jazz.net/ns/qm/rtcp/intercept/cics#\", \n").append(//$NON-NLS-1$
"\"intercept:resourcePropertyOrder\": {\n\"@type\": \"@id\", \n\"@container\": \"@list\"\n}\n}");//$NON-NLS-1$
 
    int requests = 0;
    int recorded = 0;
    int routed = 0;
    map<string, int> requestMap;
    char itoaBuf[32] = {0};
    // If required, add the stats
    int level = observationLevel();
    if (level > LEVEL_NONE) {
        int rc = pthread_rwlock_wrlock(&statslock_);
        if (rc == -1) {
            log_->error("error in pthread_rwlock_wrlock statslock_");//$NON-NLS-1$
        }
        requests = requestCount_;
        recorded = recordedCount_;
        routed = routedCount_;
        if(requests > 0){
            map<string, int>::iterator it = requestMap_.begin();
            for(;it != requestMap_.end(); it++){
                pair<string, int> value = *it;
                requestMap[value.first] = value.second;
            }
        }
        requestCount_ = 0;
        recordedCount_ = 0;
        routedCount_ = 0;
        requestMap_.clear();
        rc = pthread_rwlock_unlock(&statslock_);
        if (rc == -1) {
            log_->error("error in pthread_rwlock_unlock statslock_");//$NON-NLS-1$
        }
        statsBuf.append("\"intercept:statistics\":{\n");//$NON-NLS-1$
        statsBuf.append("\"intercept:requests\":")//$NON-NLS-1$
        .append(std::to_string(requests));
        //  .append(itoa(requests, itoaBuf, DECIMAL));
        statsBuf.append(",\n \"intercept:recorded\":")//$NON-NLS-1$
        .append(std::to_string(recorded));
        //  .append(itoa(recorded, itoaBuf, DECIMAL));
        statsBuf.append(",\n \"intercept:routed\":")//$NON-NLS-1$
        .append(std::to_string(routed));
       //   .append(itoa(routed, itoaBuf, DECIMAL));
        statsBuf.append("\n}");//$NON-NLS-1$
    }
 
    // If required, add the resources
    if (level >= LEVEL_RESOURCES) {
        // Add property order information
        resourcesBuf.append("\"intercept:resourcePropertyOrder\":[\n");//$NON-NLS-1$
        resourcesBuf.append("\"cics:applid\"");//$NON-NLS-1$
        resourcesBuf.append(", ");//$NON-NLS-1$
        resourcesBuf.append("\"cics:sysid\"");//$NON-NLS-1$
        resourcesBuf.append(", ");//$NON-NLS-1$
        resourcesBuf.append("\"cics:jobname\"");//$NON-NLS-1$
        resourcesBuf.append("],\n ");//$NON-NLS-1$
 
        // Add resource list
        resourcesBuf.append("\"intercept:resource\":[\n");//$NON-NLS-1$
        // Processed all resources start
        resourcesBuf.append("{");//$NON-NLS-1$
        resourcesBuf.append("\"cics:applid\":\"")
        .append(pReg_->applid()).append("\",\n ");//$NON-NLS-1$
        resourcesBuf.append("\"cics:sysid\":\"")
        .append(pReg_->sysid()).append("\",\n ");//$NON-NLS-1$
        resourcesBuf.append("\"cics:jobname\":\"")
        .append(pReg_->jobname()).append("\",\n");//$NON-NLS-1$
        resourcesBuf.append("\"intercept:count\":")
        .append(std::to_string(requests));//$NON-NLS-1$
     // .append(itoa(requests, itoaBuf, DECIMAL));//$NON-NLS-1$
        if(requests > 0){
            resourcesBuf.append(",\n");
            map<string,int>::iterator it = requestMap.begin();
            resourcesBuf.append("\"intercept:invocation\": [\n");
            for(int i = 0; it != requestMap.end(); i++, it++){
                if(i > 0){
                    resourcesBuf.append(",\n");
                }
                pair<string, int> value = *it;
                resourcesBuf.append("{ \"cics:program\" : \"")
                .append(value.first).append("\",\n")
                .append("\"intercept:count\" : ")
                .append(std::to_string(value.second)).append("\n}");//$NON-NLS-1$
            //  .append(itoa(value.second, itoaBuf, DECIMAL)).append("\n}");//$NON-NLS-1$
            }
            resourcesBuf.append("\n]");
        }
        // Processed all resources, close off the context
        resourcesBuf.append("\n}\n");//$NON-NLS-1$
        resourcesBuf.append("]");//$NON-NLS-1$
    }
 
    // Build the full payload
    messageBuf.append("{\n").append(contextBuf);
    if (statsBuf.length() > 0) {
        messageBuf.append(",\n ").append(statsBuf);
    }
    if (resourcesBuf.length() > 0) {
        messageBuf.append(",\n ").append(resourcesBuf);
    }
    messageBuf.append("}\n");//$NON-NLS-1$
#ifdef DEBUG_OBSERVATION
    FPRINTF(stdout,
    "Leaving getMessagePayload() with message below:\n%s\n",//$NON-NLS-1$
        messageBuf.c_str());
#endif
}
 
void* observation_send(void* arg) {
    sleep(2);
    Observation* observation = (Observation*) arg;
    CICSRegistration* cicsreg = observation->registration();
    Logger* log = observation->logger();
    //CHANGE
    string baseurl;
    if (!rtcp_server) {
    baseurl = cicsreg->serverUrl() + OBSERVATION_PATH_TH;
    }
    else{
    baseurl = cicsreg->serverUrl() + OBSERVATION_PATH;
    }
    std::string asciiUrl;
    ebc2asc(baseurl.c_str(), asciiUrl);
 
    pthread_t thid = pthread_self();
    FPRINTF(stdout, "Observation thread id is %X.\n", thid);
    log->info("Observation thread id is %X.\n", thid);
 
    ObjXfer xfer(baseurl,cicsreg->gsk_keyring_ring());
    int count = 0;
    while (observation->getStop() == 0) {
        int level = observation->observationLevel();
        if (level > LEVEL_NONE) {
            string uuid = cicsreg->uuid();
            if (uuid.length() == UUID_LENGTH) {
            std::string url = std::string(asciiUrl) + uuid;
            //  string url = baseurl + uuid;
                string obsrvMessage;
                observation->getMessagePayload(obsrvMessage);
 
                int rc = xfer.postObsrvMessage(url, obsrvMessage, log);
                if (rc != 0) {
                    log->error("observation_send obsrvMessage error");//$NON-NLS-1$
                }
#ifdef DEBUG_OBSERVATION
                else {
                    FPRINTF(stdout,
                   "observation level=%d, sent observation message: %s\n",//$NON-NLS-1$
                   level, obsrvMessage.c_str());
                }
#endif
            } // uuid.length
        } // level
        sleep (Observation::UPDATE_INTERVAL);
    } // while
    observation->stop(2);
    pthread_exit(NULL);
    return NULL;
}
