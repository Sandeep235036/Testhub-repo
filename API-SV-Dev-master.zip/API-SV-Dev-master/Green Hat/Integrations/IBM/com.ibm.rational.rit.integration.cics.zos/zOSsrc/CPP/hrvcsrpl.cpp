/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017.All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*******************************************************************************
 * svrpoll.cpp
 * ****************************************************************************/
#pragma csect (CODE,"HRVCSRPL")
#define OPEN_DEFAULT 1
#define OPEN_SYS_EXT 1
#define _LARGE_TIME_API 1
#define _OPEN_THREADS 3
#define  _XOPEN_SOURCE 600
#define _OPEN_SYS 1
#define _ISOC99_SROURCE 1
#define _XOPEN_SOURCE_EXTENDED 1
#define _POSIX_SOURCE 1
#define _POSIX_C_SOURCE 200112L
#define _OPEN_SYS_MUTEX_EXT 1
#define _OPEN_SYS_ITOA_EXT 1
#include "svrpoll.h"
#include "regpoll.h"
#include "cfgpoll.h"
#include "ritlog.h"
#include "observ.h"
#include "objxfer.h"
#include "servlog.h"
 
#include <pthread.h>
 
#define RULEBASE_REST_PATH     "rest/proxy/rulebase/" //$NON-NLS-1$
 
#define SERVERPOLLER_ERROR 1100
 
ServerPoller* ServerPoller::s_instance = NULL;
 
ServerPoller* ServerPoller::instance(CICSRegistration* reg) {
    if (s_instance == 0) {
        s_instance = new ServerPoller(reg);
    }
    return s_instance;
}
 
ServerPoller::ServerPoller(CICSRegistration* reg)
:pReg_(reg)
{
    log_ = LoggerFactory::getInstance()->getLogger("ServerPoller"); //$NON-NLS-1$
    serverLogger_ = ServerLogger::instance(reg);
    regPoller_ = RegisterPoller::instance(reg);
    cfgPoller_ = ConfigPoller::instance(reg);
    observation_ = Observation::instance(reg);
 
    int rc = pthread_attr_init(&thrattr_);
    if (rc == -1) {
        log_->error("error in pthread_attr_init");
        FPRINTF(stdout, "pthread_attr_init error, errno=%d. Exiting...\n", errno);//$NON-NLS-1$
        exit(SERVERPOLLER_ERROR + 4);
    }
    int ds = 1; // PTHREAD_CREATE_DETACHED
    rc = pthread_attr_setdetachstate(&thrattr_,&ds);
    if (rc == -1) {
        log_->error("error in pthread_attr_setdetachstate");//$NON-NLS-1$
        FPRINTF(stdout, "pthread_attr_setdetachstate error, errno=%d. Exiting...\n", errno);//$NON-NLS-1$
        exit(SERVERPOLLER_ERROR + 5);
    }
    rc = pthread_attr_setweight_np(&thrattr_, __MEDIUM_WEIGHT);
    if (rc == -1) {
        log_->error("error in pthread_attr_setweight_np");//$NON-NLS-1$
        FPRINTF(stdout, "pthread_attr_setweight_np error, errno=%d. Exiting...\n", errno);//$NON-NLS-1$
        exit(SERVERPOLLER_ERROR + 6);
    }
}
 
ServerPoller::~ServerPoller(){
    if (pthread_attr_destroy(&thrattr_) == -1) {
        log_->error("error in pthread_attr_destroy");//$NON-NLS-1$
    }
 
    DELETE(serverLogger_);
    DELETE(cfgPoller_);
    DELETE(observation_);
    DELETE(regPoller_);
}
 
void ServerPoller::start(){
    regPoller_->start(&thrattr_);
    cfgPoller_->start(&thrattr_);
    serverLogger_->start(&thrattr_);
    observation_->start(&thrattr_);
}
 
void ServerPoller::stop(){
    regPoller_->stop(1);
    cfgPoller_->stop(1);
    serverLogger_->stop(1);
    observation_->stop(1);
}
 
static
void* ServerPoller_removeRule(void * rulePath) {
    Logger* log = LoggerFactory::getInstance()->getLogger("ServerPoller");//$NON-NLS-1$
    bool* status = new bool;
    string * pUrl = (string*)rulePath;
    ObjXfer xfer(string(""));
    *status = xfer.remove(*pUrl, log);
    return (void*)status;
}
 
bool ServerPoller::suspendRule(const string & ruleId){
    string  path = pReg_->serverUrl() + RULEBASE_REST_PATH;
    path = path + ruleId;
    pthread_t  worker;
    bool* status = nullptr;
    int error = 0;
    int nice = 1;
    do{
        error = pthread_create(&worker, NULL, ServerPoller_removeRule, (void*)(&path));
        if(error != 0){
            log_->debug("pthread_create worker error, errno = %d\n",//$NON-NLS-1$
                    errno);
            if(errno == EAGAIN || errno == ENOMEM){
                sleep(nice++);
            }else{
                break;
            }
        }else{
            nice = 1;
        }
    }while(error != 0);
 
    if(error < 0){
        log_->error("pthread_create worker error, errno = %d",//$NON-NLS-1$
            errno);
        return false;
    }
    error = pthread_join(worker, (void**)&status);
    if(error < 0){
        log_->error("Thread RulesPoller::removeRule terminated\n");//$NON-NLS-1$
    }
    //bool bRes = *status;
    bool bRes = status ? *status : false;
 
    char msg[RIT_BUFFER_LEN_80] = {0};
    sprintf(msg, "Remove rule <%s> %s.", path.c_str(),
            bRes ? "succeeded" : "failed");
    serverLogger_->info(msg);
    DELETE(status);
    return bRes;
}
