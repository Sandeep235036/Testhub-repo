#pragma XOPTS(CICS)
#pragma csect (CODE,"HRVCQERY")
/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*********************************************************************
 * hrvcqery.c
 *
 * This program run in CICS region.
 *
 * It is invoked by ECIRequest or other Link program.
 *
 * It link to program RITSTATS to get the common-area:
 *    DS_COMM_AREA.
 *
 *
 * ******************************************************************/
#include <cics.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <cmanifes.h>
#include <time.h>
#include <sys/time.h>

#ifndef _LARGE_TIME_API
#define _LARGE_TIME_API
#endif

#define RIT_LOGGING_TDQ    "RITL"
#define RIT_STATS          "HRVCSTAT"

const char queue[] = {RIT_LOGGING_TDQ};

typedef struct DS_COMM_AREA {
    char VERSION_NUMBER[8];
    char BUILD_LEVEL[16];
    char CICS_JOBNAME[8];
    char SYSID[4];
    char CICS_LEVEL[8];
    char OS_LEVEL[8];
    char LIBRARY_DSNAME[44];
    char YEAR_MON_DAY_TIME[64]; /* YYYY MM DD HH:MM:SS 20 */
} RitqComm;
/*
 * Main transaction program
 */
void main() {
    RitqComm* pCommarea = NULL;

    char msg80[80] = "";
    short int leng = 80; /* Length for messages         */
    /* Get the EIB address */
    EXEC CICS ADDRESS EIB(dfheiptr);

    EXEC CICS ADDRESS COMMAREA( pCommarea );

    if (dfheiptr->eibresp != DFHRESP(NORMAL)) {
        sprintf(msg80,
        "In Perfrm03: ADDRESS COMMAREA error, resp1=%d,resp2=%d\n",
            dfheiptr->eibresp, dfheiptr->eibresp2);
        EXEC CICS WRITEQ TD QUEUE(queue) FROM (msg80) LENGTH(leng);
    }

    int iLength = sizeof(RitqComm);

    EXEC CICS LINK PROGRAM(RIT_STATS)
    COMMAREA (pCommarea) LENGTH(iLength);

    if (dfheiptr->eibresp != DFHRESP(NORMAL)) {
        sprintf(msg80, "Link to RITSTATS error, resp1=%d, resp2=%d\n",
            dfheiptr->eibresp, dfheiptr->eibresp2);
        EXEC CICS WRITEQ TD QUEUE(queue) FROM (msg80) LENGTH(leng);
    }

    EXEC CICS RETURN;
}
