#pragma XOPTS(CICS)
#pragma CSECT(CODE,"HRVCTRGR")
/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*********************************************************************
 * HRVCTRGR.c
 *
 * This program run in CICS region.
 *
 * It is invoked by ATI TRIGGER TASK.
 *
 * It reads the header and common area from RITQ (TDQ)
 * and sends those to RITCICS by socket.
 *
 * HRVCTRGR will read the RITQ until it empty (QZERO).
 *
 * ******************************************************************/
#ifndef _OPEN_SYS_SOCK_IPV6
#define _OPEN_SYS_SOCK_IPV6
#define _XOPEN_SOURCE
#define _POSIX_SOURCE
#define _ISOC99_SOURCE
#define _ALL_SOURCE
#define _XOPEN_SOURCE_EXTENDED 1
#define _OPEN_SYS_SOCK_EXT
#define _OPEN_SYS_ITOA_EXT
#endif

#include <cics.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <time.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/sys_time.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <net/rtrouteh.h>
#include <net/if.h>
#include <cmanifes.h>

/*  #define DEBUG_HRVCTRGR  1 */

#define SERV_PORT         7819
#define MAX_PORT_NUMBER   65535
#define RIT_MAX_BIND_ADDR_LEN 48
#define RIT_MAX_BIND_PORT_LEN 5
#define MAX_MSG_LEN       32707
#define BUFFER_LEN        (MAX_MSG_LEN + sizeof(Header))

#define EBCDIC_SPACE   '\40'

#define RIT_LOGGING_TDQ    "RITL"
#define RIT_SOURCE_TDQ     "RITQ"
#define RIT_TEMP_STOR_QUEUE  "RITTEMPSTORQUEUE"
#define RIT_TSQ_BIND_ADDR    "RITTSQBINDADDRES"

const char queue[] = RIT_LOGGING_TDQ;
const char RitTSQName[] = RIT_TEMP_STOR_QUEUE;
const char RitBindAddr[] = RIT_TSQ_BIND_ADDR;
const char tdqueue[] = RIT_SOURCE_TDQ;
const char blank80[81] = "                                        "
                         "                                        ";
const int flag = 0;        /* Flag set to 0 for recv cmd  */
const int call_failed = -1;
const int max_sock = 2000;

/* this structure must be same with structure Header in socksvr.h */
#include "protocl.h"

/*
 * get the ritcics listen port
 */
int getPort();
/*
 * get the ritcics bind address
 */
int getBindAddr(char* rit_bind_addr);

int handleDPL(int sock_desc);

/*
 * Get the header and commarea from TDQ,
 * send to CICS agent run in batch and
 * set the response to 1 to let RITCICS know we are recording.
 */
void main() {
    unsigned short servers_port; /* Port server has bound to    */
    char rit_bind_addr[RIT_MAX_BIND_ADDR_LEN];
    char rit_bind_port[RIT_MAX_BIND_PORT_LEN];
    struct addrinfo hints, *hostinfo, *hostsave;
    int sock_desc; /* Socket connected & received */

    signed int init_rc;  /* Initapi Return Code         */
    signed int getd_rc; /* GetAddrinfo Return code     */
    signed int conn_rc;  /* Connect    Return Code      */
    signed int close_rc; /* Close  Return Code          */
    short int leng = 80; /* Length for messages         */
    char msg80[81] = "";

    EXEC CICS ADDRESS EIB(dfheiptr);

    memset(rit_bind_addr, 0, RIT_MAX_BIND_ADDR_LEN);

    servers_port = getPort();
    if(servers_port < 0 || servers_port > MAX_PORT_NUMBER){
        EXEC CICS RETURN;
    }
    itoa(servers_port,rit_bind_port,DECIMAL);

    int rc = getBindAddr(rit_bind_addr);
    if(rc < 0){

        sprintf(msg80, "Get RIT bind address failed.\n");
        EXEC CICS
        WRITEQ TD
        QUEUE (queue)
        FROM (msg80)
        LENGTH (leng);

        EXEC CICS RETURN;
    }

    /******************/
    /*  INITAPI  Call */
    /******************/

    init_rc = initapi(max_sock, NULL);
    strncpy(msg80, blank80, 80);
    if (init_rc < 0) {
        if(errno == 10197){
            ;
        }else{
            sprintf(msg80, "INITAPI UNsuccesful rc = %d. "
                 "The global errno is %d.\n", init_rc, errno);
            EXEC CICS
            WRITEQ TD
            QUEUE (queue)
            FROM (msg80)
            LENGTH (leng);

            EXEC CICS RETURN;
        }
    }
     /******************/
     /*  SOCKET  Call  */
     /******************/
     memset(&hints, 0 ,sizeof hints);
     hints.ai_socktype= SOCK_STREAM;
     hints.ai_family= AF_UNSPEC;


     getd_rc = getaddrinfo(rit_bind_addr,rit_bind_port,&hints,
                           &hostinfo);
     if(getd_rc != 0){
         strncpy(msg80, blank80, 80);
         sprintf(msg80, "getaddrinfo error: %s",gai_strerror(getd_rc));
         EXEC CICS
         WRITEQ TD
         QUEUE (queue)
         FROM (msg80)
         LENGTH (leng);

         EXEC CICS RETURN;
     }

     hostsave = hostinfo;

     do {
         sock_desc = socket(hostinfo->ai_family, hostinfo->ai_socktype,
                 hostinfo->ai_protocol);
         if(sock_desc < 0) {
             continue;
         }
         conn_rc=connect(sock_desc,hostinfo->ai_addr,
            hostinfo->ai_addrlen);
         if(conn_rc != -1){
             break; /* connect success */
         }
         close(sock_desc);
     } while ((hostinfo = hostinfo->ai_next) != NULL);
     if (hostinfo == NULL) {
         freeaddrinfo(hostsave);
         strncpy(msg80, blank80, 80);
         sprintf(msg80, "CONNECT UNsuccesful. "
             "The global errno is %d.\n", errno);
         EXEC CICS
         WRITEQ TD
         QUEUE (queue)
         FROM (msg80)
         LENGTH (leng);

         EXEC CICS RETURN;
     }

    init_rc = handleDPL(sock_desc);
    /******************/
    /*  CLOSE   Call  */
    /******************/
    if ((close_rc = close(sock_desc)) == call_failed)
    {
        freeaddrinfo(hostsave);
        strncpy(msg80, blank80, 80);
        sprintf(msg80, "CLOSE UNsuccesful "
          "The global errno is %d.\n", errno);
        EXEC CICS WRITEQ TD QUEUE(queue) FROM(msg80) LENGTH(leng);
    }

    freeaddrinfo(hostsave);
    EXEC CICS RETURN;
}

/**
 * return message leng if normal
 * return 0 if get QZERO
 * return -1 if error
 */
int readTDQ(char* buffer, short len){
    char msg80[81] = {0};
    const int leng = 80; /* Length for messages         */
    short msgLen = len;
    Header* pHeader;

    EXEC CICS
    READQ TD QUEUE(tdqueue) INTO(buffer)
    LENGTH(&msgLen) NOHANDLE;

    if(dfheiptr->eibresp == DFHRESP(NORMAL)){
        pHeader = (Header*)buffer;
        pHeader->response = 1;
        return msgLen;
    } else if(dfheiptr->eibresp == DFHRESP(QZERO)){
        return 0;
    } else {
        strncpy(msg80, blank80, 80);
        sprintf(msg80, "Read TDQ error, requested len=%d, "
            "resp1=%d,resp2=%d.\n", len,
             dfheiptr->eibresp, dfheiptr->eibresp2);
        EXEC CICS
        WRITEQ TD
        QUEUE (queue)
        FROM (msg80)
        LENGTH (leng);
        return -1;
    }
    return -1;
}

int handleDPL(int sock_desc) {
    char msg80[81] = {0};
    const int leng = 80; /* Length for messages         */
    short tdqMsgLen = BUFFER_LEN;
    char buffer[BUFFER_LEN] = {0};

    int rc, msgLen;
    int i = 0;
    while (++i) {
        msgLen = readTDQ(buffer, tdqMsgLen);
        if( msgLen <= 0){
            break;
        }
        if( msgLen < sizeof(Header)){
            strncpy(msg80, blank80, 80);
            sprintf(msg80, "Read TDQ message length less than "
                    "header length. Return now.\n");
            EXEC CICS
            WRITEQ TD
            QUEUE (queue)
            FROM (msg80)
            LENGTH(leng);
            break;
        }

        /*****************************/
        /*  Send comm-area to server */
        /*****************************/
        if ((rc = send(sock_desc, buffer, msgLen, flag))
                == call_failed) {
            strncpy(msg80, blank80, 80);
            sprintf(msg80, "SEND message UNsuccesful. "
                    "The global errno is %d.\n", errno);
            EXEC CICS
            WRITEQ TD
            QUEUE (queue)
            FROM (msg80)
            LENGTH(leng);

            break;
        }

    } /* end of while */

    return rc;
}

/*
 * get the ritcics listen port from TSQ RITS
 */
int getPort(){
    char msg80[81] = "";
    const int leng = 80;
    int defalutPort = SERV_PORT;
    short dataLen = 4;
    int port;

    EXEC CICS READQ TS QNAME(RitTSQName) INTO(&port) LENGTH(&dataLen)
              ITEM(1) NOHANDLE;

    if(dfheiptr->eibresp != DFHRESP(NORMAL))
    {
        strncpy(msg80, blank80, 80);
        sprintf(msg80, "READQ TS failed, "
            "resp1=%d,resp2=%d.\n",
             dfheiptr->eibresp, dfheiptr->eibresp2);
        EXEC CICS
        WRITEQ TD
        QUEUE (queue)
        FROM (msg80)
        LENGTH (leng);
        return defalutPort;
    }
    return port;
}

/*
 * get the ritcics bind address from TSQ
 */
int getBindAddr(char* rit_bind_addr){
    short dataLen = RIT_MAX_BIND_ADDR_LEN;
    char msg80[81] = "";
    int leng = 80;

    EXEC CICS READQ TS QNAME(RitBindAddr) INTO(rit_bind_addr)
         LENGTH(&dataLen) ITEM(1) NOHANDLE;

    if(dfheiptr->eibresp != DFHRESP(NORMAL))
    {
        strncpy(msg80, blank80, 80);
        sprintf(msg80, "READQ TS failed, "
            "resp1=%d,resp2=%d.\n",
             dfheiptr->eibresp, dfheiptr->eibresp2);
        EXEC CICS
        WRITEQ TD
        QUEUE (queue)
        FROM (msg80)
        LENGTH (leng);
        return -1;
    }
    return 0;
}

