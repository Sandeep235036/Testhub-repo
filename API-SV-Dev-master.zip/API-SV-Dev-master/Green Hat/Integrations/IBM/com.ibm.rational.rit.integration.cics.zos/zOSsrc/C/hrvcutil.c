#pragma XOPTS(EXCI)
#pragma CSECT(CODE,"HRVCUTIL")
#ifndef  _RITDLL_
#define  _RITDLL_
#endif
/********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *********************************************************************/
/*********************************************************************
 * ritexcid.c
 *********************************************************************/
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#include "dfhxcplh.h"
#include "ritutil.h"

/* #define DEBUG_RITEXCID 1 */

#define RITCONFG_NAME "HRVCCNFG"
#define RITHRTBT_NAME "HRVCHTBT"
#define RITMNGRC_NAME "HRVCMGRC"

/* WI 50417: PMR 43215,689,864 */
#define RIT_DEFAULT_EXCI_TRANID "RITX"
#define RIT_EXCI_TRANID "RIT_EXCI_TRANID"

#define no_abort   0
#define yes        1
#define MAX_COMMAREA_LENGTH 512   /* 507 + 4 (sizeof int) =511 */
void linkrets(exci_exec_return_code *);

char g_transid??(4??) = {0};
/*===================================================================*/
/*                                                                   */
/*   getTranId:   This routine will get the transaction id of EXCI   */
/*                The default is RITX. End user can use their special*/
/*                transaction id in RITUSD#T. But the transaction id */
/*                also need to define ENVAR(RIT_EXCI_TRANID=CUSX).   */
/*===================================================================*/
const char* getTranId(){
    if(g_transid[0] != 0){
        return g_transid;
    }
    char* envvar = NULL;
    envvar = getenv(RIT_EXCI_TRANID);
    if(envvar){
        fprintf(stdout, "Getenv RIT_EXCI_TRANID=%s\n", envvar);
        strncpy(g_transid, envvar, 4);
    }else{
        strncpy(g_transid, RIT_DEFAULT_EXCI_TRANID, 4);
    }
    return g_transid;
}
/*===================================================================*/
/*                                                                   */
/*   execcall:    This routine will use an EXEC level EXCI link      */
/*                request to call into the target CICS system, and   */
/*                invoke the RITCONFG program                        */
/*===================================================================*/
int execcall(EXCICOMMAREA* pcomm,
             const char* system)
{
#ifdef DEBUG_RITEXCID
     fprintf(stdout, "Entering execcall...\n");
     fprintf(stdout, "The CICS applid is: %s\n", system);
     fprintf(stdout, "The filter rule number is: %d\n",
             pcomm->ruleNum);
#endif

    char program??(8??) = {0};
    char applid??(8??) = {0};
    const char* transid = getTranId();
    strncpy(program,"        ",8);
    strncpy(program, RITCONFG_NAME, 8);
    int parm_len = strlen(system);
    strncpy(applid,"        ",8);
    strncpy(applid, system, parm_len);
/*===================================================================*/
/*   Declare local variables.                                        */
/*===================================================================*/
                                           /*=====================*/
 exci_exec_return_code link_retarea;          /* EXEC Return area.   */
 short int link_commlength;                   /* Length of Commarea  */
 short int link_datalength;                   /* Len of outbound area*/
 short int abort_needed = no_abort;           /* Abort flag.         */
/*===================================================================*/
/*   Set the Commarea Length and Data Length constants(in bytes).    */
/*===================================================================*/
    link_commlength = MAX_COMMAREA_LENGTH;
    link_datalength = pcomm->ruleNum * RIT_DPL_FILTER_LEN +
            sizeof(int);

#ifdef DEBUG_RITEXCID
     fprintf(stdout, "Before call EXEC_CICS_LINK\n");
     fprintf(stdout, "Comm-area length is %d\n", link_commlength);
     fprintf(stdout, "Data length is %d\n", link_datalength);
#endif
/*===================================================================*/
/*                                                                   */
/*   Perform the Link Request.                                       */
/*                                                                   */
/*===================================================================*/
  EXEC CICS LINK PROGRAM(program)
                      APPLID(applid)
                      RETCODE(&link_retarea)
                      COMMAREA(pcomm)
                      LENGTH(link_commlength)
                      DATALENGTH(link_datalength)
                      TRANSID(transid)
                      SYNCONRETURN;

#ifdef DEBUG_RITEXCID
     fprintf(stdout,
         "After call EXEC_CICS_LINK, return code=%d\n",
         link_retarea.exec_resp);
#endif
/*===================================================================*/
/*                                                                   */
/*   Check on how successful the call was.                           */
/*                                                                   */
/*===================================================================*/
                                           /*========================*/
   if (link_retarea.exec_resp != 0)        /* Check high lvl response*/
   {                                       /*                        */
      linkrets(&link_retarea);             /* Output response codes  */
      abort_needed=yes;                    /*                        */
   }                                       /*                        */
   return(abort_needed);                   /*========================*/
}

/*===================================================================*/
/*                                                                   */
/*   heartbtc:     This routine will use an EXEC level EXCI link      */
/*                request to call into the target CICS system, and   */
/*                invoke the RITHRTBT program                        */
/*===================================================================*/
int heartbtc(COMMSTATUS* pcomm,
             const char* system)
{
#ifdef DEBUG_RITEXCID
     fprintf(stdout, "Entering heartbtc...\n");
     fprintf(stdout, "The CICS applid is: %s\n", system);
#endif

    char program??(8??) = {0};
    char applid??(8??) = {0};
    const char* transid = getTranId();
    strncpy(program,"        ",8);
    strncpy(program, RITHRTBT_NAME, 8);
    int parm_len = strlen(system);
    strncpy(applid,"        ",8);
    strncpy(applid, system, parm_len);
/*===================================================================*/
/*   Declare local variables.                                        */
/*===================================================================*/
                                           /*=====================*/
 exci_exec_return_code link_retarea;          /* EXEC Return area.   */
 short int link_commlength;                   /* Length of Commarea  */
 short int abort_needed = no_abort;           /* Abort flag.         */
/*===================================================================*/
/*   Set the Commarea Length and Data Length constants(in bytes).    */
/*===================================================================*/
    link_commlength = sizeof(int);

#ifdef DEBUG_RITEXCID
     fprintf(stdout, "Before call EXEC_CICS_LINK\n");
     fprintf(stdout, "Comm-area length is %d\n", link_commlength);
#endif
/*===================================================================*/
/*                                                                   */
/*   Perform the Link Request.                                       */
/*                                                                   */
/*===================================================================*/
  EXEC CICS LINK PROGRAM(program)
                      APPLID(applid)
                      RETCODE(&link_retarea)
                      COMMAREA(pcomm)
                      LENGTH(link_commlength)
                      TRANSID(transid)
                      SYNCONRETURN;

#ifdef DEBUG_RITEXCID
     fprintf(stdout,
         "After call EXEC_CICS_LINK, return code=%d\n",
         link_retarea.exec_resp);
#endif
/*===================================================================*/
/*                                                                   */
/*   Check on how successful the call was.                           */
/*                                                                   */
/*===================================================================*/
                                           /*========================*/
   if (link_retarea.exec_resp != 0)        /* Check high lvl response*/
   {                                       /*                        */
      linkrets(&link_retarea);             /* Output response codes  */
      abort_needed=yes;                    /*                        */
   }                                       /*                        */
   return(abort_needed);                   /*========================*/
}

void linkrets(exci_exec_return_code *pRet_Area)
{
    char      pMsg_String[256];
    short int Msg_Len;
    /* output response, reason, subreason */
    fprintf(stdout, "EXCI LINK failed. "
    "Response = %d Response2 = %d "
      "Abend Code = %4.4s*\n",
               pRet_Area->exec_resp,
               pRet_Area->exec_resp2,
               pRet_Area->exec_abcode);

    /* output message if one exists */
    if (pRet_Area->exec_msg_ptr != NULL)
    {
      /* get message length       */
      Msg_Len = pRet_Area->exec_msg_len;
      Msg_Len = Msg_Len > 255 ? 255 : Msg_Len;
      memcpy(pMsg_String, pRet_Area->exec_msg_ptr, Msg_Len);

      /* null terminate our message string */
      *(pMsg_String + Msg_Len) = '\0';

      /* output message */
      fprintf(stdout, "%80.120s\n", pMsg_String);
    }

    return;
}


/*===================================================================*/
/*                                                                   */
/*   enabcrit:    This routine will use an EXEC level EXCI link      */
/*                request to call into the target CICS system, and   */
/*                invoke the RITMAINTC program                       */
/*===================================================================*/
int enabcrit(RITMCOMM* pcomm,
             const char* system)
{
#ifdef DEBUG_RITEXCID
     fprintf(stdout, "Entering enabcrit...\n");
     fprintf(stdout, "The CICS applid is: %s\n", system);
     fprintf(stdout, "The command is: %d\n",
             pcomm->command);
#endif
     const char * transid = getTranId();
     char program??(8??) = {0};;
     char applid??(8??) = {0};
     strncpy(program,"        ",8);
     strncpy(program, RITMNGRC_NAME, 8);
     int parm_len = strlen(system);
     strncpy(applid,"        ",8);
     strncpy(applid, system, parm_len);

#ifdef DEBUG_RITEXCID
     fprintf(stdout, "transid is:\'%8.8s\'\n", transid);
     fprintf(stdout, "program is:\'%8.8s\'\n", program);
     fprintf(stdout, "applid  is:\'%8.8s\'\n", applid);
#endif
/*===================================================================*/
/*   Declare local variables.                                        */
/*===================================================================*/
                                              /*=====================*/
 exci_exec_return_code link_retarea;          /* EXEC Return area.   */
 short int link_commlength;                   /* Length of Commarea  */
 short int abort_needed = no_abort;           /* Abort flag.         */
/*===================================================================*/
/*   Set the Commarea Length constants(in bytes).                    */
/*===================================================================*/
    link_commlength = sizeof(RITMCOMM);
#ifdef DEBUG_RITEXCID
     fprintf(stdout, "Before call EXEC_CICS_LINK\n");
     fprintf(stdout, "Comm-area length is %d\n", link_commlength);
#endif
/*===================================================================*/
/*                                                                   */
/*   Perform the Link Request.                                       */
/*                                                                   */
/*===================================================================*/
  EXEC CICS LINK PROGRAM(program)
                      APPLID(applid)
                      RETCODE(&link_retarea)
                      COMMAREA(pcomm)
                      LENGTH(link_commlength)
                      TRANSID(transid)
                      SYNCONRETURN;

#ifdef DEBUG_RITEXCID
     fprintf(stdout,
         "After call CICS LINK: return code=%d, status=%d\n",
         link_retarea.exec_resp, pcomm->status);
     char sysid[5] = {0};
     snprintf(sysid, 4, "%s", pcomm->sysid);
     fprintf(stdout,
         "After call CICS LINK: SYSID=%s\n",
              sysid);

     char jobname[9] = {0};
     snprintf(jobname, 8, "%s", pcomm->jobname);
     fprintf(stdout,
         "After call CICS LINK: SYSID=%s, JOBNAME=%s\n",
             jobname);
#endif
/*===================================================================*/
/*                                                                   */
/*   Check on how successful the call was.                           */
/*                                                                   */
/*===================================================================*/
                                           /*========================*/
   if (link_retarea.exec_resp != 0)        /* Check high lvl response*/
   {                                       /*                        */
      linkrets(&link_retarea);             /* Output response codes  */
      abort_needed=yes;                     /*                        */
   }                                        /*                        */
   return(abort_needed);                    /*========================*/
}
