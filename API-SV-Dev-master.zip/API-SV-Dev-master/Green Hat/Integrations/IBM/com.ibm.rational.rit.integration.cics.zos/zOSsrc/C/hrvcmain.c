#pragma XOPTS(CICS)
#pragma CSECT(CODE,"HRVCMAIN")
/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/*********************************************************************
 * ritmainc.c
 *
 * This program run in CICS region.
 *
 * It is invoked by RITEXITC by link and it gets necessary headers
 * and comm-area by container.
 *
 * It is invoked by RITMNGRC by link and it gets dummy headers to
 * test connection to RITAGENT HRVCSSVR which listen on local port.
 *
 * It send the EXIT XPCREQ/XPCREQC call event
 * to RIT CICS Agent run in batch.
 * ******************************************************************/
#ifndef _OPEN_SYS_SOCK_IPV6
#define _OPEN_SYS_SOCK_IPV6
#define _XOPEN_SOURCE
#define _POSIX_SOURCE
#define _ISOC99_SOURCE
#define _ALL_SOURCE
#define _XOPEN_SOURCE_EXTENDED 1
#define _OPEN_SYS_SOCK_EXT
#define _OPEN_SYS_ITOA_EXT
#endif

#include <cics.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <time.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/sys_time.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <net/rtrouteh.h>
#include <net/if.h>
#include <cmanifes.h>
#include <stdarg.h>
#include "protocl.h"

#define CNTNR_CONTAINERNAME "HRVUSEDCONTAINER"
#define CNTNR_APPCOMAREA   "APPCOMMAREA     "

#define SERV_PORT         7819
#define MAX_PORT_NUMBER   65535
#define RIT_MAX_BIND_ADDR_LEN 48
#define RIT_MAX_BIND_PORT_LEN 5

#define INT_BeforeLink      4
#define INT_AfterLink       8
#define INT_OK              4
#define INT_Bypass          8

#define EBCDIC_SPACE   '\40'

#define RIT_LOGGING_TDQ      "RITL"
#define RIT_TEMP_STOR_QUEUE  "RITTEMPSTORQUEUE"
#define RIT_TSQ_BIND_ADDR    "RITTSQBINDADDRES"

const char RitTSQName[] = RIT_TEMP_STOR_QUEUE;
const char RitBindAddr[] = RIT_TSQ_BIND_ADDR;

const int flag = 0; /* Flag set to 0 for recv cmd  */
const int call_failed = -1;
const int max_sock = 2000;
static int s_port = 0;
char channelName[16];

/*
 * Get the progname, jobname, commarea from caller program by channel.
 */
int getCommareaContent(Header* pHeader, Commarea* pComarea);

/*
 * get the ritcics listen port
 */
int getPort();
/*
 * get the ritcics bind address
 */
int getBindAddr(char* rit_bind_addr);
/*
 * Put the progname, jobname, commarea to caller program by channel.
 */

/*
 * Get message from container
 */
int getCICSContainerIntoCommarea(const char* channelNameIn,
        const char* containerNameIn, void* databuffer, int* leng);

int putCommarea(Commarea* comArea);

int putHeader(const Header* header);

/*
 *  write message to container
 */
int putCICSContainer(const char* channelName, const char* containerName,
        const void* dptr, int* leng);
/*
 * Write messages to ts queue
 */

int log(const char* format, ...) {
    va_list args;
    va_start(args, format);
    short int leng = 80; /* Length for messages         */
    char msg80[81];

    memset(msg80, ' ', leng);
    sprintf(msg80, format, args);

    EXEC CICS
    WRITEQ TD
    QUEUE(RIT_LOGGING_TDQ)
    FROM (msg80)
    LENGTH(leng);

    va_end(args);
}

/*
 * Get the commarea, send to CICS agent run in batch and
 * put the response from CICS agent to caller program by channel.
 */
void main() {
    unsigned short servers_port; /* Port server has bound to    */
    char rit_bind_addr[RIT_MAX_BIND_ADDR_LEN];
    char rit_bind_port[RIT_MAX_BIND_PORT_LEN];
    struct addrinfo hints, *hostinfo, *hostsave;
    int sock_desc; /* Socket connected & received */

    signed int init_rc; /* Initapi Return Code         */
    signed int getd_rc; /* GetAddrinfo Return code     */
    signed int conn_rc; /* Connect    Return Code      */
    signed int recv_rc; /* Recv        Return Code     */
    signed int send_rc; /* send   Return Code          */
    signed int close_rc; /* Close  Return Code          */

    short int leng = 80; /* Length for messages         */
    char msg80[81] = "";
    const int call_failed = -1;

    memset(rit_bind_addr, 0, RIT_MAX_BIND_ADDR_LEN);


    EXEC CICS
    ADDRESS EIB( dfheiptr);

    servers_port = getPort();
    if (servers_port < 0 || servers_port > MAX_PORT_NUMBER) {
        EXEC CICS
        RETURN;
    }
    itoa(servers_port, rit_bind_port, DECIMAL);
    int rc = getBindAddr(rit_bind_addr);
    if (rc < 0) {
        log("Get RIT bind address failed.\n");
        EXEC CICS
        RETURN;
    }

    /******************/
    /*  INITAPI  Call */
    /******************/

    init_rc = initapi(max_sock, NULL );
    memset(msg80, ' ', sizeof msg80);
    if (init_rc < 0) {
        if (errno == 10197) {
            ;
        } else {
            log("INITAPI UNsuccesful rc = %d. "
                    "The global errno is %d.\n", init_rc, errno);
            EXEC CICS
            RETURN;
        }
    }

    /******************/
    /*  SOCKET  Call  */
    /******************/
    memset(&hints, 0, sizeof hints);
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_family = AF_UNSPEC;

    getd_rc = getaddrinfo(rit_bind_addr, rit_bind_port, &hints,
            &hostinfo);
    if (getd_rc != 0) {
        log("getaddrinfo: %s", gai_strerror(getd_rc));
        log("getaddrinfo UNsuccesful, "
                "The global errno is %d.\n", errno);
        EXEC CICS
        RETURN;
    }

    hostsave = hostinfo;

    do {
        sock_desc = socket(hostinfo->ai_family, hostinfo->ai_socktype,
                hostinfo->ai_protocol);
        if (sock_desc < 0) {
            continue;
        }
        conn_rc = connect(sock_desc, hostinfo->ai_addr,
                hostinfo->ai_addrlen);
        if (conn_rc != -1) {
            break; /* connect success */
        }
        close(sock_desc);
    } while ((hostinfo = hostinfo->ai_next) != NULL );
    if (hostinfo == NULL ) {
        log("CONNECT UNsuccesful. "
                "The global errno is %d.\n", errno);
        EXEC CICS
        RETURN;
    }
    freeaddrinfo(hostsave);
    /******************************
     * Business logic
     ******************************/
    Header header;
    EXEC CICS ASSIGN CHANNEL(channelName);
    if (getHeader(&header) < 0) {
        EXEC CICS
        RETURN;
    }
    if ((send_rc = send(sock_desc, (char*) &header, sizeof(header),
            flag)) == call_failed) {
        log("SEND header UNsuccesful. "
                "The global errno is %d.\n", errno);
        close(sock_desc);
        EXEC CICS
        RETURN;
    }
    int isCommarea = strncmp(channelName, CHANNEL_NAME,
            sizeof channelName)==0?1:0;
    if (isCommarea) {
        Commarea comArea;
        comArea.pCommarea = NULL;
        comArea.len = 0;
        if (header.length == 0) {
            if (header.reqresp == INT_BeforeLink
                    && strncmp(header.correl, RIT_DUMMY_COR, 4) == 0
                    && strncmp(header.jobName, RIT_DUMMY_JOB, 8) == 0
                    && strncmp(header.progName, RIT_DUMMY_PGM, 8) == 0
                    && strncmp(header.tranID, RIT_DUMMY_TRN, 4) == 0) {
            log("Got TEST CONNECTION package and sent to RITAGENT.\n");
            }else if (header.reqresp == INT_BeforeLink
                    && strncmp(header.correl, RIT_PLTSD_COR, 4) == 0
                    && strncmp(header.jobName, RIT_PLTSD_JOB, 8) == 0
                    && strncmp(header.progName, RIT_PLTSD_PGM, 8) == 0
                    && strncmp(header.tranID, RIT_DUMMY_TRN, 4) == 0) {
                log("Got SHUTDOWN package and sent to RITAGENT.\n");
            }
            /*other programs that are linked with empty commarea*/

        } else if(getCommareaContent(&header, &comArea) < 0) {
            EXEC CICS
            RETURN;
        }

        /*****************************/
        /*  Send comm-area to server */
        /*****************************/

        if (comArea.len > 0) {
            if ((send_rc = send(sock_desc, comArea.pCommarea,
                    comArea.len, flag)) == call_failed) {
                log("Send Commarea UNsuccesful. "
                        "The global errno is %d.\n", errno);

                close(sock_desc);

                free(comArea.pCommarea);
                EXEC CICS
                RETURN;
            }
        }

        /******************/
        /*  RECV    Call  */
        /******************/
        memset((void*) (&header), 0, sizeof(header));

        if ((recv_rc = recv(sock_desc, (char*) &header, sizeof(header),
                flag)) == call_failed) {
            log("RECV header UNsuccesful. "
                    "The global errno is %d.\n", errno);

            close(sock_desc);

            EXEC CICS
            RETURN;
        }

        putHeader(&header);

        if (header.reqresp == INT_BeforeLink) {
            if (header.length > 0) {
                size_t nsize = header.length;

                if (header.dataLength > 0
                        && header.dataLength < header.length) {
                    nsize = header.dataLength;
                }

                void* commptr=realloc(comArea.pCommarea,
                        nsize);
                if (commptr == NULL ||
                     (recv_rc = recv(sock_desc,commptr, nsize, flag))
                        == call_failed) {
                    log("RECV Commarea UNsuccesful "
                            "The global errno is %d.\n", errno);
                    close(sock_desc);
                    (commptr == NULL)?
                            free(comArea.pCommarea):free(commptr);
                    EXEC CICS
                    RETURN;
                }else {
                    comArea.pCommarea =(char*)commptr;
                }

                comArea.len = nsize;
                putCommarea(&comArea);
            } else if (strncmp(header.correl, RIT_DUMMY_COR, 4) == 0
                    && strncmp(header.jobName, RIT_DUMMY_JOB, 8) == 0
                    && strncmp(header.progName, RIT_DUMMY_PGM, 8) == 0
                    && strncmp(header.tranID, RIT_DUMMY_TRN, 4) == 0) {
                log("Got TEST CONNECTION response %d from RITAGENT.\n",
                        header.response);
            } else if (strncmp(header.correl, RIT_PLTSD_COR, 4) == 0
                    && strncmp(header.jobName, RIT_PLTSD_JOB, 8) == 0
                    && strncmp(header.progName, RIT_PLTSD_PGM, 8) == 0
                    && strncmp(header.tranID, RIT_DUMMY_TRN, 4) == 0) {
                log("Got SHUTDOWN response %d from RITAGENT.\n",
                        header.response);
            }
        }
        if (comArea.len != 0 && comArea.pCommarea != NULL ) {
            free(comArea.pCommarea);
        }

    } else {
        char browseToken[4];
        char containerName[16];
        char* dataarea = NULL;
        int flength = 0;

        ContainerHeader containerHeader;

        EXEC CICS
        STARTBROWSE CONTAINER BROWSETOKEN(browseToken)
        CHANNEL(channelName);
        EXEC CICS
        GETNEXT CONTAINER(containerName)
        BROWSETOKEN(browseToken);
        while (dfheiptr->eibresp == DFHRESP(NORMAL)) {
            EXEC CICS
            GET CONTAINER( containerName)
            CHANNEL (channelName)
            SET(dataarea)
            FLENGTH(&flength);
            if (strncmp(containerName, CNTNR_CONTAINERNAME, 16) == 0){
                /* do nothing for rit container */
            }
            else if(flength > 0 && dataarea != NULL ) {
                strncpy(containerHeader.containerName, containerName,
                        sizeof(containerHeader.containerName));
                containerHeader.length = flength;
                if ((send_rc = send(sock_desc, (char*) &containerHeader,
                        sizeof(containerHeader), flag))
                        == call_failed) {
                    log("SEND containerHeader UNsuccesful. "
                            "The global errno is %d.\n", errno);
                    close(sock_desc);
                    EXEC CICS
                    RETURN;
                }
                if ((send_rc = send(sock_desc, dataarea, flength, flag))
                        == call_failed) {
                    log("Send Commarea UNsuccesful. "
                            "The global errno is %d.\n", errno);
                    close(sock_desc);
                    EXEC CICS
                    RETURN;
                }
                EXEC CICS DELETE CONTAINER(containerName)
                CHANNEL (channelName);
            }
            EXEC CICS
            GETNEXT CONTAINER( containerName)
            BROWSETOKEN(browseToken);
        }
        EXEC CICS
        ENDBROWSE CONTAINER BROWSETOKEN(browseToken);
        /*send a empty header to indicate the end of container list*/
        memset((void*) &containerHeader, 0, sizeof(containerHeader));
        strncpy(containerHeader.containerName, containerName, 16);
        containerHeader.length = 0;
        if ((send_rc = send(sock_desc, (char*) &containerHeader,
                sizeof(containerHeader), flag)) == call_failed) {
            log("SEND containerHeader UNsuccesful. "
                    "The global errno is %d.\n", errno);
            close(sock_desc);
            EXEC CICS
            RETURN;
        }


        /******************************************
         * Receive stub data from server
         ******************************************/
        memset((void*) (&header), 0, sizeof(header));

        if ((recv_rc = recv(sock_desc, (char*) &header, sizeof(header),
                flag)) == call_failed) {
            log("RECV header UNsuccesful. "
                    "The global errno is %d.\n", errno);

            close(sock_desc);

            EXEC CICS
            RETURN;
        }

        putHeader(&header);
		memset((void*) &containerHeader, 0, sizeof(containerHeader));
		if ((recv_rc = recv(sock_desc, (char*) &containerHeader,
				sizeof(containerHeader), flag)) == call_failed) {
			log("RECV containerHeader UNsuccesful. "
					"The global errno is %d.\n", errno);
			close(sock_desc);
			EXEC CICS
			RETURN;
		}
		while (containerHeader.length != 0) {
			char* dataarea = NULL;
			dataarea = (char*) malloc(containerHeader.length);
			if ((recv_rc = recv(sock_desc, dataarea, containerHeader.length,
					flag)) == call_failed) {
				log("RECV Commarea UNsuccesful "
						"The global errno is %d.\n", errno);

				close(sock_desc);

				free(dataarea);
				EXEC CICS
				RETURN;
			}
			putCICSContainer(header.channelName, containerHeader.containerName,
					dataarea, &containerHeader.length);
			free(dataarea);
			dataarea = NULL;
			/*get next container containerHeader*/
			memset((void*) &containerHeader, 0, sizeof(containerHeader));
			if ((recv_rc = recv(sock_desc, (char*) &containerHeader,
					sizeof(containerHeader), flag)) == call_failed) {
				log("RECV containerHeader UNsuccesful. "
						"The global errno is %d.\n", errno);
				close(sock_desc);
				EXEC CICS
				RETURN;
			}
		}

    }

    /******************/
    /*  CLOSE   Call  */
    /******************/

    if ((close_rc = close(sock_desc)) == call_failed) {
        log("CLOSE UNsuccesful "
                "The global errno is %d.\n", errno);
    }
    EXEC CICS
    RETURN;
}

int getHeader(Header*pHeader) {
    int length = sizeof(Header);
    EXEC CICS
    GET CONTAINER(CNTNR_CONTAINERNAME)
    CHANNEL (channelName)
    INTO (pHeader)
    FLENGTH (&length)
    NOHANDLE;

    if (dfheiptr->eibresp != 0) {
        log("Get container error,Container=%s,resp1=%d,resp2=%d.\n",
          CNTNR_CONTAINERNAME, dfheiptr->eibresp, dfheiptr->eibresp2);
        return -1;
    }
    return 0;
}

int getCommareaContent(Header* pHeader, Commarea* pComarea) {
    int dataLen8 = 8;
    int dataLen4 = 4;
    char containerName[17];
    char msg80[81] = "";
    int leng = 80; /* Length for messages         */
    int length;
    int datalength;
    int rc = 0;
    if (pHeader->dataLength > 0
            && pHeader->dataLength < pHeader->length) {
        pComarea->len = pHeader->dataLength;
    } else if(pHeader ->length > 0){
        pComarea->len = pHeader->length;
    }

    if (NULL == pComarea->pCommarea) {
        pComarea->pCommarea = (char*) malloc(pComarea->len);
    } else {
        char* commptr = (char*) realloc(pComarea->pCommarea,
                pComarea->len);
        if(commptr == NULL) {
            free(pComarea->pCommarea);
            pComarea->pCommarea = commptr;
        }
    }
    if (NULL == pComarea->pCommarea) {
        log("Memory allocation failed:"
                "Alc %d bytes,errno = %d.\n", pComarea->len, errno);
        return -1;
    } else {
        rc = getCICSContainerIntoCommarea(channelName, CNTNR_APPCOMAREA,
                pComarea->pCommarea, &pComarea->len);
        if (rc < 0) {
            if (pComarea->pCommarea != NULL ) {
                free(pComarea->pCommarea);
                pComarea->len = 0;
            }
            return rc;
        }
    }
    return 0;
}

int putHeader(const Header* pHeader) {
    int length = sizeof(Header);
    char channelNameBuffer[16];
    memset((void *) channelNameBuffer, EBCDIC_SPACE, 16);
    strncpy(channelNameBuffer, channelName, 16);
    EXEC CICS
    PUT CONTAINER(CNTNR_CONTAINERNAME)
    CHANNEL (channelNameBuffer)
    FROM (pHeader)
    FLENGTH (&length)
    NOHANDLE;
    if (dfheiptr->eibresp != 0 || dfheiptr->eibresp2 != 0) {
        log("Put container error,Container=%s,resp1=%d,resp2=%d.\n",
          CNTNR_CONTAINERNAME, dfheiptr->eibresp, dfheiptr->eibresp2);
        return -1;
    }


}

/*
 * get the ritcics listen port from TSQ
 */
int getPort() {
    if (s_port > 0) {
        return s_port;
    }
    short dataLen = 4;
    char msg80[81] = "";
    int leng = 80;
    int defalutPort = SERV_PORT;
    int port;

    EXEC CICS
    READQ TS
    QNAME (RitTSQName)
    INTO(&port)
    LENGTH(&dataLen)
    ITEM(1)
    NOHANDLE;

    if (dfheiptr->eibresp != DFHRESP(NORMAL)) {
        log("READQ TS failed, "
                "resp1=%d,resp2=%d.\n", dfheiptr->eibresp,
                dfheiptr->eibresp2);
        return defalutPort;
    }
    s_port = port;
    return port;
}

/*
 * get the ritcics bind address from TSQ
 */
int getBindAddr(char* rit_bind_addr) {
    short dataLen = RIT_MAX_BIND_ADDR_LEN;
    char msg80[81] = "";
    int leng = 80;

    EXEC CICS
    READQ TS
    QNAME (RitBindAddr)
    INTO (rit_bind_addr)
    LENGTH(&dataLen)
    ITEM(1)
    NOHANDLE;

    if (dfheiptr->eibresp != DFHRESP(NORMAL)) {
        log("READQ TS failed, "
                "resp1=%d,resp2=%d.\n", dfheiptr->eibresp,
                dfheiptr->eibresp2);
        return -1;
    }
    return 0;
}

int putCommarea(Commarea * pComarea) {
    return putCICSContainer(channelName, CNTNR_APPCOMAREA,
            pComarea->pCommarea, &pComarea->len);
}

int getCICSContainerIntoCommarea(const char* channelNameIn,
        const char* containerNameIn, void* databuffer, int* leng) {
    char containerName[17];
    char channelName[17];

    memset((void *) channelName, EBCDIC_SPACE, 17);
    strncpy(channelName, channelNameIn, 16);
    memset((void*) containerName, EBCDIC_SPACE, 17);
    strncpy(containerName, containerNameIn, 16);

    memset((void *) databuffer, EBCDIC_SPACE, *leng);
    int length =*leng;
    char* dataarea = (char*) databuffer;

    EXEC CICS
    GET CONTAINER(containerName)
    CHANNEL (channelName)
    INTO (dataarea)
    FLENGTH (&length)
    NOHANDLE;

    if (dfheiptr->eibresp != 0) {
        return -1;
    } else {
        *leng=length;
        return 0;
    }
}
int putCICSContainer(const char* channelNameIn,
        const char* containerNameIn, const void* dptr, int* leng) {
    char containerName[17];
    char channelName[17];
    memset((void *) channelName, EBCDIC_SPACE, 17);
    memset((void *) containerName, EBCDIC_SPACE, 17);

    strncpy(channelName, channelNameIn, 16);
    strncpy(containerName, containerNameIn, 16);

    EXEC CICS
    PUT CONTAINER( containerName)
    CHANNEL (channelName)
    FROM (dptr)
    FLENGTH (leng)
    NOHANDLE;
    if (dfheiptr->eibresp != 0 || dfheiptr->eibresp2 != 0) {
        log("Put container error,Container=%s,resp1=%d,resp2=%d.\n",
                containerName, dfheiptr->eibresp, dfheiptr->eibresp2);
        return -1;
    } else {
        return 0;
    }
}
