/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 *
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2019. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
#pragma runopts(POSIX(OFF),TRAP(OFF))
#pragma csect (CODE,"RITSTART")
#pragma csect (STATIC,"RITSTRTS")
 
#define _XOPEN_SOURCE 500
#ifdef  NO
#include <sys/types.h>
#include <signal.h>
#endif
 
#include <stdarg.h>
#include <stdlib.h>
#include "ritcom.h"
 
/* Map vsnprintf to external symbol.     */
#pragma map (vsnprintf, "\174\174VSNPTF")
 
/* Map snprintf to external symbol.     */
#pragma map (snprintf, "\174\174SNPRTF")
 
#define PRINTX(a) printf("%8s %8.8x\n",#a,p.##a);
#define NL_ENT_LENGTH 48
#undef  UTP
#define UTP p.
 
long processCommandQueue(MQHCONN hConn, MQHOBJ hWaitQ, Userparm *p, Exitrule unauthRules[], int *unauthCnt, int secOn);
int parseParam(Userparm * p, int argc, char** argv, int *authChk);
 
/********************************************************************
 * printHexS - Function to print a buffer in hex and character form
 ********************************************************************/
const char ascii_tab[256] = ASCII_STRING;
void printHexS(void *buff, int length, char sepchars[2]) {
    int i, j;
    unsigned char *pbuff = (unsigned char*) buff;
    long bytesleft;
    char printchar;
    for (i = 0; i < length; i += 16, pbuff += 16) {
        if ((bytesleft = length - i) >= 16)
            bytesleft = 16;
        /**********************************************************
         * First print a row of hex chars.
         **********************************************************/
        printf("%8.8X :", i);
        for (j = 0; j < bytesleft; j++) {
            if (j % 4 == 0)
                printf(" %2.2X", *(pbuff + j));
            else
                printf("%2.2X", *(pbuff + j));
        }
        /**********************************************************
         * This pads the hex display with blanks if this is the
         * last row and it's less than 16 bytes long.
         **********************************************************/
        for (j = bytesleft; j < 16; j++) {
            if (j % 4 == 0)
                printf("    ");
            else
                printf("  ");
        }
        /***********************************************************
         * Next print the characters themselves (if they're
         * printable).
         ***********************************************************/
        printf(" %c", sepchars[0]);
        for (j = 0; j < bytesleft; j++) {
            printchar = isprint(*(pbuff + j)) ? *(pbuff + j) : '.';
            printf("%c", printchar);
        }
        /**********************************************************
         * ..and pad the last row with blanks if necessary.
         **********************************************************/
        for (j = bytesleft; j < 16; j++)
            printf(" ");
        printf("%c", sepchars[1]);
        for (j = 0; j < bytesleft; j++) {
            printf("%c", ascii_tab[*(pbuff + j)]);
        }
        /**********************************************************
         * ..and pad the last row with blanks if necessary.
         **********************************************************/
        for (j = bytesleft; j < 16; j++)
            printf(" ");
        printf("%c\n", sepchars[1]);
 
    }
    return;
}
 
/*
 * console routine to print message on the MVS console
 * parameters
 * common anchor
 * message number
 * parameters passed to message, used in sprintf(...) of the message
 */
 
void CONSOLE(Userparm * p, long msgno, ...)
/* msgno is the message number to process */
{
    struct {
        short lWTO;
        char buffer[150];
    } wto;
    char * pMsg = p->pMessageModule(msgno);
    if (strlen(pMsg) > 0) {
        /* we need to process a variable number of parameters
         *  passed to messages*/
        va_list args;
        va_start(args, msgno);
        vsnprintf(&wto.buffer[0], sizeof(wto.buffer),
                p->pMessageModule(msgno),
                args);
        va_end(args);
    } else /* no message returned */
    {
        snprintf(&wto.buffer[0], sizeof(wto.buffer),
                "RIT000S Unknown message requested %d\n", msgno);
    }
    wto.lWTO = strlen(wto.buffer) - 1;/* -1 to ignore trailing null */
    /* and issue the message itself             */
    RITWTO(wto, &p->CART[0], &p->ConsoleID);
}
 
/* the next two are used within the trace macro */
/* TRACEP locates the debug flag                     */
/* FUNCTION reports the function name              */
#define TRACEP p.debugLevel
#define FUNCTION "ritstart"
 
/*
 *
 * main routine
 *
 */
 
int main(int argc, char *argv[]) {
    printf("Compiled Date %s Time %s\n", __DATE__, __TIME__);
 
    MQHOBJ hWaitQ = MQHO_NONE;
 
    MQLONG MQcc;
    MQLONG MQrc;
    MQLONG cc;
    MQLONG rc;
    MQLONG adminCmdLen;
    MQBYTE *adminCmd;
 
    char qmgr[5]; /* used during MQCONN    */
    Userparm p; /* main anchor             */
    long ruleLimit=MQNC_MAX_NAMELIST_NAME_COUNT*2+MQNC_MAX_NAMELIST_NAME_COUNT/3;
    Exitrule authRules[ruleLimit];
    Exitrule unauthRules[ruleLimit];
    int authCnt=-1;
    int unauthCnt=-1;
    char qmgrProfPfx[5];
    char qsgProfPfx[5];
    char secClasPfx[3];
    MQOD waitQueue = { MQOD_DEFAULT };
 
    MQHCONN hConn;
    long endLoop = 0;
    long doRefresh = 0;
    long lQEDIT;
    long lMQECB;
    long lCancel;
    char buffer[100];
    int authChk=1;
 
    rc = parseParam(&p, argc, argv, &authChk);
    if (rc > 0)
        return rc;
 
    memcpy(&qmgr[0], &p.QMGR[0], 4);
    qmgr[4] = 0; /* null termination */
    CONSOLE(&p, RITPARMMQ, qmgr);
    CONSOLE(&p, RITPARMTRACE, p.debugLevel);
    CONSOLE(&p, RITDIAGNOSIS, p.DiagnosisXX);
 
    /* initialise the common block                                 */
    strncpy(&p.TRACE[0], "..............................", sizeof(p.TRACE));
    strncpy(&p.Breadcrumb[0], "Start    ", sizeof(p.Breadcrumb));
#define MQCONN_RETRY  10
#define MQCONN_WAIT   5
    int connected = 0;
    for (int i = 0; i < MQCONN_RETRY; i++) {
        /* connect to MQ and open the command queue     */
        /* main line processing    */
        MQCONN(&p.QMGR[0], &hConn, &MQcc, &MQrc);
        TRACE(1, "MQCONN to %s condition code %d reason %d\n", qmgr, MQcc, MQrc);
        if (MQrc != 0) {
            CONSOLE(&p, RITMQCONNERROR, qmgr, MQcc, MQrc, RITMQRC(MQrc));
            RITSLEEP(MQCONN_WAIT);
            continue;
        } else {
            connected = 1;
            break;
        }
    }
    if(connected == 0){
        return 8;
    }
 
    /* Is this QMGR part of a QSG? If so, getQSGN will save the queue */
    /* sharing group name in userparm                                 */
    rc = getQSGN(hConn,&p);
    if (rc!=0) {
        CONSOLE(&p, RITMQQSGERR, p.QSGNAME);
        return 8;
    }
    CONSOLE(&p, RITMQQSGNAME, p.QSGNAME);
    rc = getNLSuffix(hConn,&p);
    if (rc==4) {
    	CONSOLE(&p, RITMQNOSHRQ);
    }
    else if (rc==8) {
        CONSOLE(&p, RITMQNONL);
        TRACE(1, "Error locating required name lists (rc %d)", rc);
        return 8;
    }
 
    /* What security options are in effect for the QMGR? */
    int secOn=1;
    if (authChk==1) {
        rc = getSecurityStatus(hConn,&p,qmgrProfPfx,qsgProfPfx,secClasPfx);
        if (rc>2) {
            CONSOLE(&p, RITMQDISSEC);
            return 8;
        }
        TRACE(1, "Security profile prefix (QMGR): %s.\n", qmgrProfPfx);
        TRACE(1, "Security profile prefix (QSG): %s.\n", qsgProfPfx);
        TRACE(1, "Security class prefix: %s.\n", secClasPfx);
        if ((strcmp(qmgrProfPfx,"N/A")==0)&(strcmp(qsgProfPfx,"N/A")==0)) {
            secOn=0;
            CONSOLE(&p, RITMQAUTHCHK, "disabled do to MQ switch profiles");
            TRACE(0, "Queue access authorization checking disabled due to MQ switch profiles\n");
        } else {
            CONSOLE(&p, RITMQAUTHCHK, "enabled");
            TRACE(0, "Queue access authorization checking is enabled\n");
        }
    } else {
        strcpy(qmgrProfPfx,"N/A");
        strcpy(qsgProfPfx,"N/A");
        strcpy(secClasPfx,"NA");
        secOn=0;
        CONSOLE(&p, RITMQAUTHCHK, "disabled");
    }
 
    if (1) { /* inquire MQ level from the qmgr */
        MQOD QMgrObjDesc = { MQOD_DEFAULT };
        /* QMgr Object descriptor */
        QMgrObjDesc.ObjectType = MQOT_Q_MGR;
        MQHOBJ hQMgr;
        MQOPEN(hConn, &QMgrObjDesc, MQOO_INQUIRE + MQOO_FAIL_IF_QUIESCING,
                &hQMgr, &cc, &rc);
        TRACE(1, "QM MQOPEN cc %d rc %d %s\n", cc, rc, RITMQRC(rc));
#ifdef UNITTEST
        DOUNITTEST(INQQMGR)
        cc = 8;
        rc = MQRC_NOT_AUTHORIZED;
        printf("DOUNITTEST INQQMGR\n");
        ENDUNITTEST
#endif
 
        if (cc != 0) {
            CONSOLE(&p, RITINQQMQR, cc, rc, RITMQRC(rc));
            return 8;
        }
        long commandLevel;
        MQCHAR sQmgrName[MQ_Q_MGR_NAME_LENGTH + 1] = {0};
        MQCHAR sQsgName[MQ_QSG_NAME_LENGTH + 1] = {0};
        MQLONG charLength = MQ_Q_MGR_NAME_LENGTH + 1 + MQ_QSG_NAME_LENGTH + 1 + 1;
        MQCHAR CharAttrs[MQ_Q_MGR_NAME_LENGTH + 1 + MQ_QSG_NAME_LENGTH + 1 + 1] = {0};
#define nSelectors 3
        long selectors[nSelectors] = { MQIA_COMMAND_LEVEL, MQCA_Q_MGR_NAME, MQCA_QSG_NAME };
        MQINQ(hConn, hQMgr,
        nSelectors, /* selectors */
        selectors,
        1, /* one int specified */
        &commandLevel,
        charLength,
        CharAttrs,
        &cc, &rc);
        TRACE(1, "MQINQ for commandLevel cc %d rc %d %s\n", cc, rc, RITMQRC(rc));
        TRACE(1, "Command level %d  \n", commandLevel);
        if (commandLevel < MQCMDL_LEVEL_701) {
            CONSOLE(&p, RITWRONGMQ, commandLevel);
            return 8;
        }
        strncpy(sQmgrName, CharAttrs, MQ_Q_MGR_NAME_LENGTH );
        strncpy(sQsgName, CharAttrs + MQ_Q_MGR_NAME_LENGTH, MQ_QSG_NAME_LENGTH);
 
        TRACE(1, "QMGR name: %s  \n", sQmgrName);
        TRACE(1, "QSG name: %s  \n", sQsgName);
 
    } /* inquire command level from the qmgr */
 
    strncpy(waitQueue.ObjectName, RIT_CMD_QUEUE, sizeof(waitQueue.ObjectName));
    strcat(waitQueue.ObjectName, p.nlSuffix);
 
    MQOPEN(hConn, &waitQueue, MQOO_INPUT_SHARED + MQOO_FAIL_IF_QUIESCING,
            &hWaitQ, &cc, &rc);
    TRACE(1, "MQOPEN for %s cc %d rc %d %s\n", waitQueue.ObjectName, cc, rc,
            RITMQRC(rc));
#ifdef UNITTEST
    DOUNITTEST(CMDQNA)
    cc = 8;
    rc == MQRC_NOT_AUTHORIZED;
    ENDUNITTEST
#endif
    if (cc != 0) {
        CONSOLE(&p, RITMQOPENERROR, waitQueue.ObjectName, cc, rc, RITMQRC(rc));
        return 8;
    }
 
    TRACE(1, "Before RITSASM\n");
    rc = ritsasm(&p, "S");
    if ( TRACEP > 8) {
        printHexS(&p, sizeof(Userparm), "  ");
    }
    TRACE(1, "start RC=%d trace = %32.32s breadcrumb = %8.8s\n", rc, p.TRACE,
            p.Breadcrumb);
    switch (rc) {
    /* success  so dont report any message*/
    case eOK:
        break;
        /*program name */
    case eAPF:
        CONSOLE(&p, RITAPF, argv[0]);
        return 8;
        break;
    case eGETENQ:
        CONSOLE(&p, RITENQ, argv[0]);
        break;
    case eLOAD:
        if (p.FUNCRC == 8)
            CONSOLE(&p, RITNOTFOUND, p.FUNCRC);
        else
            CONSOLE(&p, RITCSVQUERY, p.FUNCRC);
        return 8;
        break;
    case eLXRES:
    case eIEANTCR:
    case eGETDSASTORAGE:
    case eETCRE:
        /*    eCALL_FAILED equ 9 */
    case eGETPCD:
    case eIEANTRT:
        /*      break; */
        /* the following should not occur as we connected to MQ already */
 
    case eNoSubsystem:
    case eNOSUBSYS:
    case eERLY_FAIL:
    case eSCOM_FAIL:
    case eNO_RMVT:
    case eWXTOKEN0:
    case eBadGlobal:
        CONSOLE(&p, RITBADSASM, rc, p.Breadcrumb, p.FUNCRC, p.TRACE);
        return 8;
        break;
    case eETCON:
        CONSOLE(&p, RITBADETCON, rc, p.SCHED_RC0, p.SCHED_RC1, p.SCHED_RC2,
                p.SCHED_RC3);
        break;
    case eBadSwap: /* 19 */
        CONSOLE(&p, RITBADSWAP, p.FUNCRC, p.TRACE);
        break;
    case eRESMGRAdd: /* 23 */
        CONSOLE(&p, RITBADRESGGRADD, p.FUNCRC, p.TRACE);
        break;
    default:
        CONSOLE(&p, RITBADSASM, rc, "UNKNOWN", p.FUNCRC, p.TRACE);
 
    }
    if (rc > 0)
        debug(&p);
#ifdef delete
    if ( p.pGlobal -> RITFLAGS && 0x00008000 == 0x00008000)
    /* strange PC*/
 
    TRACE(1,"strange PC found %8.8x %8.8x: %8.8x\n",
            p.pGlobal -> PRH2PC,p.pGlobal -> PRH2IN,
            p.MQLXRES );
#endif
 
    if (rc != 0){
        rc = ritsasm(&p, "P");
        TRACE(1, "stop RC=%d trace = %32.32s breadcrumb = %8.8s\n", rc, p.TRACE,
                p.Breadcrumb);
        return 8;
    }
 
    CONSOLE(&p, RITMQFLEVEL, p.aModule + 8);
    TRACE(1, "Call initial refresh command\n");
    memcpy(&p.UnitTest, "          ", 8);
    rc = ritsasm(&p, "U", &p.UnitTest);
    rc = getDupRulesFromNL(authRules,&authCnt,hConn,&p);
    TRACE(1, "Return from retrieving DUP rules %d\n", rc);
    rc = getDivRulesFromNL(authRules,&authCnt,hConn,&p);
    TRACE(1, "Return from retrieving DIVERT rules %d\n", rc);
    rc = refresh(&p, hConn, unauthRules, &unauthCnt, authRules, &authCnt, qmgrProfPfx, qsgProfPfx, secClasPfx);
    TRACE(1, "Return from initial refresh command %d\n", rc);
    if (rc > 4){
        rc = ritsasm(&p, "P");
        TRACE(1, "stop RC=%d trace = %32.32s breadcrumb = %8.8s\n", rc, p.TRACE,
                p.Breadcrumb);
        return 8;
    }
    p.MQECB = 0;
    long loop = 0;
    /* clear the command queue */
    TRACE(1, "Draining the command queue\n");
    rc = processCommandQueue(hConn, hWaitQ, &p, unauthRules, &unauthCnt, secOn);
    TRACE(1, "Draining the command queue rc=%d\n", rc);
 
    /*************************************************************
     Main loop
     *************************************************************/
    for (loop = 0;; loop++) {
        doRefresh = 0;
 
        /* we wait on 3 ECBs                                                  */
        /* ecb1 is from MQGGET Signal - when message comes in      */
        /*          or MQ is terminating                                     */
        /* QEDIT ECB - when an operator stop or modify command     */
        /*          has been issued                                            */
        /* Cancel  ECB if we were cancelled                              */
        /* we own the MQ ECB, but only have a pointer to the        */
        /* qedit ECB, so need to treat them differently              */
        /*                                                                          */
        /* The ECB list has the top bit on in the last entry        */
        /* to indicate last ECB in the list                              */
        long * ECBLIST[3];
        memcpy(&ECBLIST[0], &p.QEDITECB, 4);
        ECBLIST[1] = &p.MQECB;
        ECBLIST[2] = &p.CancelECB;
        /* set high bit on to indicate end of ECB list */
        ECBLIST[2] = (long *) (0x80000000 | (long) ECBLIST[2]);
        /* now wait for console request or MQ request */
 
        TRACE(1, "Before RITWAIT MQECB %8.8x QEDIT %8.8x Cancel %8.8x\n",
                p.MQECB, *(p.QEDITECB), p.CancelECB);
 
        RITWAIT(&ECBLIST);
 
        TRACE(1, "After RITWAIT MQECB %8.8x QEDIT %8.8x Cancel %8.8x\n",
                p.MQECB, *(p.QEDITECB), p.CancelECB);
 
        /* we need to see which ( or both) ECB has been posted     */
        /* the layoutof the ECB is                                          */
        /* bit 0 is the wait bit                                             */
        /* bit 1 is the posted bit                                          */
        /* remainder is the posted reason code                          */
 
        /* check the wait bit                                                 */
        lQEDIT = *(p.QEDITECB) & POSTED; /* POSTED=0x40000000*/
        lMQECB = p.MQECB & POSTED;
        lCancel = p.CancelECB & POSTED;
 
        /* if MQ was posted                                                    */
        if ( POSTED == lCancel) {
            printf("TASK was cancelled \n");
            endLoop = 1;
 
        }
        TRACE(1, "MQECB %8.8x QEDIT %8.8x Cancel %8.8x\n", p.MQECB,
                *(p.QEDITECB), p.CancelECB);
 
        /* if MQ was posted                                                    */
        if ( POSTED == lMQECB) {
            TRACE(1, "MQECB posted %8.8x\n", p.MQECB);
            long ecbPost = p.MQECB & POSTCODE;
            switch (ecbPost) {
            /* if MQ is going down quit from loop              */
            case MQEC_CONNECTION_QUIESCING:
            case MQEC_Q_MGR_QUIESCING:
                TRACE(1, "MQ Shutdown request\n")
                ;
                endLoop = 1;
                break;
            case MQEC_MSG_ARRIVED:
                rc = processCommandQueue(hConn, hWaitQ, &p, unauthRules, &unauthCnt, secOn);
                if (rc == 0)
                    doRefresh = 1;
                else
                    endLoop = 1;/* we had a problem with the get */
                break;
            default:
                /*
                 MQEC_WAIT_INTERVAL_EXPIRED EQU 3
                 MQEC_WAIT_CANCELED EQU 4
                 */
                endLoop = 1;
                break;
            } /* switch */
#if delete
            p.MQECB = 0;
#endif
        }
        if ( POSTED == lQEDIT) {
            TRACE(1, "QEDIT posted %8.8x\n", *(p.QEDITECB));
            char * pData = &buffer[0];
            long flags;
            long rc2;
            rc2 = RITACONS(p, &flags, &buffer[0], &p.CART[0], &p.ConsoleID);
            TRACE(1, "RITACONS rc %d flags %8.8x\n", rc2, flags);
            if (rc2 != 0) {
                CONSOLE(&p, RITCMD, rc2, flags);
                endLoop = 1;
                break;
            }
 
            switch (flags) {
            case (0x04):
                TRACE(1, "Start Command:%s\n", pData)
                ;
                break;
            case (0x44):
                TRACE(1, "Operator Modify Command:%s.\n", pData)
                ;
                /* display request on console */
                CONSOLE(&p, RITUSERCMD, pData);
                long lCommand = strlen(pData);
                if (lCommand < 3)
                    CONSOLE(&p, RITBADCMD, pData);
                else if (strncmp(pData, "DIS", 3) == 0) {
                    long lData = strlen(pData);
                    /* The following are accepted */
                    /* DIS                                 */
                    /* DIS A                              */
                    /* DIS AL                             */
                    /* DIS ALL                            */
                    /* DIS E                              */
                    /* DIS ER                             */
                    /* DIS ERR                            */
                    /* DIS ERRO                          */
                    /* DIS ERROR                         */
                    /* DIS ERRORS                        */
                    if (strncmp(pData, "DIS", lData) == 0)
                        display(&p, dtUsed);
                    else if (strncmp(pData, "DIS ALL", lData) == 0)
                        display(&p, dtAll);
                    else if (strncmp(pData, "DIS ERRORS", lData) == 0)
                        display(&p, dtErrors);
                    else
                        CONSOLE(&p, RITBADDIS);
                }
#ifdef UNITTEST
                else if (memcmp(pData,"UNITTEST",8) == 0 )
                {
                    long lString = strlen(pData); /* ignore trailing ) */
                    /* 8 for UNITTEST 1 for blank 8 for value */
                    if (lString > 8+1+8) lString = 8+1+8;
                    if (lString > 8+1)
                    {
                        lString = lString - 10; /* get length of string */
                        /* l(UNITTEST) = 8, () = 2 */
                        memcpy(&p.UnitTest,"          ",8); /* set to nulls */
                        if (lString > 8) lString = 8;
                        memcpy(&p.UnitTest,&pData[9],lString);/* copy data*/
                        TRACE(1,"UNITTEST Command to %8.8s.\n",p.UnitTest);
                        rc = ritsasm(&p,"U",&p.UnitTest);
                        TRACE(1,"RITSASM U Command OK\n");
                    }
                }
 
#endif
                else if (strcmp(pData, "REFRESH") == 0) {
                    doRefresh = 1;
                    /* indicate to reset the disable */
                    p.RefreshCommand = 1;
                } else
                /* indicate we got stop */
                if (strcmp(pData, "STOP") == 0)
                    endLoop = 1;
                else if (strcmp(pData, "DEBUG") == 0) {
                    TRACE(1, "Debug trace = %32.32s breadcrumb = %8.8s\n",
                            p.TRACE, p.Breadcrumb);
 
                    debug(&p);
                } else
                    CONSOLE(&p, RITBADCMD, pData);
                break;
            case (0x40):
                TRACE(1, "Operator STOP Command:%s\n", pData)
                ;
                endLoop = 1;/* we got stop */
 
                break;
            default:
                CONSOLE(&p, RITCMD, rc2, flags);
            }
        }
        if (endLoop > 0)
            break;
        if (doRefresh > 0) {
            rc = refresh(&p, hConn, unauthRules, &unauthCnt, authRules, &authCnt, qmgrProfPfx, qsgProfPfx, secClasPfx);
            p.RefreshCommand = 0;
            if (rc > 4)
                break;/* end */
        }
 
    } /* while loop */
 
    /* reset trace buffer for shut down                        */
    strncpy(&p.TRACE[0], "..............................", sizeof(p.TRACE));
 
 
     MQCLOSE(hConn, &hWaitQ, MQCO_NONE, /* close options      */
                     &cc, &rc);
 
    TRACE(1, "Before MQDISC\n");
    MQDISC(&hConn, &MQcc, &MQrc);
    TRACE(1, "After MQDISC cc %d rc %d\n", MQcc, MQrc);
    TRACE(1, "Before shutdown\n");
    rc = ritsasm(&p, "P");
    TRACE(1, "stop RC=%d trace = %32.32s breadcrumb = %8.8s\n", rc, p.TRACE,
            p.Breadcrumb);
 
    return 0;
}
/* end of main */
 
#undef TRACEP
#define TRACEP p->debugLevel
 
int parseParam(Userparm * p, int argc, char** argv, int *authChk) {
    memset(p, '\0', sizeof(p)); /* clear it  */
    memcpy(p->userparmc, "USRP", 4);
    p->UserParmL = sizeof(Userparm);
 
#ifdef no
//          /* set the routine structure to point to the handler */
//          /* and use CEEHDLR to register the user handler        */
//    token = (_INT4)& p; /* pass this through to abend handler */
    //  routine.address = (_POINTER)&handler; /* abend hander address */
    // routine.nesting = NULL;
    //  CEEHDLR(&routine,&token,&fc);
 
    //     /* verify that CEEHDLR was successful */
    //  if ( _FBCHECK ( fc , CEE000 ) != 0 ) {
    //         printf("CEEHDLR failed with message number %d\n",
    //                  fc.tok_msgno);
    //         exit (2999);
    //     }
#endif
    /* load the message routine, and save pointer to it      */
    p->pMessageModule = (pMsgModule) fetch("HRVMMSG");
    if (p->pMessageModule == 0) {
        struct {
            short lWTO;
            char buffer[100];
        } wto;
        strncpy(&wto.buffer[0],
                "RIT001S load of message module RITMSG failed\n",
                sizeof(wto.buffer));
        wto.lWTO = strlen(wto.buffer) - 1;
        /* -1 to ignoret training null */
        RITWTO(wto, &p->CART[0]);
        perror("Load of RITMSG");
        return 8;
    }
 
    CONSOLE(p, RITPRODUCT);
 
    /* parse the arguments    */
    if (argc == 1) {
        CONSOLE(p, RITPARMNONE);
        return 8;
    }
    int rc = 0;
    /* argv:0 is the module name - so skip past this and start iParm at 1*/
    memcpy(&p->QMGR[0], "          ", 8); /* preset to blanks       */
    for (int iParm = 1; iParm < argc; iParm++) {
        char * pData = argv[iParm];
        if (memcmp(pData, "QM(", 3) == 0) {
            long lString = strlen(&pData[3]) - 1; /* ignore trailing ) */
            if (lString < 1 || lString > 4) {
                CONSOLE(p, RITPARMBADQM);
                if (rc < 8)
                    rc = 8;
            } else
                memcpy(&p->QMGR[0], &pData[3], lString);
        }
#ifdef UNITTEST
        else if (memcmp(pData,"UNITTEST",8) == 0 )
        {
            /* UNITTEST(XXXX) so point to the xxx */
            long lString = strlen(&pData[9])-1; /* ignore trailing ) */
            TRACE(1,"Doing Unittest %s. lString %d\n",pData,lString);
            if (lString > 0 && lString <=8)
            {
                memcpy(&p->UnitTest,"          ",8); /* set to nulls */
                memcpy(&p->UnitTest,&pData[9],lString); /* copy data*/
                p->UnitTest[lString] = 0; /* null terminator */
                TRACE(1,"UNITTEST set to %s.\n",p->UnitTest);
                /* update common storage */
                rc = ritsasm(&p,"U",&p->UnitTest);
                TRACE(1,"RITSASM U OK\n");
            }
        }
 
#endif
 
        else if (memcmp(pData, "TRACE(", 6) == 0) {
            long lString = strlen(&pData[6]) - 1; /* ignore trailing ) */
            if (lString != 1) {
                CONSOLE(p, RITPARMBADTRACE);
                if (rc < 4)
                    rc = 4;
            }
            if (pData[6] < '0' || pData[6] > '9') {
                CONSOLE(p, RITPARMBADTRACE);
                if (rc < 4)
                    rc = 4;
            } else {
                p->debugLevel = atol(&pData[6]);
            }
        }
 
        else if (memcmp(pData, "AUTHCHK(NO)", 11) == 0) {
            *authChk=0;
        }
 
        else {
            CONSOLE(p, RITPARMUNKNOWN, pData);
            if (rc < 8)
                rc = 8;
        }
    }
    if (rc == 0 && p->QMGR[0] == 0) /* was not specified */
    {
        CONSOLE(p, RITPARMBADQM);
        if (rc < 8) {
            rc = 8;
        }
        return rc;
    }
    if(rc == 0){
    /* Get the debug flag set in environment */
        char* sDiag = getenv(RIT_DIAGNOSIS);
        if(sDiag != NULL){
            long nDiag = atoi(sDiag);
            if(nDiag > 0){
                p->DiagnosisXX = 1;
            }else{
                p->DiagnosisXX = 0;
            }
        }else{
            p->DiagnosisXX = 0;
        }
    }
    return rc;
}
/*
 ***********************************************************
 *  processCommandQueue
 ***********************************************************
 * we do a get from the command queue queue -
 * and specify signal so we can wait on an ECB
 * if there are no more messages
 * if queue manager is shutting
 * down we get notified - and so post the main task
 */
long processCommandQueue(MQHCONN hConn, MQHOBJ hWaitQ, Userparm * p, Exitrule unauthRules[], int *unauthCnt, int secOn) {
    MQMD md = { MQMD_DEFAULT }; /* Message Descriptor                */
    MQGMO gmo = { MQGMO_DEFAULT }; /* get message options              */
    MQLONG cc;
    MQLONG rc;
    long ruleLimit=MQNC_MAX_NAMELIST_NAME_COUNT*2+MQNC_MAX_NAMELIST_NAME_COUNT/3;
    long bufLen=ruleLimit*(10+3*(NL_ENT_LENGTH+1)); /* 3 entries plus a 10 byte rule
                                                   type for each rule */
    char buffer[bufLen];
    char waitQueueName[MQ_Q_NAME_LENGTH+1];
    long lBuffer = sizeof(buffer);
    long msgCount = 0;
    long lengthReturnedMessage = 0;
    int  ruleTypeLen=9;
    char ruleType[ruleTypeLen+1];
    char inQueue[MQ_Q_NAME_LENGTH+1];
    char outQueue[MQ_Q_NAME_LENGTH+1];
    char ruleQmgr[MQ_Q_MGR_NAME_LENGTH+1];
    char * pMsgField;
    const char blnk = ' ';
    char * lastBlnk;
    int fieldsCnt=0;
 
    gmo.Options = MQGMO_SET_SIGNAL + MQGMO_FAIL_IF_QUIESCING
    + MQGMO_NO_SYNCPOINT + MQGMO_ACCEPT_TRUNCATED_MSG + MQGMO_CONVERT;
    gmo.Signal1 = &p->MQECB;
    p->MQECB = 0; /* preset this */
 
    gmo.WaitInterval = MQWI_UNLIMITED;
    long error = 0;
 
    long leaveGetLoop = 0;
    strcpy(waitQueueName,RIT_CMD_QUEUE);
    strcat(waitQueueName,p->nlSuffix);
 
    for (msgCount = 0;; msgCount++) {
        /* always clear msgid, correlid, and contents of message */
        memcpy(md.MsgId, MQMI_NONE, sizeof(md.MsgId));
        memcpy(md.CorrelId, MQCI_NONE, sizeof(md.CorrelId));
        memset(buffer, '\0', sizeof(buffer)); /* clear it  */
        memset(ruleType, '\0', sizeof(ruleType)); /* clear it  */
        memset(inQueue, '\0', sizeof(inQueue)); /* clear it  */
        memset(outQueue, '\0', sizeof(outQueue)); /* clear it  */
        memset(ruleQmgr, '\0', sizeof(ruleQmgr)); /* clear it  */
 
        MQGET(hConn, hWaitQ, &md, &gmo, lBuffer, buffer, &lengthReturnedMessage,
                &cc, &rc);
 
        TRACE(1, "MQGET from %s cc %d rc %d %s\n", waitQueueName, cc, rc,
                RITMQRC(rc));
        switch (rc) {
        case MQRC_NO_MSG_AVAILABLE:
            /* we should not get this as we have signal */
            leaveGetLoop = 1;
            break;
        case MQRC_TRUNCATED_MSG_ACCEPTED:
        case MQRC_TRUNCATED_MSG_FAILED:
        case MQRC_NONE:
            /* if security is enabled, parse message data into fields */
            if (secOn==1) {
                TRACE(1,"%d byte message received from command queue: \n%s\n",lengthReturnedMessage,buffer);
                if (lengthReturnedMessage>10) {
                    /* First parse message into fields */
                    pMsgField=strtok(buffer,",");
                    if (pMsgField!=NULL) {
                        ++fieldsCnt;
                        strncpy(ruleType,pMsgField,ruleTypeLen);
                        ruleType[ruleTypeLen]='\0';
                    }
                    pMsgField=strtok(NULL,",");
                    if (pMsgField!=NULL) {
                        ++fieldsCnt;
                        strncpy(inQueue,pMsgField,MQ_Q_NAME_LENGTH);
                        inQueue[MQ_Q_NAME_LENGTH]='\0';
                    }
                    pMsgField=strtok(NULL,",");
                    if (pMsgField!=NULL) {
                        ++fieldsCnt;
                        strncpy(outQueue,pMsgField,MQ_Q_NAME_LENGTH);
                        outQueue[MQ_Q_NAME_LENGTH]='\0';
                    }
                    pMsgField=strtok(NULL,",");
                    if (pMsgField!=NULL) {
                        ++fieldsCnt;
                        strncpy(ruleQmgr,pMsgField,MQ_Q_MGR_NAME_LENGTH);
                        ruleQmgr[MQ_Q_MGR_NAME_LENGTH]='\0';
                    }
                    /* Then copy to unauthRules array */
                    if (*unauthCnt<49) {
                        (*unauthCnt)++;
                        strncpy(unauthRules[*unauthCnt].ruleType,ruleType,ruleTypeLen);
                        unauthRules[*unauthCnt].ruleType[ruleTypeLen]='\0';
                        strncpy(unauthRules[*unauthCnt].inQueue,inQueue,MQ_Q_NAME_LENGTH);
                        unauthRules[*unauthCnt].inQueue[MQ_Q_NAME_LENGTH]='\0';
                        strncpy(unauthRules[*unauthCnt].outQueue,outQueue,MQ_Q_NAME_LENGTH);
                        unauthRules[*unauthCnt].outQueue[MQ_Q_NAME_LENGTH]='\0';
                        strncpy(unauthRules[*unauthCnt].ruleQmgr,ruleQmgr,MQ_Q_MGR_NAME_LENGTH);
                        unauthRules[*unauthCnt].ruleQmgr[MQ_Q_MGR_NAME_LENGTH]='\0';
                        strncpy(unauthRules[*unauthCnt].userId,md.UserIdentifier,MQ_USER_ID_LENGTH);
                        unauthRules[*unauthCnt].userId[MQ_USER_ID_LENGTH]='\0';
                        strncpy(unauthRules[*unauthCnt].msgDate,md.PutDate,8);
                        unauthRules[*unauthCnt].msgDate[8]='\0';
                        strncpy(unauthRules[*unauthCnt].msgTime,md.PutTime,8);
                        unauthRules[*unauthCnt].msgTime[8]='\0';
                    } else {
                        TRACE(0,"Maximum number of rules reached. Ignoring rule\n");
                    }
                /* Regadless of whether the message contained exactly */
                /* 4 fields, let the process continue.                */
                }
                TRACE(1,"ruleType...: %s\n",unauthRules[*unauthCnt].ruleType);
                TRACE(1,"inQueue....: %s\n",unauthRules[*unauthCnt].inQueue);
                TRACE(1,"outQueue...: %s\n",unauthRules[*unauthCnt].outQueue);
                TRACE(1,"ruleQmgr...: %s\n",unauthRules[*unauthCnt].ruleQmgr);
                TRACE(1,"userId.....: %s\n",unauthRules[*unauthCnt].userId);
                TRACE(1,"msgDate....: %s\n",unauthRules[*unauthCnt].msgDate);
                TRACE(1,"msgTime....: %s\n",unauthRules[*unauthCnt].msgTime);
            }
            break;
        case MQRC_SIGNAL_REQUEST_ACCEPTED:
            /* no messages left so we need to exit until the ECB is posted */
            leaveGetLoop = 1;
            break;
        default:
            CONSOLE(p, RITMQGETERROR, waitQueueName, cc, rc, RITMQRC(rc));
            error = 1;
            leaveGetLoop = 1;
        }
        if (leaveGetLoop > 0)
            break;
    } /* for */
    TRACE(1, "%d messages drained\n", msgCount);
 
    return error;
}
