#pragma csect (CODE,"HRVMCREF")
#pragma csect (STATIC,"HRVMCRES")
/***********************************************************************
* Licensed Materials - Property of IBM and/or HCL
* (c) Copyright IBM Corporation 2001, 2016. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2019. All Rights Reserved.
*
* Note to U.S. Government Users Restricted Rights:
* Use, duplication or disclosure restricted by GSA ADP Schedule
* Contract with IBM Corp.
***********************************************************************/
 
/* Map snprintf to external symbol.     */
#pragma map (snprintf, "\174\174SNPRTF")
 
#include "ritcom.h"
#include "ctype.h"
 
#define TRACEP p->debugLevel
#define FUNCTION "refresh"
#define NL_ENT_LENGTH 48
#define ATTR_READ      2
#define ATTR_UPDATE    4
#define ATTR_CONTROL   8
#define ATTR_ALTER   128
 
#define nNLSelectors   4
#define nSelectors2    2
 
#define DUP 0
#define DIVERT 1
#define FREE(a) if(a){free(a);a=NULL;}
 
long inqDivertNL(char *, QArea *, MQHCONN hConn, Userparm * p);
 
long sendAdminCmd(MQLONG , MQBYTE * , MQHCONN hConn, Userparm * p, MQLONG, MQBYTE *, int);
 
long getQSGN(MQHCONN hConn, Userparm * p);
 
long getSecurityStatus(MQHCONN hConn, Userparm * p,char qmgrProfPfx[],char qsgProfPfx[],char secClasPfx[]);
 
long getNLSuffix(MQHCONN hConn, Userparm * p);
 
long delNamelist(char* pNamelist, MQHCONN hConn, Userparm * p);
 
long replNamelist(int, MQBYTE*, char* pNamelist, MQHCONN hConn, Userparm * p);
 
long saveDupRulesToNL(Exitrule authRules[], int *authCnt, MQHCONN hConn, Userparm * p);
 
long saveDivRulesToNL(Exitrule authRules[], int *authCnt, MQHCONN hConn, Userparm * p);
 
long getDupRulesFromNL(Exitrule authRules[], int *authCnt, MQHCONN hConn, Userparm * p);
 
long getDivRulesFromNL(Exitrule authRules[], int *authCnt, MQHCONN hConn, Userparm * p);
 
long duplicat(Userparm * p, MQHCONN hConn,Exitrule unauthRules[],int *unauthCnt,Exitrule authRules[],int *authCnt,
    char qmgrProfPfx[],char qsgProfPfx[],char secClasPfx[]);
 
long divertrf(Userparm * p, MQHCONN hConn,Exitrule unauthRules[],int *unauthCnt,Exitrule authRules[],int *authCnt,
    char qmgrProfPfx[],char qsgProfPfx[],char secClasPfx[]);
 
int  verifyAuth(short userIdLen,char userId[],short classLen,char class[],short entityLen,char entity[],short attr,
    char qmgrProfPfx[],char qsgProfPfx[],char secClasPfx[],Userparm * p);
 
long removeRule(Exitrule ruleArray[], int *ruleCnt, char compStr[]);
 
const char * UC_NL_RIT[] = { RIT_DUP_NL, RIT_DIVERT_NL };
const char * LC_NL_RIT[] = { RIT_DUP_NL_LC, RIT_DIVERT_NL_2 };
 
char* trimTailBlank(char* str) {
    int len = strlen(str);
    for (int i = 0; i < len; i++) {
        if (str[i] == ' ') {
            str[i] = '\0';
            break;
        }
    }
    return str;
}
 
char* trimBlank(char* str){
    int len = strlen(str);
    int i = 0;
    for (; i < len; i++) {
        if (str[i] != ' ') {
            break;
        }
    }
    if(i == 0){
        return trimTailBlank(str);
    } else {
        strncpy(str, str + i, len - i);
        str[len - i] = 0;
        return trimTailBlank(str);
    }
}
 
long duplicat(Userparm * p, MQHCONN hConn,Exitrule unauthRules[],int *unauthCnt,Exitrule authRules[],int *authCnt,
    char qmgrProfPfx[],char qsgProfPfx[],char secClasPfx[]) {
    /* const char * pNLName;  pointer to the name list */
    char pNLName[44];
    long haveError = 0;
    QArea * pEntry; /* pEntry is a queue triples    */
    short int holdQNLen;
    unsigned char holdInQ[MQ_Q_NAME_LENGTH+1];
    unsigned char holdOutQ[MQ_Q_NAME_LENGTH+1];
    unsigned char holdQmgr[MQ_Q_MGR_NAME_LENGTH+1];
    MQLONG cc;
    MQLONG rc;
    long count = 0;
 
    long selectors[nNLSelectors] = {
    MQCA_ALTERATION_DATE,
    MQCA_ALTERATION_TIME,
    MQIA_NAME_COUNT,
    MQCA_NAMES };
 
    int compLen=3*NL_ENT_LENGTH;
    char compUnauth[compLen+1];
    char compAuth[compLen+1];
    int foundUnauthRule=0;
    int foundAuthRule=0;
    int foundDupRule=0;
    char userId[MQ_USER_ID_LENGTH+1];
    char userIdNlEnt[NL_ENT_LENGTH+1];
    short userIdLen;
    short classLen;
    char class[8];
    short entityLen;
    char entity[54];
    short attr;
    int ignoreRule=0;
    int authIdx=0;
    int tempCnt=0;
    int unauthIdx=0;
    int inQueueRc=8;
    int outQueueRc=8;
    char* blankLoc;
    char * pOutQueue;
    const char blnk=' ';
    char authNames[MQNC_MAX_NAMELIST_NAME_COUNT*(2+NL_ENT_LENGTH)+1];
    int secOn=1;
    long ruleLimit=MQNC_MAX_NAMELIST_NAME_COUNT*2+MQNC_MAX_NAMELIST_NAME_COUNT/3;
 
    if ((strcmp(qmgrProfPfx,"N/A")==0) & (strcmp(qsgProfPfx,"N/A")==0)) secOn=0;
 
    TRACE(9, "List of new rules prior to duplicate processing:\n");
    for (int i=0; i<=*unauthCnt; ++i) {
        /* pad with blanks up to length of name list entry (48 bytes) */
        snprintf(compUnauth,sizeof(compUnauth),"%-48s%-48s%-48s",unauthRules[i].inQueue,unauthRules[i].outQueue,
            unauthRules[i].ruleQmgr);
        TRACE(1, "Rule (%i bytes):\n",strlen(compUnauth));
        TRACE(1, "%s\n",compUnauth);
    }
 
    TRACE(9, "List of existing rules prior to duplicate processing:\n");
    for (int i=0; i<=*authCnt; ++i) {
        /* pad with blanks up to length of name list entry (48 bytes) */
        snprintf(compAuth,sizeof(compAuth),"%-48s%-48s%-48s",authRules[i].inQueue,authRules[i].outQueue,
            authRules[i].ruleQmgr);
        TRACE(1, "Rule Type:\n",authRules[i].ruleType);
        TRACE(1, "Rule (%i bytes):\n",strlen(compAuth));
        TRACE(1, "%s\n",compAuth);
    }
 
    /* we go round the copy queue and the replace queue, so have two to do */
    /* if we have not opened the name list try now */
    /* there may have been problems with it, such as security */
    /* so there can be several attempts before this is successful */
    /* original code had lower case namelist. Which caused problems */
    /* when trying to protect it as it required lower case security */
    /* We try with upper case name, and if that gives not found     */
    /* we try with the lower case name                                */
    /* pNLName = UC_NL_RIT[DUP]; */
    strcpy(pNLName,UC_NL_RIT[DUP]);
    strcat(pNLName,p->nlSuffix);
    MQOD odNamelist = { MQOD_DEFAULT };
    strncpy(odNamelist.ObjectName, pNLName, sizeof(odNamelist.ObjectName));
    odNamelist.ObjectType = MQOT_NAMELIST;
    if (p->hNameList[DUP] == 0) {
        MQOPEN(hConn, &odNamelist, MQOO_INQUIRE + MQOO_FAIL_IF_QUIESCING,
                 &p->hNameList[DUP], &cc, &rc);
        TRACE(1, "MQOPEN for namelist %s cc %d rc %d %s\n", pNLName, cc, rc,
                 RITMQRC(rc));
        if (rc == MQRC_UNKNOWN_OBJECT_NAME) {
            strcpy(pNLName,LC_NL_RIT[DUP]);
            strcat(pNLName,p->nlSuffix);
            for (int i=0; pNLName[i]; i++) {
                pNLName[i]=tolower(pNLName[i]);
            }
            strncpy(odNamelist.ObjectName, pNLName,
                     sizeof(odNamelist.ObjectName));
             MQOPEN(hConn, &odNamelist, MQOO_INQUIRE + MQOO_FAIL_IF_QUIESCING,
                     &p->hNameList[DUP], &cc, &rc);
             TRACE(1, "MQOPEN for namelist %s cc %d rc %d %s\n", pNLName, cc, rc,
                     RITMQRC(rc));
             /* if this lower case name is not found either */
             /* then use upper case name in messages        */
             if (rc == MQRC_UNKNOWN_OBJECT_NAME) {
                 /*  pNLName = UC_NL_RIT[DUP]; */
                     strcpy(pNLName,UC_NL_RIT[DUP]);
                     strcat(pNLName,p->nlSuffix);
             }
        }
#ifdef UNITTEST
        DOUNITTEST(NONL)
        cc = 8;
        rc = MQRC_UNKNOWN_OBJECT_NAME;
        printf("DOUNITTEST NONL\n") ;
        ENDUNITTEST
        DOUNITTEST(NLNA)
        cc = 8;
        rc = MQRC_NOT_AUTHORIZED;
        printf("DOUNITTEST NLNA\n");
        ENDUNITTEST
#endif
        if (cc != 0) {
             CONSOLE(p, RITREFOPEN, pNLName, cc, rc, RITMQRC(rc));
             if (rc == MQRC_UNKNOWN_OBJECT_NAME)
                 return 4; /* continue processing divert rules */
             else
                 return 8; /* stop processing divert rules */
        }
    }
    p->inqSize[DUP] = 1;
    p->lInqStorage[DUP] = MQ_DATE_LENGTH + MQ_TIME_LENGTH
             + p->inqSize[DUP] * lMQCHAR48;
    FREE(p->pInqStorage[DUP]);
    p->pInqStorage[DUP] = (char *) malloc(p->lInqStorage[DUP]);
    if (p->pInqStorage[DUP] == 0) {
        printf("p->pInqStorage non found \n");
    }
    for (int iLoop = 0; iLoop < 10; iLoop++) {
        MQINQ(hConn, p->hNameList[DUP], nNLSelectors, /* selectors */
        selectors, 1, /* one int specified */
        &count, p->lInqStorage[DUP], p->pInqStorage[DUP], &cc, &rc);
        TRACE(1, "MQINQ for Namelist %s cc %d rc %d %s\n", pNLName, cc, rc,
                 RITMQRC(rc));
 
#ifdef UNITTEST
        DOUNITTEST(INQ0)
        count = 0;
        TRACE(1, "DOUNITTEST INQ0\n");
        ENDUNITTEST
#endif
        if (rc == 0)
             break;
        else if (rc == MQRC_CHAR_ATTRS_TOO_SHORT) {
             TRACE(1,
                     "cref: count > inqsize - so reallocate count %d old count %d \n",
                     count, p->inqSize[DUP]);
             p->inqSize[DUP] = count;
             FREE(p->pInqStorage[DUP]);
             p->lInqStorage[DUP] = MQ_DATE_LENGTH + MQ_TIME_LENGTH
                     + p->inqSize[DUP] * lMQCHAR48;
             p->pInqStorage[DUP] = (char *) malloc(p->lInqStorage[DUP]);
             if (p->pInqStorage[DUP] == 0) {
                 TRACE(0, "unable to allocate storage for p->lInqStorage[DUP]\n");
                 return 8;
             }
        } else if (rc == MQRC_HOBJ_ERROR) {
             MQOPEN(hConn, &odNamelist, MQOO_INQUIRE + MQOO_FAIL_IF_QUIESCING,
                              &p->hNameList[DUP], &cc, &rc);
             TRACE(1, "MQOPEN for namelist %s cc %d rc %d %s\n", pNLName, cc, rc,
                     RITMQRC(rc));
             if (rc == MQRC_UNKNOWN_OBJECT_NAME) {
                 strcpy(pNLName,LC_NL_RIT[DUP]);
                 strcat(pNLName,p->nlSuffix);
                 for (int i=0; pNLName[i]; i++) {
                     pNLName[i]=tolower(pNLName[i]);
                 }
                 strncpy(odNamelist.ObjectName, pNLName,
                          sizeof(odNamelist.ObjectName));
                 MQOPEN(hConn, &odNamelist, MQOO_INQUIRE + MQOO_FAIL_IF_QUIESCING,
                          &p->hNameList[DUP], &cc, &rc);
                 TRACE(1, "MQOPEN for namelist %s cc %d rc %d %s\n", pNLName, cc, rc,
                          RITMQRC(rc));
                 /* if this lower case name is not found either */
                 /* then use upper case name in messages        */
                 if (rc == MQRC_UNKNOWN_OBJECT_NAME) {
                     /* pNLName = UC_NL_RIT[DUP]; */
                     strcpy(pNLName,UC_NL_RIT[DUP]);
                     strcat(pNLName,p->nlSuffix);
                 }
             }
             if (cc != 0) {
                 CONSOLE(p, RITREFOPEN, pNLName, cc, rc, RITMQRC(rc));
                 FREE(p->pInqStorage[DUP]);
                 if (rc == MQRC_UNKNOWN_OBJECT_NAME)
                     return 4; /* continue processing divert rules */
                 else
                     return 8; /* stop processing divert rules*/
             }
        } else {
            FREE(p->pInqStorage[DUP]);
            CONSOLE(p, RITREFINQ, pNLName, cc, rc, RITMQRC(rc));
            return 8;
        }
    } /* for loop */
#ifdef delete
    if ( count == 0)
    {
        TRACE(1,"Count of elements for Namelist %s is zero\n", pNLName);
        CONSOLE(p,RITREFINQNO, pNLName); /* warning: count is zero */
        return 4;
    }
#endif
    long remainder;
    remainder = count % 3; /* integer remainer */
    if (remainder != 0) {
        FREE(p->pInqStorage[DUP]);
        TRACE(1, "Number of elements  not multiple of 3: %d\n", count);
        CONSOLE(p, RITREFBADNUM, pNLName, count); /*invalid count */
        return 4;
    }
 
    long entries = count / 3;
    int nEntryNum = 0;
    /* point past the date and time */
    char * pData = p->pInqStorage[DUP] + MQ_DATE_LENGTH + MQ_TIME_LENGTH;
    char * pData2 = pData;
    char * pNamelist = pData;
    char * pTime = p->pInqStorage[DUP] + MQ_DATE_LENGTH;
    TRACE(1, "Namelist changed on %10.10s at %8.8s\n", p->pInqStorage[DUP],
             pTime);
 
    QArea * pEntries = NULL;
    long lEntry = sizeof(QArea);
    char* pDupNamelist = NULL;
    if (entries == 0) {
        pEntries = 0; /* we have no entries */
 
        TRACE(1, "before ritrefr count %d  length %d address %8.8x\n",
            nEntryNum, lEntry, pEntries);
        rc = ritrefr(p, nEntryNum, lEntry, pEntries, DUP);
        /* which element to store it in */
        TRACE(1, "after ritrefr %d\n", rc);
        if (rc == 0) {
            CONSOLE(p, RITREFOKDT, "duplicate", p->pInqStorage[DUP], pTime);
            TRACE(1, "Namelist %s date %10.10s time %8.8s\n", pNLName,
                     p->pInqStorage[DUP], pTime);
        } else {
        	if (rc == 16) {
                CONSOLE(p, RITREFBADQA, "duplicate", rc);
        	} else {
                CONSOLE(p, RITREFONOTDT, "duplicate", rc);
        	}
        }
        if(nEntryNum < entries){
            TRACE(1,"About to do replNamelist\n");
            rc = replNamelist(nEntryNum * 3, pDupNamelist,
                     pNLName, hConn, p);
            if(rc == 0){
                 TRACE(1, "Replace duplication namelist successfully.\n");
            }else{
                 TRACE(1, "Replace duplication namelist failed.\n");
            }
        }
        if (secOn==1) {
            /* Since there are no entries in the recording name list,
            remove each auth rule with ruletype duplicate, and save
            auth rules to name list.                            */
            TRACE(1,"Removing DUP auth rules\n");
            for (int i=0; i<=*authCnt; ++i) {
                TRACE(1,"Rule type is %s\n",authRules[i].ruleType);
                if (strncmp(authRules[i].ruleType,"DUPLICATE",9)==0) {
                    /* pad with blanks up to length of name list entry (48 bytes) */
                    snprintf(compAuth,sizeof(compAuth),"%-48s%-48s%-48s",authRules[i].inQueue,authRules[i].outQueue,
                        authRules[i].ruleQmgr);
                    TRACE(1,"Removing rule\n");
                    rc=removeRule(authRules,authCnt,compAuth);
                    /* when the rule is removed, authCnt is decremented,
                    so the next rule will have the same index as the
                    one that was removed.                            */
                    if (rc==0) --i;
                }
            }
            TRACE(1,"Saving %i rules to NL\n",*authCnt);
            saveDupRulesToNL(authRules,authCnt,hConn,p);
        }
        FREE(pEntries);
        FREE(p->pInqStorage[DUP]);
        return 0;
    }
    /* get enough storage of all of our 48 byte entries    */
    pEntries = (QArea *) malloc(entries * lEntry);
    if (pEntries == NULL) {
        FREE(p->pInqStorage[DUP]);
        TRACE(0, "unable to allocate storage for pEntries\n");
        return 8;
    }
    pEntry = pEntries; /* point to the first entry     */
    memset(pEntries, 0, entries * lEntry); /* and clear    */
    pDupNamelist = (char*)malloc(count * NL_ENT_LENGTH);
    if (pDupNamelist == NULL) {
        FREE(p->pInqStorage[DUP]);
        FREE(pEntries);
        TRACE(0, "unable to allocate storage for pDupNameList\n");
        return 8;
    }
    memset(pDupNamelist, 0, count * NL_ENT_LENGTH);
 
    char* pCurrNamelist = pDupNamelist;
 
    if (secOn==1) {
        /* reset inDupNL flag within authRules */
        TRACE(1,"About to initialize inDupNL\n");
        for (int i=0; i<=*authCnt; ++i) {
            authRules[i].inDupNL=0;
        }
    }
 
    /* loop through rules in name list */
    /* pEntry    - entry in list of queues to be refreshed. Passed */
    /*             to assembly language refresh routine.           */
    /* pNamelist - pointer used to bump through "triplets"         */
    /* pData     - pointer used to bump through names              */
    /* hold????  - used to temporarily hold the values from the    */
    /*             namelist until it can be confirmed that the     */
    /*             values should be copied to pEntry.              */
    for (long iEntry = 0; iEntry < entries; iEntry++) { /* number of triplets */
        ignoreRule=0;
        memset(userId, '\0', sizeof(userId)); /* clear it  */
        memset(entity, '\0', sizeof(entity)); /* clear it  */
        memset(holdInQ, '\0', sizeof(holdInQ)); /* clear it  */
        memset(holdOutQ, '\0', sizeof(holdOutQ)); /* clear it  */
        memset(holdQmgr, '\0', sizeof(holdQmgr)); /* clear it  */
 
        if (secOn==1) {
            /* First determine if this rule is already in the list
               of authorized rules.                                */
            foundAuthRule=0;
            for (int i=0; i<=*authCnt; ++i) {
                /* pad with blanks up to length of name list entry (48 bytes) */
                snprintf(compAuth,sizeof(compAuth),"%-48s%-48s%-48s",authRules[i].inQueue,authRules[i].outQueue,
                    authRules[i].ruleQmgr);
                TRACE(1,"Does the name list rule match this auth rule?:\n");
                TRACE(1,"%s\n",compAuth);
                if (strncmp(compAuth,pData,compLen)==0) {
                    foundAuthRule=1;
                    authRules[i].inDupNL=1;
                    authIdx=i;
                    sprintf(userId,"%s",authRules[i].userId);
                    TRACE(1,"Auth rule exists for name list rule:\n");
                    break;
                }
            }
 
            /* If not already in list of authorized rules, and if
               ther are already the max number of authRules, ignore this one. */
            if (*authCnt>=ruleLimit && foundAuthRule==0) {
                ignoreRule=1;
                TRACE(1, "Only %d rules are supported. Ignoring rule.\n",ruleLimit);
            }
 
            /* If rule was not already in list of authorized rules,
               loop through "unauthenticated rules" received as part of
               COM.GREENHAT.INTERCEPT message. If a match is found, get
               the user id. If no match is found, then this rule is
               invalid and should be removed from the list.          */
            if (foundAuthRule==0) {
                foundUnauthRule=0;
                for (int i=0; i<=*unauthCnt; ++i) {
                    /* pad with blanks up to length of name list entry (48 bytes) */
                    snprintf(compUnauth,sizeof(compUnauth),"%-48s%-48s%-48s",unauthRules[i].inQueue,
                        unauthRules[i].outQueue,unauthRules[i].ruleQmgr);
                    TRACE(1, "NL rule (%i bytes):\n",strlen(pData));
                    TRACE(1, "%s\n",pData);
                    TRACE(1, "Msg rule (%i bytes):\n",strlen(compUnauth));
                    TRACE(1, "%s\n",compUnauth);
                    if (strncmp(compUnauth,pData,compLen)==0) {
                        /* This name list rule matches a rule from the RIT
                        command queue. Save the userId for use later. */
                        foundUnauthRule=1;
                        sprintf(userId,"%s",unauthRules[i].userId);
                        unauthIdx=i;
                        break;
                    }
                }
            }
 
            /* If rule is not in either authRules or unAuthRules
               it should be ignored. */
            if (foundAuthRule==0 && foundUnauthRule==0) {
                ignoreRule=1;
                TRACE(1, "Rule not found in either rule list. Ignoring rule.\n");
            }
        } /* end if secon==1 */
 
        /*check it we have generic processing to do  */
        pData2 = pData; /* point to the current entry    */
        pNamelist = pData;
        /* we increment pData2 as we process the chars  */
        /* generic string - or base64 sting begins with %                */
        TRACE(1, "Queue name %s.\n", pData2);
        if (memcmp(pData2, "% ", 2) == 0)/* all queues */
        {
             holdQNLen = 0;
             memset(&holdInQ[0], ' ', MQ_Q_NAME_LENGTH); /* preset to blanks and overlay it */
             memcpy(&holdInQ[0], "*", 1); /* move the * into the front        */
             memset(entity, '\0', sizeof(entity)); /* clear it  */
             strcpy(entity,".COM.GREENHAT.ALLOW.GENERIC.QNAMES");
             TRACE(1, "Generic entity: %s\n", entity);
        } else if (*pData2 == '%') { /* Need to decode and extract any * */
             TRACE(1, "generic2 %s\n", pData2);
 
             /* allocate 48+1 temp string. +1 for a Null terminator*/
             pData2 += 1; /* past the % */
             char pattern[MQ_Q_NAME_LENGTH];
             memcpy(&pattern[0], pData2 + 1, MQ_Q_NAME_LENGTH - 1);
             pattern[MQ_Q_NAME_LENGTH - 1] = 0; /* last char to null    */
             int iChar = 0;
             for (iChar = 0; iChar < NL_ENT_LENGTH; iChar++)/* scan the string */
             {
                 /* Base64 is used to get the number equivilent so A becomes 0 and / comes  63 */
                 static const char * Base64 =
                          "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789./";
                 if (*pData2 == ' ')
                     break; /* cant have blank so end of string     */
                 if (*pData2 == 0)
                     break; /* in case we hit the end                */
                 if (*pData2 == '_') /* padding value                          */
                 {
                     pattern[iChar] = 0; /* indicate it was a padding char        */
                     /* you can have up to 2 padding chars    */
                 } else /* need to do a look up                  */
                 {
                     char * q;
                     /* locate the character in the list  so A becomes 0, B becomes 1 etc */
                     /* the strchr function returns a pointer to the character             */
                     /* so we need to calculate the offset from the start                  */
                     q = strchr(Base64, *pData2);
                     if (q == NULL) /*not found */
                     {
                          TRACE(1,
                                  "base 64 invalid char %c (%2.2xx) in string %s %d\n",
                                  *pData2, *pData2, pData, iChar);
                          CONSOLE(p, RITBADBASE64, pData2, pData); /*invalid count */
                          haveError = 1;
                          break;
                     }
                     /* calculate the offset to give us our value                            */
                     pattern[iChar] = q - Base64; /* 0 for A, 1 for B... up to 63           */
                 }
                 pData2++; /* next character                                          */
             }
             pattern[iChar] = 0; /* we need at least one to indicate end          */
             pattern[iChar + 1] = 0; /* up to 2 trailing nulls for the decode        */
             long lPattern = strlen(&pattern[0]); /* calculate length of the string*/
             long outPos = 0;
             char regex[64];
             long decodedLength;
             for (iChar = 0; iChar < lPattern; iChar += 4) {
                 /* the original is usual way of doing it                            */
                 /* the other way is clearer                                          */
                 /* we need to convert4 chars to 3 chars                             */
                 /* so we take ..123456,..78abcd,..efgh12,..345678                  */
                 /* ignore the ..  and take 1-8 of each 3 groups                    */
                 /* 12345678 abcdefgh and 12345678                                    */
#ifdef orginal
 
                 regex[outPos ] = (unsigned char ) (pattern[iChar] << 2 | pattern[iChar+1] >> 4);
                 regex[outPos+1] = (unsigned char ) (pattern[iChar +1] << 4 | pattern[iChar+2] >> 2);
                 regex[outPos+2] = (unsigned char ) (((pattern[iChar+ 2] << 6) & 0xc0) | pattern[iChar+3]);
#endif
                 long t; /* <<only works on integers/longs                              */
                 t = pattern[iChar];
                 /* so we have ..123456 these are bits not bytes                           */
                 t = t << 6;
                 /* so we have ..123456000000                                               */
                 /* top 2 bits of all chars are 0                                           */
                 t = t | pattern[iChar + 1];
                 /* so we have ..12345678abcd                                               */
                 t = t << 6;
                 /* so we have ..12345678abcd000000                                        */
                 t = t | pattern[iChar + 2];
                 /* so we have ..12345678abcdefgh12                                        */
                 t = t << 6;
                 /* so we have ..12345678abcdefgh12000000                                  */
                 t = t | pattern[iChar + 3];
                 /* so we have ..12345678abcdefgh12345678                                  */
                 t = t << 8;
                 /* so we have 12345678abcdefgh1234567800000000 losing top 2 bits        */
                 /* which is 12345678,abcdefgh,12345678,00000000 ignore last char        */
                 memcpy(&regex[outPos], &t, 3); /*take the top 3 chars of the long       */
                 outPos += 3; /* and point to next output in buffer    */
             }
             if (haveError > 0)
                 return 8;
             regex[outPos] = 0; /* null terminator at the end */
             /* we now need to covert from ASCII to EBCDIC                               */
 
             const char ascii_tab[256] = ASCII_STRING;
             /* find the length of the string up to the first null*/
             outPos = strlen(&regex[0]);
 
             for (iChar = 0; iChar < outPos; iChar++)
                 regex[iChar] = ascii_tab[regex[iChar]];
 
             TRACE(1, "Entry decode EBCDIC %s.\n", regex);
             /* No match to see if we can find something that starts with the prefix. */
             char * pos;
             pos = strchr(regex, '*');
             long indexOfWildcard;
             if (pos != 0)
                 holdQNLen = (int) (pos - regex);
             else
                 holdQNLen = NL_ENT_LENGTH;
             long ll3 = holdQNLen;
             TRACE(1, "wildcard position %d\n", ll3);
             memset(&holdInQ[0], ' ', MQ_Q_NAME_LENGTH); /* preset to blanks and overlay it */
             memcpy(&holdInQ[0], regex, outPos);
             if (secOn==1) {
                 memset(entity, '\0', sizeof(entity)); /* clear it  */
                 strcpy(entity,".COM.GREENHAT.ALLOW.GENERIC.QNAMES");
                 TRACE(1, "Generic entity %s\n", entity);
             }
 
        } else {
             TRACE(1, "not generic %s\n", pData);
             memcpy(&holdInQ[0], pData, MQ_Q_NAME_LENGTH);
             holdQNLen = MQ_Q_NAME_LENGTH;
             if (secOn==1) {
                 memset(entity, '\0', sizeof(entity)); /* clear it  */
                 strcpy(entity,".");
                 strncat(entity,pData,NL_ENT_LENGTH);
             }
        }
        pData += NL_ENT_LENGTH;
        pOutQueue = pData;
        TRACE(1, "Get toqueue %s\n", pData);
        memcpy(&holdOutQ[0], pData, MQ_Q_NAME_LENGTH);
        pData += NL_ENT_LENGTH;
        TRACE(1, "Get QM %s\n", pData);
        memcpy(&holdQmgr[0], pData, MQ_Q_MGR_NAME_LENGTH);
 
        if (memcmp(&holdQmgr[0], &p->QMGR[0], 4) != 0
                 && holdQmgr[0] != ' ') {
             pEntry->QFLags[0] |= NotLocalQM;
        }
        pData += NL_ENT_LENGTH;
 
        if (secOn==1) {
            if (ignoreRule==0 && foundAuthRule==0) {
                TRACE(1,"Duplicate rule is NOT being ignored.\n");
                /* Now that we know whether the rule is generic,
                   check auth and save in the authRules array */
                blankLoc=strchr(userId,blnk);
                if (blankLoc!=NULL) memset(blankLoc, '\0', 1);
                userIdLen=strlen(userId);
                strcpy(class,secClasPfx);
                strcat(class,"QUEUE");
                classLen=strlen(class);
                blankLoc=strchr(entity,blnk);
                if (blankLoc!=NULL) memset(blankLoc, '\0', 1);
                entityLen=strlen(entity);
                attr=ATTR_READ;
                inQueueRc=verifyAuth(userIdLen,userId,classLen,class,entityLen,entity,attr,qmgrProfPfx,qsgProfPfx,
                    secClasPfx,p);
                if (inQueueRc==0) {
                    /* Now that we know the id is authorized to access the
                       input queue, check access to the outQueue */
                    memset(entity, '\0', sizeof(entity)); /* clear it  */
                    strcpy(entity,".");
                    strncat(entity,pOutQueue,MQ_Q_NAME_LENGTH);
                    blankLoc=strchr(entity,blnk);
                    if (blankLoc!=NULL) memset(blankLoc, '\0', 1);
                    entityLen=strlen(entity);
                    attr=ATTR_UPDATE;
                    outQueueRc=verifyAuth(userIdLen,userId,classLen,class,entityLen,entity,attr,qmgrProfPfx,qsgProfPfx,
                        secClasPfx,p);
                    if (outQueueRc==0) {
                        /* if the id is authorized to write to the output queue,
                           move the rule to the authRules array.              */
                        if (foundUnauthRule==1) {
                            (*authCnt)++;
                            sprintf(authRules[*authCnt].ruleType,"%-9s",unauthRules[unauthIdx].ruleType);
                            /* pad with blanks up to length of name list entry (48 bytes) */
                            sprintf(authRules[*authCnt].inQueue,"%-48s",unauthRules[unauthIdx].inQueue);
                            sprintf(authRules[*authCnt].outQueue,"%-48s",unauthRules[unauthIdx].outQueue);
                            sprintf(authRules[*authCnt].ruleQmgr,"%-48s",unauthRules[unauthIdx].ruleQmgr);
                            sprintf(authRules[*authCnt].userId,"%-12s",unauthRules[unauthIdx].userId);
                            authRules[*authCnt].inDupNL=1;
                            /* save authRules TO exit name list */
                            saveDupRulesToNL(authRules,authCnt,hConn,p);
                            /* Since we moved this rule to the authRules array,
                            we can now remove it from the unauthRules array. */
                            removeRule(unauthRules,unauthCnt,compUnauth);
                        }
                    } else {
                        TRACE(1,"Authorization to output queue failed. Rule being discarded.\n");
                        ignoreRule=1;
                        if (foundUnauthRule==1) {
                            removeRule(unauthRules,unauthCnt,compUnauth);
                        }
                        if (foundAuthRule==1) {
                            removeRule(authRules,authCnt,compAuth);
                        }
                    }
                } else {
                    TRACE(1,"Authorization to input queue failed. Rule being discarded.\n");
                    ignoreRule=1;
                    if (foundUnauthRule==1) {
                        removeRule(unauthRules,unauthCnt,compUnauth);
                    }
                    if (foundAuthRule==1) {
                        removeRule(authRules,authCnt,compAuth);
                    }
                }
            } /* end if ignoreRule */
        } /* end if secOn */
 
        MQOD toQueue = { MQOD_DEFAULT };
        MQHOBJ hTo = MQHO_NONE;
        strncpy(toQueue.ObjectName, &holdOutQ[0], MQ_Q_NAME_LENGTH);
        MQOPEN(hConn, &toQueue, MQOO_INQUIRE + MQOO_FAIL_IF_QUIESCING, &hTo,
                 &cc, &rc);
        TRACE(1, "MQOPEN for %s cc %d rc %d %s\n", holdOutQ[0], cc, rc,
                 RITMQRC(rc));
        /* The user id associated with the exit may not
        have authority to open the "to queue". That's ok,
        so continue if the cc is 0 or the rc is MQRC_NOT_AUTHORIZED. */
        if (((cc==0)||(rc ==MQRC_NOT_AUTHORIZED))&&(ignoreRule==0)) {
             MQCLOSE(hConn, &hTo, 0, /* close options     */
             &cc, &rc);
             pEntry->QNLength = holdQNLen;
             memcpy(&pEntry->INQUEUE[0],&holdInQ[0], NL_ENT_LENGTH);
             memcpy(&pEntry->OUTQUEUE[0],&holdOutQ[0], NL_ENT_LENGTH);
             memcpy(&pEntry->OUTQM[0],&holdQmgr[0], NL_ENT_LENGTH);
             pEntry->INQUEUENull = 0;
             strcpy(pEntry->QAREAEND,"QAREAEND");
             TRACE(1, "Adding duplicate rule: InQueue<%s> OutQueue<%s> QM<%s>\n",
                     pEntry->INQUEUE, pEntry->OUTQUEUE, pEntry->OUTQM);
             pEntry += 1;
             nEntryNum++;
             memcpy(pCurrNamelist, pNamelist, NL_ENT_LENGTH * 3);
             pCurrNamelist += NL_ENT_LENGTH * 3;
             pNamelist += NL_ENT_LENGTH * 3;
        } else if (rc == MQRC_UNKNOWN_OBJECT_NAME) {
             TRACE(1, "Ignore this rule.\n");
        }
    } /* End of for.  number of triplets */
    /* refresh command using name list changed at */
    if (TRACEP > 8 && nEntryNum > 0) {
        printf("Refresh data\n");
        printHexS(pEntries, nEntryNum * lEntry, "  ");
    }
    TRACE(1, "before ritrefr count %d  length %d address %8.8x\n", nEntryNum,
             lEntry, pEntries);
    rc = ritrefr(p, nEntryNum, lEntry, pEntries, DUP); /* which element to store it in */
    TRACE(1, "after ritrefr %d\n", rc);
    if (rc == 0) {
        CONSOLE(p, RITREFOKDT, "duplicate", p->pInqStorage[DUP], pTime);
        TRACE(1, "Namelist %s date %10.10s time %8.8s\n", pNLName,
                 p->pInqStorage[DUP], pTime);
    } else {
    	if (rc == 16) {
            CONSOLE(p, RITREFBADQA, "duplicate", rc);
    	} else {
            CONSOLE(p, RITREFONOTDT, "duplicate", rc);
    	}
    }
    TRACE(1, "nEntryNum=%i, entries=%i\n",nEntryNum,entries);
    if(nEntryNum < entries){
        rc = replNamelist(nEntryNum * 3, pDupNamelist,
                 pNLName, hConn, p);
        if(rc == 0){
             TRACE(1, "Replace duplication namelist successfully.\n");
        }else{
             TRACE(1, "Replace duplication namelist failed.\n");
        }
    }
    FREE(pEntries);
    FREE(pDupNamelist);
#ifdef delete
    if( p->pInqStorage[DUP] > 0) FREE( p->pInqStorage[DUP]);
#endif
 
    if (secOn==1) {
        /* remove any authRules that do not have a matching rule
           in COM.GREENHAT.INTERCEPT and save to exit name list. */
        for (int i=0; i<=*authCnt; ++i) {
            foundDupRule=strncmp(authRules[i].ruleType,"DUPLICATE",9);
            if ((authRules[i].inDupNL==0)&(foundDupRule==0)) {
                /* pad with blanks up to length of name list entry (48 bytes) */
                snprintf(compAuth,sizeof(compAuth),"%-48s%-48s%-48s",authRules[i].inQueue,authRules[i].outQueue,
                    authRules[i].ruleQmgr);
                TRACE(1,"Removing auth rule:\n");
                TRACE(1,"%s\n",compAuth);
                removeRule(authRules,authCnt,compAuth);
                --i;
                TRACE(1,"After removing rule authCnt=%i",*authCnt);
            }
        }
        /* remove any unauthRules (except for DIVERT rules)   */
        for (int i=0; i<=*unauthCnt; ++i) {
            foundDupRule=strncmp(unauthRules[i].ruleType,"DIVERT",6);
            if (foundDupRule!=0) {
                /* pad with blanks up to length of name list entry (48 bytes) */
                snprintf(compUnauth,sizeof(compUnauth),"%-48s%-48s%-48s",unauthRules[i].inQueue,unauthRules[i].outQueue,
                    unauthRules[i].ruleQmgr);
                TRACE(1,"Removing unauth rule after processing DUP rules:\n");
                TRACE(1,"%s\n",compUnauth);
                removeRule(unauthRules,unauthCnt,compUnauth);
                --i;
                TRACE(1,"After removing rule unauthCnt=%i",*unauthCnt);
            }
        }
        saveDupRulesToNL(authRules,authCnt,hConn,p);
    }
 
    return 0;
}
 
/*
 * *******************************************************************************
 * Divert processing
 * *******************************************************************************
 */
long divertrf(Userparm * p, MQHCONN hConn,Exitrule unauthRules[],int *unauthCnt,Exitrule authRules[],int *authCnt,
    char qmgrProfPfx[],char qsgProfPfx[],char secClasPfx[]) {
    MQLONG cc;
    MQLONG rc;
    long count = 0;
    QArea * pEntry; /* pEntry is a queue triples    */
    QArea * pEntries;
    char* pCurrNamelist;
    char* pDupNamelist;
    char* pData2;
    long lEntry = sizeof(QArea);
    /* const char* pNLName = UC_NL_RIT[DIVERT]; */
    char pNLName[44];
    long haveError = 0;
 
    long selectors[nNLSelectors] = {
    MQCA_ALTERATION_DATE,
    MQCA_ALTERATION_TIME,
    MQIA_NAME_COUNT,
    MQCA_NAMES };
 
    int compLen=3*NL_ENT_LENGTH;
    char compUnauth[compLen+1];
    char compAuth[compLen+1];
    char compEntry[compLen+1];
    int foundUnauthRule=0;
    int foundAuthRule=0;
    int foundDivRule=0;
    char userId[MQ_USER_ID_LENGTH+1];
    char userIdNlEnt[NL_ENT_LENGTH+1];
    short userIdLen;
    short classLen;
    char class[8];
    short entityLen;
    char entity[54];
    short attr;
    short traceLevel=9;
    int ignoreRule=0;
    int authIdx=0;
    int tempCnt=0;
    int unauthIdx=0;
    int inQueueRc=8;
    int outQueueRc=8;
    char* blankLoc;
    char * pOutQueue;
    const char blnk=' ';
    char authNames[MQNC_MAX_NAMELIST_NAME_COUNT*(2+NL_ENT_LENGTH)+1];
    int secOn=1;
    long ruleLimit=MQNC_MAX_NAMELIST_NAME_COUNT*2+MQNC_MAX_NAMELIST_NAME_COUNT/3;
 
    if ((strcmp(qmgrProfPfx,"N/A")==0) & (strcmp(qsgProfPfx,"N/A")==0)) secOn=0;
 
    TRACE(9, "List of new rules prior to divert processing:\n");
    for (int i=0; i<=*unauthCnt; ++i) {
        /* pad with blanks up to length of name list entry (48 bytes) */
        snprintf(compUnauth,sizeof(compUnauth),"%-48s%-48s%-48s",unauthRules[i].inQueue,unauthRules[i].outQueue,
            unauthRules[i].ruleQmgr);
        TRACE(1, "Rule (%i bytes):\n",strlen(compUnauth));
        TRACE(1, "%s\n",compUnauth);
    }
 
    TRACE(9, "List of existing rules prior to divert processing:\n");
    for (int i=0; i<=*authCnt; ++i) {
        /* pad with blanks up to length of name list entry (48 bytes) */
        snprintf(compAuth,sizeof(compAuth),"%-48s%-48s%-48s",authRules[i].inQueue,authRules[i].outQueue,
            authRules[i].ruleQmgr);
        TRACE(1, "Rule (%i bytes):\n",strlen(compAuth));
        TRACE(1, "%s\n",compAuth);
    }
 
    /* if we have not opened the name list try now */
    /* there may have been problems with it, such as security */
    /* so there can be several attempts before this is successful */
    strcpy(pNLName,UC_NL_RIT[DIVERT]);
    strcat(pNLName,p->nlSuffix);
    if (p->hNameList[DIVERT] == 0) {
        MQOD odNamelist = { MQOD_DEFAULT };
        strncpy(odNamelist.ObjectName, pNLName, sizeof(odNamelist.ObjectName));
        odNamelist.ObjectType = MQOT_NAMELIST;
        MQOPEN(hConn, &odNamelist, MQOO_INQUIRE + MQOO_FAIL_IF_QUIESCING,
                 &p->hNameList[DIVERT], &cc, &rc);
        TRACE(1, "MQOPEN for namelist %s cc %d rc %d %s\n", pNLName, cc, rc,
                 RITMQRC(rc));
 
#ifdef UNITTEST
        DOUNITTEST(NONL2)
        cc = 8;
        rc = MQRC_UNKNOWN_OBJECT_NAME;
        printf("DOUNITTEST NONL2\n");
        ENDUNITTEST
        DOUNITTEST(NLNA2)
        cc = 8;
        rc = MQRC_NOT_AUTHORIZED;
        printf("DOUNITTEST NLNA2\n");
        ENDUNITTEST
#endif
        if (cc != 0) {
             CONSOLE(p, RITREFOPEN, pNLName, cc, rc, RITMQRC(rc));
             if (rc == MQRC_UNKNOWN_OBJECT_NAME)
                 return 4; /* continue processing */
             else
                 return 8; /* stop processing  */
        }
        p->inqSize[DIVERT] = 1;
        p->lInqStorage[DIVERT] = MQ_DATE_LENGTH + MQ_TIME_LENGTH
                 + p->inqSize[DIVERT] * lMQCHAR48;
        FREE(p->pInqStorage[DIVERT]);
        p->pInqStorage[DIVERT] = (char *) malloc(p->lInqStorage[DIVERT]);
        if (p->pInqStorage[DIVERT] == 0){
             printf("p->pInqStorage non found \n");
        }
    } /*name list == 0:  where we open the namelist and save the handle*/
 
    long cEntries = 0; /*how many entries we have */
    /* get the size of the name list with the list of NLs */
    for (int iLoop = 0; iLoop < 10; iLoop++) {
        MQINQ(hConn, p->hNameList[DIVERT], nNLSelectors, /* selectors */
        selectors, 1, /* one int specified */
        &count, p->lInqStorage[DIVERT], p->pInqStorage[DIVERT], &cc, &rc);
        TRACE(1, "MQINQ for namelist %s cc %d rc %d %s\n", pNLName, cc, rc,
                 RITMQRC(rc));
 
#ifdef UNITTEST
        DOUNITTEST(INQ0)
        count = 0;
        printf("DOUNITTEST INQ0\n");
        ENDUNITTEST
#endif
        if (rc == 0)
             break;
        else if (rc == MQRC_CHAR_ATTRS_TOO_SHORT) {
             TRACE(1,"cref: count > inqsize - so reallocate count %d old count %d \n",
                     count, p->inqSize[DIVERT]);
             p->inqSize[DIVERT] = count;
             FREE(p->pInqStorage[DIVERT]);
             p->lInqStorage[DIVERT] = MQ_DATE_LENGTH + MQ_TIME_LENGTH
                     + p->inqSize[DIVERT] * lMQCHAR48;
             p->pInqStorage[DIVERT] = (char *) malloc(p->lInqStorage[DIVERT]);
             if (p->pInqStorage[DIVERT] == 0) {
                 TRACE(0, "unable to allocate storage for p->lInqStorage[DIVERT]\n");
                 return 8;
             }
        } else if (rc == MQRC_HOBJ_ERROR) {
             MQOD odNamelist = { MQOD_DEFAULT };
             strncpy(odNamelist.ObjectName, pNLName, sizeof(odNamelist.ObjectName));
             odNamelist.ObjectType = MQOT_NAMELIST;
             MQOPEN(hConn, &odNamelist, MQOO_INQUIRE + MQOO_FAIL_IF_QUIESCING,
                     &p->hNameList[DIVERT], &cc, &rc);
             TRACE(1, "MQOPEN for namelist %s cc %d rc %d %s\n", pNLName, cc, rc,
                     RITMQRC(rc));
 
             if (cc != 0) {
                 CONSOLE(p, RITREFOPEN, pNLName, cc, rc, RITMQRC(rc));
                 if (rc == MQRC_UNKNOWN_OBJECT_NAME)
                     return 4; /* continue processing */
                 else
                     return 8; /* stop processing  */
             }
             p->inqSize[DIVERT] = 1;
             p->lInqStorage[DIVERT] = MQ_DATE_LENGTH + MQ_TIME_LENGTH
                     + p->inqSize[DIVERT] * lMQCHAR48;
             p->pInqStorage[DIVERT] = (char *) malloc(p->lInqStorage[DIVERT]);
             if (p->pInqStorage[DIVERT] == 0){
                 printf("p->pInqStorage non found \n");
             }
        } else {
             CONSOLE(p, RITREFINQ, pNLName, cc, rc, RITMQRC(rc));
             return 8;
        }
 
    } /* for  MQINQ loop */
 
    if (secOn==1) {
        /* reset inDivNL flag within authRules */
        TRACE(1,"Initializing inDivNL\n");
        for (int i=0; i<=*authCnt; ++i) {
            authRules[i].inDivNL=0;
        }
    }
 
    /************************************************************************/
    /* now process each element                                             */
    /* which is a name list containing the data                             */
    /************************************************************************/
    /* point past the gdate and time */
    char* pData = p->pInqStorage[DIVERT] + MQ_DATE_LENGTH + MQ_TIME_LENGTH;
    char* pTime = p->pInqStorage[DIVERT] + MQ_DATE_LENGTH;
    TRACE(1, "Namelist divert %s changed on %10.10s at %8.8s\n", pNLName,
             p->pInqStorage[DIVERT], pTime);
    TRACE(1, "Namelist divert %s entries %d contents %s\n", pNLName, count, pData);
 
    long entries = count;
    if (count != 0) {
        /* get enough storage of all of our 48 byte entries    */
        pEntries = (QArea *) malloc(entries * sizeof(QArea));
        if (pEntries == NULL) {
             TRACE(0, "unable to allocate storage for pEntries\n");
             return 8;
        }
        memset(pEntries, 0, entries * lEntry); /* and clear    */
    } else {
        pEntries = 0;
    }
    pEntry = pEntries; /* point to the first entry     */
    TRACE(1, "inqSize %d\n", p->inqSize[DIVERT]);
    char* divertNamelist = (char*)malloc(p->inqSize[DIVERT] * lMQCHAR48);
    if (divertNamelist == NULL) {
        FREE(pEntries);
        TRACE(0, "unable to allocate storage for divertNamelist\n");
        return 8;
    }
    memset(divertNamelist, 0, p->inqSize[DIVERT] * lMQCHAR48);  /* and clear    */
    pCurrNamelist = divertNamelist;
    for (long iEntry = 0; iEntry < entries; iEntry++) { /* number of entries */
        pData2 = pData;
        /* remove trailing blanks by changing first blank to a null */
        for (long j = 0; j < NL_ENT_LENGTH; j++) {
             if (pData[j] != ' ')
                 continue;
             pData[j] = 0;
             break;
        }
        long inqDivRc = inqDivertNL(pData, pEntry, hConn, p);
        TRACE(1, "inqDivRC %d\n", inqDivRc);
 
        pData += NL_ENT_LENGTH; /* keep going along the name list */
        strcpy(pEntry->QAREAEND,"QAREAEND");
        if (inqDivRc == 0) {
            /* Now that we know the namelist is valid and the   */
            /* out queue exists, check authorizations.          */
            if (secOn==1) {
                /* First determine if this rule is already in the list
                   of authorized rules.                                */
                foundAuthRule=0;
                /* pad with blanks up to length of name list entry (48 bytes) */
                snprintf(compEntry,sizeof(compEntry),"%-48s%-48s%-48s",pEntry->INQUEUE,pEntry->OUTQUEUE,
                    pEntry->OUTQM);
                compEntry[compLen]='\0';
                for (int i=0; i<=*authCnt; ++i) {
                    /* pad with blanks up to length of name list entry (48 bytes) */
                    snprintf(compAuth,sizeof(compAuth),"%-48s%-48s%-48s",authRules[i].inQueue,authRules[i].outQueue,
                        authRules[i].ruleQmgr);
                    TRACE(1,"Checking if auth rule exists for:\n");
                    TRACE(1,"%s\n",compAuth);
                    if (strncmp(compAuth,compEntry,2*NL_ENT_LENGTH)==0) {
                        foundAuthRule=1;
                        authRules[i].inDivNL=1;
                        authIdx=i;
                        sprintf(userId,"%s",authRules[i].userId);
                        TRACE(1,"Auth rule exists for name list rule:\n");
                        break;
                    }
                }
 
                /* If not already in list of authorized rules, and if
                   the max number of authRules has been reached, ignore this one.    */
                if (*authCnt>=ruleLimit && foundAuthRule==0) {
                    ignoreRule=1;
                    TRACE(1, "Only %d rules are supported. Ignoring rule.\n",ruleLimit);
                }
 
                /* If rule was not already in list of authorized rules,
                   loop through "unauthenticated rules" received as part of
                   COM.GREENHAT.INTERCEPT message. If a match is found, get
                   the user id. If no match is found, then this rule is
                   invalid and should be removed from the list.          */
                if (foundAuthRule==0) {
                    foundUnauthRule=0;
                    for (int i=0; i<=*unauthCnt; ++i) {
                        /* pad with blanks up to length of name list entry (48 bytes) */
                        snprintf(compUnauth,sizeof(compUnauth),"%-48s%-48s%-48s",unauthRules[i].inQueue,
                            unauthRules[i].outQueue,unauthRules[i].ruleQmgr);
                        TRACE(1, "NL rule (%i bytes):\n",strlen(compEntry));
                        TRACE(1, "%s\n",compEntry);
                        TRACE(1, "Msg rule (%i bytes):\n",strlen(compUnauth));
                        TRACE(1, "%s\n",compUnauth);
                        if (strncmp(compUnauth,compEntry,2*NL_ENT_LENGTH)==0) {
                            /* This name list rule matches a rule from the RIT
                            command queue. Save the userId for use later. */
                            foundUnauthRule=1;
                            sprintf(userId,"%s",unauthRules[i].userId);
                            unauthIdx=i;
                            break;
                        }
                    }
                }
 
                /* If rule is not in either authRules or unAuthRules
                   it should be ignored. */
                if (foundAuthRule==0 && foundUnauthRule==0) {
                    ignoreRule=1;
                    TRACE(1, "Rule not found in either rule list. Ignoring rule.\n");
                }
 
                if (ignoreRule==0 && foundAuthRule==0) {
                    TRACE(1,"Divert rule is NOT being ignored.\n");
                    blankLoc=strchr(userId,blnk);
                    if (blankLoc!=NULL) memset(blankLoc, '\0', 1);
                    userIdLen=strlen(userId);
                    strcpy(class,secClasPfx);
                    strcat(class,"QUEUE");
                    classLen=strlen(class);
                    memset(entity, '\0', sizeof(entity)); /* clear it  */
                    strcpy(entity,".");
                    strncat(entity,pEntry->INQUEUE,NL_ENT_LENGTH);
                    blankLoc=strchr(entity,blnk);
                    if (blankLoc!=NULL) memset(blankLoc, '\0', 1);
                    entityLen=strlen(entity);
                    attr=ATTR_READ;
                    inQueueRc=verifyAuth(userIdLen,userId,classLen,class,entityLen,entity,attr,qmgrProfPfx,qsgProfPfx,
                        secClasPfx,p);
                    if (inQueueRc==0) {
                        /* Now that we know the id is authorized to access the
                           input queue, check access to the outQueue */
                        memset(entity, '\0', sizeof(entity)); /* clear it  */
                        strcpy(entity,".");
                        strncat(entity,pEntry->OUTQUEUE,NL_ENT_LENGTH);
                        blankLoc=strchr(entity,blnk);
                        if (blankLoc!=NULL) memset(blankLoc, '\0', 1);
                        entityLen=strlen(entity);
                        attr=ATTR_UPDATE;
                        outQueueRc=verifyAuth(userIdLen,userId,classLen,class,entityLen,entity,attr,qmgrProfPfx,
                            qsgProfPfx,secClasPfx,p);
                        if (outQueueRc==0) {
                            /* if the id is authorized to write to the output queue,
                               move the rule to the authRules array.              */
                            if (foundUnauthRule==1) {
                                (*authCnt)++;
                                sprintf(authRules[*authCnt].ruleType,"%-9s",unauthRules[unauthIdx].ruleType);
                                /* pad with blanks up to length of name list entry (48 bytes) */
                                sprintf(authRules[*authCnt].inQueue,"%-48s",unauthRules[unauthIdx].inQueue);
                                sprintf(authRules[*authCnt].outQueue,"%-48s",unauthRules[unauthIdx].outQueue);
                                sprintf(authRules[*authCnt].ruleQmgr,"%-48s",unauthRules[unauthIdx].ruleQmgr);
                                sprintf(authRules[*authCnt].userId,"%-12s",unauthRules[unauthIdx].userId);
                                authRules[*authCnt].inDivNL=1;
                                /* save authRules TO exit name list */
                                saveDivRulesToNL(authRules,authCnt,hConn,p);
                                /* Since we moved this rule to the authRules array,
                                we can now remove it from the unauthRules array. */
                                removeRule(unauthRules,unauthCnt,compUnauth);
                            }
                        } else {
                            TRACE(1,"Authorization to output queue failed. Rule being discarded.\n");
                            ignoreRule=1;
                            if (foundUnauthRule==1) {
                                removeRule(unauthRules,unauthCnt,compUnauth);
                            }
                            if (foundAuthRule==1) {
                                removeRule(authRules,authCnt,compAuth);
                            }
                        }
                    } else {
                        TRACE(1,"Authorization to input queue failed. Rule being discarded.\n");
                        ignoreRule=1;
                        if (foundUnauthRule==1) {
                            removeRule(unauthRules,unauthCnt,compUnauth);
                        }
                        if (foundAuthRule==1) {
                            removeRule(authRules,authCnt,compAuth);
                        }
                    }
                } /* end if ignoreRule */
            } /* end if secon==1 */
 
            /* authentication checks should be done by here */
            if (ignoreRule==0) {
                pEntry += 1; /* use the next one */
                cEntries += 1; /* count of valid entries */
                memcpy(pCurrNamelist, pData2, lMQCHAR48);
                pCurrNamelist += lMQCHAR48;
            }
        }
        if (((inqDivRc != 0) & (inqDivRc < 8)) | (ignoreRule==1)) {
             int delrc = delNamelist(pData2, hConn, p);
             if(delrc == 0){
                 TRACE(1, "Replace divert namelist successful.\n");
             }else{
                 TRACE(1, "Replace divert namelist failed.\n");
             }
             continue; /* reloop                           */
        }
    } /* for loop */
    /* refresh command using name list changed at */
    if (TRACEP > 8 && cEntries > 0) {
        printf("Refresh divert data valid entries %d\n", cEntries);
        printHexS(pEntries, cEntries * lEntry, "  ");
    }
    if (TRACEP > 8 && cEntries == 0) {
        printf("Refresh divert data had no entries\n");
    }
    TRACE(1, "before ritrefr count %d  length %d address %8.8x\n", cEntries,
             lEntry, pEntries);
    rc = ritrefr(p, cEntries, lEntry, pEntries, DIVERT); /* which element to store it in */
    TRACE(1, "after ritrefr %d\n", rc);
    if (rc == 0) {
        CONSOLE(p, RITREFOKDT, "divert", p->pInqStorage[DIVERT], pTime);
    } else {
    	if (rc == 16) {
            CONSOLE(p, RITREFBADQA, "divert", rc);
    	} else {
            CONSOLE(p, RITREFONOTDT, "divert", rc);
    	}
    }
    FREE(pEntries);
    if(cEntries < entries){
        rc = replNamelist(cEntries, divertNamelist,
             pNLName, hConn, p);
        if(rc == 0){
             TRACE(1, "Replace divert namelist successfully.\n");
        }else{
             TRACE(1, "Replace divert namelist failed.\n");
        }
    }
    FREE(divertNamelist);
#ifdef deletee
    if( p->pInqStorage[DIVERT] > 0) {
        FREE( p->pInqStorage[DIVERT]);
    }
#endif
    if (secOn==1) {
        /* remove any authRules that do not have a matching rule
           in RIT.DIVERT.RULES and save to exit name list. */
        for (int i=0; i<=*authCnt; ++i) {
            foundDivRule=strncmp(authRules[i].ruleType,"DIVERT",6);
            if ((authRules[i].inDivNL==0)&(foundDivRule==0)) {
                /* pad with blanks up to length of name list entry (48 bytes) */
                snprintf(compAuth,sizeof(compAuth),"%-48s%-48s%-48s",authRules[i].inQueue,authRules[i].outQueue,
                    authRules[i].ruleQmgr);
                TRACE(1,"Removing auth rule:\n");
                TRACE(1,"%s\n",compAuth);
                removeRule(authRules,authCnt,compAuth);
                --i;
                TRACE(1,"After removing rule authCnt=%i\n",*authCnt);
            }
        }
        /* remove any unauthRules (except for DUP rules)   */
        for (int i=0; i<=*unauthCnt; ++i) {
            foundDivRule=strncmp(unauthRules[i].ruleType,"DUPLICATE",9);
            if (foundDivRule!=0) {
                /* pad with blanks up to length of name list entry (48 bytes) */
                snprintf(compUnauth,sizeof(compUnauth),"%-48s%-48s%-48s",unauthRules[i].inQueue,unauthRules[i].outQueue,
                    unauthRules[i].ruleQmgr);
                TRACE(1,"Removing unauth rule:\n");
                TRACE(1,"%s\n",compUnauth);
                removeRule(unauthRules,unauthCnt,compUnauth);
                --i;
                TRACE(1,"After removing rule unauthCnt=%i\n",*unauthCnt);
            }
        }
        saveDivRulesToNL(authRules,authCnt,hConn,p);
    }
    return 0;
}
 
/*
 * inqDivertNL
 * return the 3 entries in the specific Divert NL
 */
long inqDivertNL(char * pName, QArea * pQA, MQHCONN hConn, Userparm * p) {
    char nlName[49]; /*name list name with trailing null */
    MQHOBJ hNL;
    MQOD divert = { MQOD_DEFAULT };
    MQLONG cc;
    MQLONG rc;
    QArea * pEntry; /* pEntry is a queue triples    */
 
    long selectors[nSelectors2] = { MQIA_NAME_COUNT, MQCA_NAMES };
 
    memcpy(nlName, pName, sizeof(divert.ObjectName));
    /* copy the passed queue name */
    char* pPureName = trimBlank(nlName);
    strncpy(divert.ObjectName, pPureName, sizeof(divert.ObjectName));
    divert.ObjectType = MQOT_NAMELIST;
    /* and save the queue name for messages */
    nlName[strlen(pPureName)] = 0; /* so we can use printf on strings */
    MQOPEN(hConn, &divert, MQOO_INQUIRE + MQOO_FAIL_IF_QUIESCING, &hNL, &cc,
             &rc);
    TRACE(1, "MQOPEN for divert namelist %s cc %d rc %d %s\n", nlName, cc,
             rc, RITMQRC(rc));
#ifdef UNITTEST
    DOUNITTEST(DNLOPENU)
    cc = 8;
    rc = MQRC_UNKNOWN_OBJECT_NAME;
    printf("DOUNITTEST DNLOPEN1\n");
    ENDUNITTEST
    DOUNITTEST(DNLOPENA)
    cc = 8;
    rc = MQRC_NOT_AUTHORIZED;
    printf("DOUNITTEST DNLOPENA\n");
    ENDUNITTEST
#endif
 
    if (cc != 0) {
        CONSOLE(p, RITREFOPEN, nlName, cc, rc, RITMQRC(rc));
        return 8; /* return 8 if the namelist not exist */
    }
 
    char list[NL_ENT_LENGTH * 3];
    long count2 = 0;
    MQLONG inqrc;
 
    MQINQ(hConn, hNL, nSelectors2, /* count of selectors */
    selectors, 1, /* one int specified */
    &count2, sizeof(list), &list[0], &cc, &inqrc);
    TRACE(1, "MQINQ for namelist %s cc %d rc %d %s\n", nlName, cc, inqrc,
             RITMQRC(inqrc));
#ifdef UNITTEST
    DOUNITTEST(DNLINQ)
    cc = 8;
    inqrc = MQRC_UNKNOWN_OBJECT_NAME;
    printf("DOUNITTEST DNLOPEN1\n");
    ENDUNITTEST
    DOUNITTEST(DNLOPENA)
    cc = 8;
    inqrc = MQRC_NOT_AUTHORIZED;
    printf("DOUNITTEST DNLOPENA\n");
    ENDUNITTEST
#endif
 
    MQCLOSE(hConn, &hNL, 0, /* close options     */
    &cc, &rc);
    TRACE(1, "MCLOSE for divert namelist %s cc %d rc %d %s\n", pName, cc,
             rc, RITMQRC(rc));
 
    /* for ease of displaying messages, treat MQRC_CHAR_ATTRS_TOO_SHORT as rc = 0 */
    /* as the number of records is greater than 3, so will get processed below    */
    if (inqrc == MQRC_CHAR_ATTRS_TOO_SHORT)
        inqrc = 0;
    if (inqrc != 0) {
        CONSOLE(p, RITREFINQ, nlName, cc, inqrc, RITMQRC(inqrc));
        return 4; /* return 4 if the namelist exist but MQINQ fail */
    }
    /* return code was 0 or MQRC_CHAR_ATTRS_TOO_SHORT */
    if (count2 == 3) {
        TRACE(1, "Get divert queue %s.\n", &list[0]);
        memcpy(&(pQA->INQUEUE[0]), &list[0], NL_ENT_LENGTH);
        TRACE(1, "Get toqueue %s.\n", &list[NL_ENT_LENGTH]);
        memcpy(&(pQA->OUTQUEUE[0]), &list[NL_ENT_LENGTH], NL_ENT_LENGTH);
        TRACE(1, "Get QM %s.\n", &list[NL_ENT_LENGTH * 2]);
        memcpy(&(pQA->OUTQM[0]), &list[NL_ENT_LENGTH * 2], NL_ENT_LENGTH);
 
        if (memcmp(&pQA->OUTQM[0], &p->QMGR[0], 4) != 0)
             TRACE(1, "NO QM Match\n");
        if (pQA->OUTQM[0] != ' ')
             TRACE(1, "NO QM Match2\n");
        /* if qm name does not match ours, and is not blank - flag it */
        if (memcmp(&pQA->OUTQM[0], &p->QMGR[0], 4) != 0
                 && pQA->OUTQM[0] != ' ') {
             pQA->QFLags[0] |= NotLocalQM;
        }
        TRACE(1, "Setting length to 48\n");
        pQA->QNLength = NL_ENT_LENGTH;
 
        MQOD toQueue = { MQOD_DEFAULT };
        MQHOBJ hTo = MQHO_NONE;
        strncpy(toQueue.ObjectName, &pQA->OUTQUEUE[0], NL_ENT_LENGTH);
        MQOPEN(hConn, &toQueue, MQOO_INQUIRE + MQOO_FAIL_IF_QUIESCING, &hTo,
                 &cc, &rc);
        TRACE(1, "MQOPEN for %s cc %d rc %d %s\n", &pQA->OUTQUEUE[0], cc, rc,
                 RITMQRC(rc));
        if (cc == 0) {
             MQCLOSE(hConn, &hTo, 0, /* close options     */
             &cc, &rc);
             TRACE(1, "Adding divert rule: InQueue<%s> OutQueue<%s> QM<%s>\n",
                     pQA->INQUEUE, pQA->OUTQUEUE, pQA->OUTQM);
             return 0;
        } else if (rc == MQRC_UNKNOWN_OBJECT_NAME) {
             TRACE(1, "OutQueue does not exist, ignore this rule.\n");
             return 4; /* not valid */
        }
    } else {
        CONSOLE(p, RITBADDIVERTNL, pName);
        TRACE(1, "Invalid number of records in NL %s %d\n", pName, count2);
        return 4; /* not valid */
    }
    return 0; /* should not get here */
}
 
/*
 * getSecurityStatus
 * Issue commands to display the status of security on a qmgr.
 * If subsystem security and queue security are enabled, then
 * MQ is set up to perform authorization checks when accessing
 * queues. Which RACF profiles are used to make these checks
 * is dependent on whether the qmgr is in a qsg. If not,
 * each RACF profile name contains the qmgr name as a four
 * character prefix. If the qmgr is in a qsg, then the profile
 * prefix might be the qsg name, the qmgr name, or there may be
 * one RACF profile with each prefix. This function sets the
 * RACF profile prefixes based on the results of the display
 * security comand. It also parses the command to determine
 * whether RACF profile names are limited to upper case.
 */
long getSecurityStatus(MQHCONN hConn, Userparm * p,char qmgrProfPfx[],char qsgProfPfx[],char secClasPfx[]) {
    int subsystemSecurity=1;
    int queueSecurity=1;
    int mixedCaseSecurity=0;
    int tempIdx=0;
    char buffer[256] = {0};
    char rspBuffer[4608] = {0}; /* 18 messages, 256 bytes each */
    char* strLoc;
    char tempStr[5];
    strcpy(qmgrProfPfx,"N/A");
    strcpy(qsgProfPfx,"N/A");
    strcpy(secClasPfx,"NA");
    sprintf(buffer, "DISPLAY SECURITY");
    TRACE(1, "rspBuffer size: %i\n", sizeof(rspBuffer));
    int rc = sendAdminCmd((MQLONG)strlen(buffer), (MQBYTE*)buffer, hConn, p,
             (MQLONG)sizeof(rspBuffer), (MQBYTE *)rspBuffer, 18);
    TRACE(1, "Send command for display  security: %s \n return code: %d\n", buffer, rc);
    TRACE(1, "display security response: %s\n", rspBuffer);
    if (rc<0) return rc;
 
    /* First see if subsys security is enabled.      */
    if (strstr(rspBuffer,"SUBSYSTEM: OFF")>0) {
        TRACE(1, "Subsystem security is OFF. \n");
        return 0;
    }
    else {
        if (strstr(rspBuffer,"SUBSYSTEM: ON")>0) {
            TRACE(1, "Subsystem security is ON. \n");
            subsystemSecurity=1;
        }
        /* Unless we specifically found that security is */
        /* off, we want to assume it is enabled.         */
        else {
            TRACE(1, "Unable to determine security status. Assuming Subsystem security is ON.\n");
            subsystemSecurity=1;
        }
    }
 
    /* Next see if queue security is enabled.        */
    if (strstr(rspBuffer," QUEUE: OFF")>0) {
        TRACE(1, "Queue security is OFF. \n");
        queueSecurity=0;
    }
    else {
        if (strstr(rspBuffer," QUEUE: ON")>0) {
            TRACE(1, "Queue security is ON. \n");
            queueSecurity=1;
        }
        /* Unless we specifically found that security is */
        /* off, we want to assume it is enabled.         */
        else {
            TRACE(1, "Unable to determine security status. Assuming QUEUE security is ON.\n");
            queueSecurity=1;
        }
    }
 
    /* Next check for QMGR: message. This only appears */
    /* When the qmgr is part of a QSG.                 */
    if (strstr(rspBuffer," QMGR: OFF")>0) {
        TRACE(1, "Queue manager security is OFF. \n");
    }
    else {
        if (strstr(rspBuffer," QMGR: ON")>0) {
            TRACE(1, "Queue manager security is ON. \n");
            strLoc=strstr(rspBuffer,"CSQH034I");
            if (strLoc!=0) {
                strLoc+=9;
                memset(qmgrProfPfx, '\0', 5); /* clear it */
                strncpy(qmgrProfPfx,strLoc,4);
            }
            else {
                TRACE(1, "Unable to determine qmgr profile prefix (qmgr in qsg).\n");
            }
        }
        /* When the QMGR is not part of a QSG, it is normal */
        /* not to find the QMGR: message. In this case, set */
        /* the qmgr profile prefix based on the subsystem   */
        /* security message.                                */
        else {
            TRACE(1, "No QMGR: security message found. Setting profile prefix from SUBSYSTEM.\n");
            strLoc=strstr(rspBuffer,".NO.SUBSYS.SECURITY");
            if (strLoc!=0) {
                strLoc-=4;
                memset(qmgrProfPfx, '\0', 5); /* clear it */
                strncpy(qmgrProfPfx,strLoc,4);
            }
            else {
                TRACE(1, "Unable to determine security profile prefix (qmgr not in qsg).\n");
            }
        }
    }
 
    /* Next check for QSG: message. This only appears  */
    /* when the qmgr is part of a QSG.                 */
    if (strstr(rspBuffer," QSG: OFF")>0) {
        TRACE(1, "Queue sharing group level security is OFF. \n");
    }
    else {
        if (strstr(rspBuffer," QSG: ON")>0) {
            TRACE(1, "Queue sharing group security is ON. \n");
            strLoc=strstr(rspBuffer,".NO.QSG.CHECKS");
            if (strLoc!=0) {
                strLoc-=4;
                memset(qsgProfPfx, '\0', 5); /* clear it */
                strncpy(qsgProfPfx,strLoc,4);
            }
            else {
                TRACE(1, "Unable to determine qsg profile prefix.\n");
            }
        }
        /* When the QMGR is not part of a QSG, it is normal */
        /* not to find the QMGR: message. In this case, set */
        /* the qmgr profile prefix based on the subsystem   */
        /* security message.                                */
        else {
            TRACE(1, "No QSG: security message found.\n");
        }
    }
 
    /* If the queue manager name is less than 4 characters,*/
    /* we need to fix the qmgrProfPfx                      */
    /* First, if there is an apostrophe in the name, only  */
    /* use characters after that.                          */
    /* The following statements are for unit testing:      */
    /* strcpy(qmgrProfPfx,"\'QM1"); */
    /* strcpy(qmgrProfPfx,"QM1 ");  */
    for (int i=0; i<4; ++i) {
        if (qmgrProfPfx[i]=='\'') {
            i=i+1;
            strcpy(tempStr,&qmgrProfPfx[i]);
            strcpy(qmgrProfPfx,tempStr);
            break;
        }
    }
    /* Second, if there are trailing blanks in the name,   */
    /* trim them off.                                      */
    for (int i=0; i<4; ++i) {
        if (qmgrProfPfx[i]==' ') {
            qmgrProfPfx[i]=0;
            break;
        }
    }
 
    /* If the qsg name is less than 4 characters, we need  */
    /* to fix the qsgProfPfx                               */
    /* First, if there is an apostrophe in the name, only  */
    /* use characters after that.                          */
    /* The following statements are for unit testing:      */
    /* strcpy(qsgProfPfx," \'QG"); */
    /* strcpy(qsgProfPfx,"QG  ");  */
    for (int i=0; i<4; ++i) {
        if (qsgProfPfx[i]=='\'') {
            i=i+1;
            strcpy(tempStr,&qsgProfPfx[i]);
            strcpy(qsgProfPfx,tempStr);
            break;
        }
    }
    /* Second, if there are trailing blanks in the name,   */
    /* trim them off.                                      */
    for (int i=0; i<4; ++i) {
        if (qsgProfPfx[i]==' ') {
            qsgProfPfx[i]=0;
            break;
        }
    }
 
    /* Check whether MQxxx or MXxxx classes are being used */
    if (strstr(rspBuffer," using uppercase classes")>0) {
        TRACE(1, "Using uppercase security profiles. \n");
        mixedCaseSecurity=0;
        strcpy(secClasPfx,"MQ");
    }
    else {
        if (strstr(rspBuffer," using mixed case classes")>0) {
            TRACE(1, "Using mixed case security profiles. \n");
            mixedCaseSecurity=1;
            strcpy(secClasPfx,"MX");
        }
        else {
            TRACE(1, "Unable to determine profile case. Assuming uppercase classes.\n");
            mixedCaseSecurity=0;
            strcpy(secClasPfx,"MQ");
        }
    }
    /*
       rc=0  MQ queue authorization checking not required
       rc=1  MQ queue authorization required using upper case security profiles
       rc=2  MQ queue authorization required using mixed case security profiles
    */
    if ((subsystemSecurity==1) & (queueSecurity==1)) {
        rc=1;
        if (mixedCaseSecurity==1) rc=2;
    }
    else rc=0;
    return rc;
}
 
long getQSGN(MQHCONN hConn, Userparm * p) {
    char buffer[256] = {0};
    char rspBuffer[256] = {0};
    char qsgName[5] = {0};
    sprintf(buffer, "DISPLAY QMGR QSGNAME");
    TRACE(1, "rspBuffer size: %i\n", sizeof(rspBuffer));
    int rc = sendAdminCmd((MQLONG)strlen(buffer), (MQBYTE*)buffer, hConn, p,
             (MQLONG)sizeof(rspBuffer), (MQBYTE *)rspBuffer, 3);
    TRACE(1, "Send command for display qmgr qsgname: %s \n return code: %d\n", buffer, rc);
    TRACE(1, "display qmgr qsgname response: %s \n", rspBuffer);
    if (strstr(rspBuffer,"QSGNAME(")>0) {
        strncpy(qsgName,strstr(rspBuffer,"QSGNAME(")+8,4);
        memcpy(&p->QSGNAME[0], &qsgName[0], 4);
    }
    TRACE(1, "qsgname: %s \n", qsgName);
    return rc;
}
 
long getNLSuffix(MQHCONN hConn, Userparm * p) {
 
    /* We want to use the new format for namelist names, but we also want */
    /* to continue to support the old namelist names. The new names       */
    /* have the QMGR name appended to the end. For                        */
    /* example, on a QMGR named ABCD, the namelist used during recording  */
    /* would be named COM.GREENHAT.INTERCEPT.ABCD. This function checks   */
    /* whether name lists with the new names exist. If not, it checks     */
    /* whether name lists with the old names exist. Based on the results, */
    /* it sets a suffix that is appended to the namelist names within     */
    /* other functions.                                                   */
 
    const char * pNLName;  /* pointer to the name list */
    char qmgr[5];
    char newDupName[40];
    char newDivName[40];
    char buffer[256] = {0};
    char rspBuffer[256] = {0};
    char qsgName[5] = {0};
    int rc;
    int nameLen;
    int newDupNLExists = 0;
    int newDivNLExists = 0;
    int oldDupNLExists = 0;
    int oldDivNLExists = 0;
 
    strncpy(qmgr,p->QMGR,4);
    qmgr[4] = 0; /* null termination */
 
    /* Is the QMGR part of a QSG ? */
    if (strncmp(p->QSGNAME,"    ",4)!=0) {
 
        /* Case #1 - Clients who want to record/virtualize shared queues  */
        /* must have the qmgr name appended to the end of the name lists, */
        /* and the name lists must be created with QSGDISP(GROUP/COPY).   */
        /* Check whether new duplicate namelist exists with QSGDISP(COPY) */
        pNLName = UC_NL_RIT[DUP];
 
        strcpy(newDupName, pNLName);
        strcat(newDupName, ".");
        strcat(newDupName, qmgr);
        sprintf(buffer, "DISPLAY NAMELIST(%s) QSGDISP(COPY) ALTDATE",newDupName);
        memset(rspBuffer,0,sizeof(rspBuffer));
        rc = sendAdminCmd((MQLONG)strlen(buffer), (MQBYTE*)buffer, hConn, p,
                 (MQLONG)sizeof(rspBuffer), (MQBYTE *)rspBuffer, 3);
        if (strstr(rspBuffer,"ALTDATE(")!=0) {newDupNLExists = 1;}
        TRACE(1, "newDupNLExists? %i\n", newDupNLExists);
 
        /* Check whether new divert namelist exists with QSGDISP(COPY)    */
        pNLName = UC_NL_RIT[DIVERT];
 
        strcpy(newDivName, pNLName);
        strcat(newDivName, ".");
        strcat(newDivName, qmgr);
        sprintf(buffer, "DISPLAY NAMELIST(%s) QSGDISP(COPY) ALTDATE",newDivName);
        memset(rspBuffer,0,sizeof(rspBuffer));
        rc = sendAdminCmd((MQLONG)strlen(buffer), (MQBYTE*)buffer, hConn, p,
                 (MQLONG)sizeof(rspBuffer), (MQBYTE *)rspBuffer, 3);
        if (strstr(rspBuffer,"ALTDATE(")!=0) {newDivNLExists = 1;}
        TRACE(1, "newDivNLExists? %i\n", newDivNLExists);
 
        if ((newDupNLExists==1)&(newDivNLExists==1)) {
            /* If both new namelists exist, set suffix to .qmgr name          */
            memcpy(&p->nlSuffix[0], ".", 1);
            memcpy(&p->nlSuffix[1], &qmgr[0], 4);
            memcpy(&p->nlSuffix[5], "", 1);
        } else if ((newDupNLExists==1)&(newDivNLExists==0)) {
            /* If only one of the new namelists exists, write error           */
            TRACE(1, "Error. %s exists, but %s does not exist.\n", newDupName, newDivName);
            TRACE(1, "In order to enable shared queue support, create %s \n", newDivName);
            TRACE(1, "with QSG(GROUP) before continuing.\n");
            return 8;
        } else if ((newDupNLExists==0)&(newDivNLExists==1)) {
            /* If only one of the new namelists exists, write error           */
            TRACE(1, "Error. %s exists, but %s does not exist. \n", newDivName, newDupName);
            TRACE(1, "In order to enable shared queue support, create %s \n", newDupName);
            TRACE(1, "with QSG(GROUP) before continuing. \n");
            return 8;
        } else {
            /* Case #2 - Clients who are recording/virtualizing only local    */
            /* queues on a QMGR that is part of a queue sharing group may     */
            /* still be set up with the original name lists without the QMGR  */
            /* name suffixed.                                                 */
 
            /* If neither of the new namelists exists, check for old name lists */
            /* Check whether old duplicate namelist exists with QSGDISP(QMGR) */
            pNLName = UC_NL_RIT[DUP];
 
            sprintf(buffer, "DISPLAY NAMELIST(%s) QSGDISP(QMGR) ALTDATE",pNLName);
            memset(rspBuffer,0,sizeof(rspBuffer));
            rc = sendAdminCmd((MQLONG)strlen(buffer), (MQBYTE*)buffer, hConn, p,
                     (MQLONG)sizeof(rspBuffer), (MQBYTE *)rspBuffer, 3);
            /* If not, write error and exit                                */
            if (strstr(rspBuffer,"ALTDATE(")==0) {
                TRACE(1, "Error. Name list (%s) not found.\n", pNLName);
                TRACE(1, "See documentation for procedures to either create %s \n", pNLName);
                TRACE(1, "if shared queue support is not needed, or to create name list %s \n", newDupName);
                TRACE(1, "if shared queue support is needed. \n");
                return 8;
            }
 
            /* Check whether old divert namelist exists with QSGDISP(QMGR) */
            /* If not, write error                                         */
            pNLName = UC_NL_RIT[DIVERT];
 
            sprintf(buffer, "DISPLAY NAMELIST(%s) QSGDISP(QMGR) ALTDATE",pNLName);
            memset(rspBuffer,0,sizeof(rspBuffer));
            rc = sendAdminCmd((MQLONG)strlen(buffer), (MQBYTE*)buffer, hConn, p,
                    (MQLONG)sizeof(rspBuffer), (MQBYTE *)rspBuffer, 3);
           TRACE(1, "command: %s \n",buffer);
           TRACE(1, "response: %s \n",rspBuffer);
           TRACE(1, "response: %i \n",strstr(rspBuffer,"ALTDATE("));
           /* If not, write error and exit                                */
           if (strstr(rspBuffer,"ALTDATE(")==0) {
               TRACE(1, "Error. Name list (%s) not found.\n", pNLName);
               TRACE(1, "See documentation for procedures to either create %s \n", pNLName);
               TRACE(1, "if shared queue support is not needed, or to create name list %s \n", newDivName);
               TRACE(1, "and name list %s if shared queue support is needed. \n", newDupName);
               return 8;
           }
 
 
           /* If both old name lists exist, issue warning message that    */
           /* recording/virtualizing of shared queues is not supported.   */
           TRACE(1, "Warning. Intercept is running without support for shared queues.\n");
           TRACE(1, "See documentation for instructions on enabling shared queue support.\n");
 
           /* set suffix to empty string                                  */
           memcpy(&p->nlSuffix[0], "", 1);
           return 4;
       }
 
   }
   else {
   /* QMGR is not part of a QSG */
 
       /* Case #3 - Clients with QMGRs that are not part of a QSG     */
       /* will be using the old name list names.                      */
 
       /* Check whether old duplicate namelist exists with QSGDISP(QMGR) */
       pNLName = UC_NL_RIT[DUP];
 
       sprintf(buffer, "DISPLAY NAMELIST(%s) QSGDISP(QMGR) ALTDATE",pNLName);
       memset(rspBuffer,0,sizeof(rspBuffer));
       rc = sendAdminCmd((MQLONG)strlen(buffer), (MQBYTE*)buffer, hConn, p,
                (MQLONG)sizeof(rspBuffer), (MQBYTE *)rspBuffer, 3);
       /* If not, write error and exit                                */
       if (strstr(rspBuffer,"ALTDATE(")==0) {
           TRACE(1, "Error. Name list (%s) not found.\n", pNLName);
           TRACE(1, "See documentation for procedures to either create %s \n", pNLName);
           TRACE(1, "if shared queue support is not needed, or to create name list %s \n", newDupName);
           TRACE(1, "if shared queue support is needed. \n");
           return 8;
       }
 
       /* Check whether old divert namelist exists with QSGDISP(QMGR) */
       /* If not, write error                                         */
       pNLName = UC_NL_RIT[DIVERT];
       sprintf(buffer, "DISPLAY NAMELIST(%s) QSGDISP(QMGR) ALTDATE",pNLName);
       memset(rspBuffer,0,sizeof(rspBuffer));
       rc = sendAdminCmd((MQLONG)strlen(buffer), (MQBYTE*)buffer, hConn, p,
                (MQLONG)sizeof(rspBuffer), (MQBYTE *)rspBuffer, 3);
       TRACE(1, "command: %s \n",buffer);
       TRACE(1, "response: %s \n",rspBuffer);
       TRACE(1, "response: %i \n",strstr(rspBuffer,"ALTDATE("));
       /* If not, write error and exit                                */
       if (strstr(rspBuffer,"ALTDATE(")==0) {
           TRACE(1, "Error. Name list (%s) not found.\n", pNLName);
           TRACE(1, "See documentation for procedures to either create %s \n", pNLName);
           TRACE(1, "if shared queue support is not needed, or to create name list %s \n", newDivName);
           TRACE(1, "and name list %s if shared queue support is needed. \n", newDupName);
           return 8;
       }
 
       /* set suffix to empty string                                  */
       memcpy(&p->nlSuffix[0], "", 1);
   }
 
   return 0;
}
 
 
long delNamelist(char* pNamelist, MQHCONN hConn, Userparm * p){
    char buffer[256] = {0};
    char rspBuffer[256] = {0};
    sprintf(buffer, "DELETE NAMELIST('%s')", pNamelist);
    int rc = sendAdminCmd((MQLONG)strlen(buffer), (MQBYTE*)buffer, hConn, p,
             (MQLONG)sizeof(rspBuffer), (MQBYTE *)rspBuffer, 3);
    TRACE(1, "Send command for delete namelist: %s \n return code: %d\n", buffer, rc);
    return rc;
}
 
/* define namelist('RIT.DIVERT.RULES') names(NLA,NLB) replace */
/* long replNamelist(int number, MQBYTE * msgCmd, int typeIn,
        MQHCONN hConn, Userparm * p) { */
long replNamelist(int number, MQBYTE * msgCmd, char* pNamelist,
        MQHCONN hConn, Userparm * p) {
    char* pBuff = (char*)malloc(128 + number * NL_ENT_LENGTH);
    char rspBuffer[256];
    if (pBuff == 0) {
        TRACE(0, "unable to allocate storage for pBuff\n");
        return 8;
    }
    /* char* pName; */
    long rc = 0;
    /*
    if(typeIn == DUP){
        pName = RIT_DUP_NL;
    }else{
        pName = RIT_DIVERT_NL;
    }
    */
    char* pCurr = msgCmd;
    if(number > 0){
        sprintf(pBuff, "DEFINE NAMELIST('%s') NAMES(", pNamelist);
        char buffer[64] = {0};
        __snprtf(buffer, NL_ENT_LENGTH, "%s", pCurr);
        strcat(pBuff, buffer);
        pCurr += NL_ENT_LENGTH;
        for(int i = 1; i < number; i++, pCurr += NL_ENT_LENGTH){
             __snprtf(buffer, 49, ",%s", pCurr);
             strcat(pBuff, buffer);
        }
        sprintf(buffer, ") REPLACE");
        strcat(pBuff, buffer);
    }else{
        sprintf(pBuff, "DEFINE NAMELIST('%s') NAMES() REPLACE", pNamelist);
    }
    TRACE(1, "Sending command for replace namelist: <%s>\n", pBuff, rc);
    rc = sendAdminCmd((MQLONG)strlen(pBuff), (MQBYTE*)pBuff, hConn, p,
             (MQLONG)sizeof(rspBuffer), (MQBYTE *)rspBuffer, 3);
    TRACE(1, "return code of replace namelist is: %d\n", rc);
    FREE(pBuff);
    return rc;
}
 
long sendAdminCmd(MQLONG msgLen, MQBYTE * msgCmd,
		MQHCONN hConn, Userparm * p, MQLONG rspLen, MQBYTE * rsp, int rspMsgs) {
 
	if (rspLen==0) {
	    /* add error message here */
		return -1;
	}
 
    MQOD odAdmin = { MQOD_DEFAULT };
    MQOD odReply = { MQOD_DEFAULT };
    MQMD md = { MQMD_DEFAULT };
    MQPMO pmo = { MQPMO_DEFAULT };
    MQGMO gmo = { MQGMO_DEFAULT };
 
    MQHOBJ hAdminQ; /* handle to admin queue */
    MQHOBJ hReplyQ; /* handle to command reply queue */
    MQLONG cc, rc;
 
    odAdmin.ObjectType = MQOT_Q;
    strncpy(odAdmin.ObjectName, SYS_CMD_QUEUE, MQ_Q_NAME_LENGTH);
    MQOPEN(hConn, /* connection handle */
    &odAdmin, /* object descriptor for queue */
    MQOO_OUTPUT, /* open options */
    &hAdminQ, /* object handle */
    &cc, /* MQOPEN completion code */
    &rc); /* reason code */
    /* report reason, if any; stop if failed */
    TRACE(1, "MQOPEN for %s ended with Reason Code %d and Comp Code %d\n",
           odAdmin.ObjectName, rc, cc);
    if (rc != MQRC_NONE) {
        return (-1);
    }
 
    odReply.ObjectType = MQOT_Q;
    strncpy(odReply.ObjectName, SYS_REPLY_QUEUE, MQ_Q_NAME_LENGTH);
    MQOPEN(hConn, /* connection handle */
    &odReply, /* object descriptor for queue */
    MQOO_INPUT_SHARED, /* open options */
    &hReplyQ, /* object handle */
    &cc, /* MQOPEN completion code */
    &rc); /* reason code */
    /* report reason, if any; stop if failed */
    char replyQueue[49] = {0};
    strncpy(replyQueue, odReply.ObjectName, NL_ENT_LENGTH);
    trimBlank(replyQueue);
    if (rc != MQRC_NONE) {
        TRACE(1, "MQOPEN for %s ended with Reason Code %d and Comp Code %d\n",
                  replyQueue, rc, cc);
        MQCLOSE(hConn, &hAdminQ, MQCO_NONE, /* close options       */
                          &cc, &rc);
        return (-1);
    } else {
        TRACE(1, "Got admin reply queue: %s.\n", replyQueue);
    }
 
    /* setup the message descriptor prior to putting the message */
    md.MsgType = MQMT_REQUEST;
    md.Report = MQRO_NONE;
    md.Expiry = MQEI_UNLIMITED;
    md.Feedback = MQFB_NONE;
    md.Encoding = MQENC_NATIVE;
    md.Priority = MQPRI_PRIORITY_AS_Q_DEF;
    md.Persistence = MQPER_PERSISTENCE_AS_Q_DEF;
    memcpy(md.Format, MQFMT_STRING, sizeof(md.Format));
    /* Copy the dynamic queue name to reply queue name */
    memcpy(md.ReplyToQ, replyQueue, sizeof(md.ReplyToQ));
    TRACE(1, "Using reply queue:<%s>\n", replyQueue);
    /* reset MsgId and CorrelId to get a new one */
    memcpy(md.MsgId, MQMI_NONE, sizeof(md.MsgId));
    memcpy(md.CorrelId, MQCI_NONE, sizeof(md.CorrelId));
    pmo.Options = pmo.Options + MQPMO_NO_SYNCPOINT;
 
    TRACE(1, "MQPUT to admin queue:<%s>\n", msgCmd);
    MQPUT(hConn, /* connection handle */
        hAdminQ, /* object handle */
        &md, /* message descriptor */
        &pmo, /* default options */
        msgLen, /* message length */
        msgCmd, /* message buffer */
        &cc, /* completion code */
        &rc); /* reason code */
 
    TRACE(1, "MQPUT ended with Reason Code %d and Comp Code %d\n", rc, cc);
    if (rc != MQRC_NONE) {
        MQCLOSE(hConn, &hAdminQ, MQCO_NONE, /* close options       */
                         &cc, &rc);
        MQCLOSE(hConn, &hReplyQ, MQCO_DELETE_PURGE, /* close options       */
                         &cc, &rc);
        return (-1);
    }
 
    int rspNum = 1;
    char buffer[256] = {0};
    while(rspNum <= rspMsgs) {
        MQLONG msglen = 0;
        gmo.Options = MQGMO_WAIT + MQGMO_NO_SYNCPOINT;
        gmo.WaitInterval = 15000;
        /* reset MsgId and CorrelId to get a new one */
        memcpy(md.MsgId, MQMI_NONE, sizeof(md.MsgId));
        memcpy(md.CorrelId, MQCI_NONE, sizeof(md.CorrelId));
        MQGET(hConn, /* connection handle */
                 hReplyQ, /* object handle */
                 &md, /* message descriptor */
                 &gmo, /* get message options */
                 256, /* Buffer length */
                 (MQBYTE *)buffer, /* message buffer */
                 &msglen, /* message length */
                 &cc, /* completion code */
                 &rc); /* reason code */
        TRACE(1, "MQGET ended with Reason Code %d and Comp Code %d\n",
                 rc, cc);
        if (rc != MQRC_NONE) {
            if(rc = MQRC_NO_MSG_AVAILABLE){
                rc = 0;
            }
            break;
        }else{
             TRACE(1, "MQGET from reply queue: msglen=%d, message=<%s>\n",
                     msglen, buffer);
             TRACE(1, "rspLen is %d\n",rspLen-1);
             /* Throw away the first reply message */
             if (rspNum==1) {
                 strcpy(rsp,"");
             }
             /* Keep second through second to last reply messages */
             if ((rspNum>1)&(rspNum<rspMsgs)) {
                 strncat(rsp,buffer,msglen);
                 strcat(rsp,"");
             }
             rspNum ++;
        }
    }
 
    MQCLOSE(hConn, &hAdminQ, MQCO_NONE, /* close options       */
            &cc, &rc);
    TRACE(1, "MQCLOSE admin queue got Reason Code %d and Comp Code %d\n",
            cc, rc);
    MQCLOSE(hConn, &hReplyQ, MQCO_DELETE_PURGE, /* close options       */
            &cc, &rc);
    TRACE(1, "MQCLOSE reply queue got Reason Code %d and Comp Code %d\n",
            cc, rc);
    return rc;
}
 
long removeRule(Exitrule ruleArray[], int *ruleCnt, char compStr[]) {
    long rc=0;
    int foundRule=0;
    int compLen=3*NL_ENT_LENGTH;
    char tempStr[compLen+1];
 
    for (int i=0; i<=*ruleCnt; ++i) {
        /* pad with blanks up to length of name list entry (48 bytes) */
        snprintf(tempStr,sizeof(tempStr),"%-48s%-48s%-48s",ruleArray[i].inQueue,ruleArray[i].outQueue,
            ruleArray[i].ruleQmgr);
        if (strncmp(compStr,tempStr,compLen)==0) {
            foundRule=1;
        }
        if (foundRule==1) {
            if (i<*ruleCnt) {
                memcpy(&ruleArray[i], &ruleArray[i+1], sizeof(Exitrule));
            } else {
                memset(&ruleArray[i], 0, sizeof(Exitrule));
            }
        }
    }
    if (foundRule==0) {
        rc=12;
    } else {
        --(*ruleCnt);
    }
    return rc;
}
 
/* save dup rules to exit name list */
long saveDupRulesToNL(Exitrule authRules[], int *authCnt, MQHCONN hConn, Userparm * p) {
 
    char authNames[MQNC_MAX_NAMELIST_NAME_COUNT*(2+NL_ENT_LENGTH)+1]={0};
    char userIdNlEnt[NL_ENT_LENGTH+1];
    char ruleTypNlEnt[NL_ENT_LENGTH+1];
 
    TRACE(1, "Number of auth rules (starting from 1): %i\n",1+*authCnt);
    for (int i=0; i<=*authCnt; ++i) {
        if (strncmp(authRules[i].ruleType,"DUPLICATE",9)==0) {
            TRACE(1, "Found auth dup rule for %s\n",authRules[i].inQueue);
            strncat(authNames,authRules[i].inQueue,NL_ENT_LENGTH);
            strncat(authNames,authRules[i].outQueue,NL_ENT_LENGTH);
            strncat(authNames,authRules[i].ruleQmgr,NL_ENT_LENGTH);
        }
    }
    TRACE(1, "authNames: %s\n",authNames);
    long rc = replNamelist((1 + *authCnt) * 3, authNames,
             EXIT_DUP_NL, hConn, p);
    if(rc == 0){
         TRACE(1, "Replace DUP exit namelist successfully.\n");
    }else{
         TRACE(1, "Replace DUP exit namelist failed.\n");
    }
}
 
/* save div rules to exit name list */
long saveDivRulesToNL(Exitrule authRules[], int *authCnt, MQHCONN hConn, Userparm * p) {
 
    char * pNLName;
    char authNames[MQNC_MAX_NAMELIST_NAME_COUNT*(2+NL_ENT_LENGTH)+1]={0};
    char userIdNlEnt[NL_ENT_LENGTH+1];
    char ruleTypNlEnt[NL_ENT_LENGTH+1];
    int  maxNames=MQNC_MAX_NAMELIST_NAME_COUNT;
    int  maxRules=maxNames/2;
    int  numDivRules=0;
    int  writeCount=0;
 
    TRACE(1, "Number of auth rules (starting from 1): %i\n",1+*authCnt);
    pNLName=EXIT_DIV_NL1;
    for (int i=0; i<=*authCnt; ++i) {
        if (strncmp(authRules[i].ruleType,"DIVERT",6)==0) {
            numDivRules++;
            writeCount+=2;
            TRACE(1, "Found auth rule for %s\n",authRules[i].inQueue);
            strncat(authNames,authRules[i].inQueue,NL_ENT_LENGTH);
            strncat(authNames,authRules[i].outQueue,NL_ENT_LENGTH);
            if (numDivRules==maxRules) {
                TRACE(1, "authNames: %s\n",authNames);
                long rc = replNamelist(writeCount, authNames,
                         pNLName, hConn, p);
                if(rc == 0){
                     TRACE(1, "Replace DIVERT1 exit namelist successful.\n");
                }else{
                     TRACE(1, "Replace DIVERT1 exit namelist failed.\n");
                }
                /* filled up first name list, so write remaining to secnd name list */
                authNames[0]='\0';
                pNLName=EXIT_DIV_NL2;
                writeCount=0;
            }
        }
    }
 
    /* if we filled up the first name list, write remaining rules to the next name list */
    if (writeCount>0) {
        TRACE(1, "authNames: %s\n",authNames);
        long rc = replNamelist(writeCount, authNames,
                 pNLName, hConn, p);
        if(rc == 0){
             TRACE(1, "Replace %s exit namelist successfully.\n",pNLName);
        }else{
             TRACE(1, "Replace %s exit namelist failed.\n",pNLName);
        }
    }
 
    /* if there were no divert rule, clear out both div exit name lists */
    if (numDivRules==0) {
        TRACE(1, "authNames: %s\n",authNames);
        long rc = replNamelist(writeCount, authNames,
                 EXIT_DIV_NL1, hConn, p);
        if(rc == 0){
             TRACE(1, "Replace %s exit namelist successfully.\n",pNLName);
        }else{
             TRACE(1, "Replace %s exit namelist failed.\n",pNLName);
        }
        TRACE(1, "authNames: %s\n",authNames);
        rc = replNamelist(writeCount, authNames,
                 EXIT_DIV_NL2, hConn, p);
        if(rc == 0){
             TRACE(1, "Replace %s exit namelist successfully.\n",pNLName);
        }else{
             TRACE(1, "Replace %s exit namelist failed.\n",pNLName);
        }
    }
}
 
long getDupRulesFromNL(Exitrule authRules[], int *authCnt, MQHCONN hConn, Userparm * p) {
 
    char pNLName[MQ_NAMELIST_NAME_LENGTH+1];
    MQHOBJ hobjNL;
    MQLONG cc;
    MQLONG rc;
    int lInqStorage=0;
    int inqSize=0;
    char * pInqStorage;
    long count = 0;
    long ruleLimit=MQNC_MAX_NAMELIST_NAME_COUNT*2+MQNC_MAX_NAMELIST_NAME_COUNT/3;
 
    long selectors[nNLSelectors] = {
    MQCA_ALTERATION_DATE,
    MQCA_ALTERATION_TIME,
    MQIA_NAME_COUNT,
    MQCA_NAMES };
 
    /* Issue MQOPEN to get name list handle */
    strcpy(pNLName,EXIT_DUP_NL);
    MQOD odNamelist = { MQOD_DEFAULT };
    strncpy(odNamelist.ObjectName, pNLName, sizeof(odNamelist.ObjectName));
    odNamelist.ObjectType = MQOT_NAMELIST;
    MQOPEN(hConn, &odNamelist, MQOO_INQUIRE + MQOO_FAIL_IF_QUIESCING,&hobjNL,
       &cc,&rc);
    TRACE(1, "MQOPEN for namelist %s cc %d rc %d %s\n", pNLName, cc, rc,
             RITMQRC(rc));
    if (cc != 0) {
        CONSOLE(p, RITREFOPEN, pNLName, cc, rc, RITMQRC(rc));
        if (rc == MQRC_UNKNOWN_OBJECT_NAME)
            return 8; /* stop processing */
    }
 
    /* Obtain storage for the name list data */
    inqSize=1;
    lInqStorage=MQ_DATE_LENGTH + MQ_TIME_LENGTH +
          inqSize * lMQCHAR48;
    pInqStorage=(char *) malloc(lInqStorage);
    if (pInqStorage == 0){
        TRACE(0, "unable to allocate %i bytes of storage for %s\n",lInqStorage,EXIT_DUP_NL);
           return 8;
    }
 
    /* Probably won't have enough storage allocated
    to hold all of the entries, so reallocate and try
    again if we receive MQRC_CHAR_ATTRS_TOO_SHORT. */
    for (int iLoop = 0; iLoop < 10; iLoop++) {
        MQINQ(hConn, hobjNL, nNLSelectors, /* selectors */
        selectors, 1, /* one int specified */
        &count, lInqStorage, pInqStorage, &cc, &rc);
        TRACE(1, "MQINQ for namelist %s cc %d rc %d %s\n", pNLName, cc, rc,
                 RITMQRC(rc));
        if (rc == 0)
             break;
        else if (rc == MQRC_CHAR_ATTRS_TOO_SHORT) {
            TRACE(1,"cref: count > inqsize - so reallocate count %d old count %d \n",
                    count, inqSize);
            inqSize = count;
            FREE(pInqStorage);
            lInqStorage = MQ_DATE_LENGTH + MQ_TIME_LENGTH
                    + inqSize * lMQCHAR48;
            pInqStorage = (char *) malloc(lInqStorage);
            if (pInqStorage == 0) {
                TRACE(0, "unable to allocate %i bytes of storage for %s\n",lInqStorage,EXIT_DUP_NL);
                return 8;
            }
        } else {
             CONSOLE(p, RITREFINQ, pNLName, cc, rc, RITMQRC(rc));
             FREE(pInqStorage);
             return 8;
        }
    } /* for  MQINQ loop */
 
    /* Each rule is composed of 3 names. If the number of names is not
       evenly divisible by 3, there is a problem.   */
    long remainder;
    remainder = count % 3; /* integer remainer */
    if (remainder != 0) {
        FREE(pInqStorage);
        TRACE(1, "Number of elements not multiple of 3: %d\n", count);
        CONSOLE(p, RITREFBADNUM, pNLName, count); /*invalid count */
        return 8;
    }
 
    /* Now process the results. We receive the date and time follwed by
       the list of names. All are concatenated together in inqStorage.
       point past the date and time */
    char* pData = pInqStorage + MQ_DATE_LENGTH + MQ_TIME_LENGTH;
    char* pTime = pInqStorage + MQ_DATE_LENGTH;
    TRACE(1, "Namelist %s changed on %10.10s at %8.8s\n", pNLName,
             pInqStorage, pTime);
    TRACE(1, "Namelist %s contains %d entries\n", pNLName, count);
    long entries = count;
    long numRules=entries/3;
    if (numRules>ruleLimit) {
        numRules=ruleLimit;
        TRACE(0, "Only %d rules allowed. Additional rules being ignored.\n",ruleLimit);
    }
    char* pName = pData;
    for (int i = 0; i < numRules; i++) { /* number of entries */
        (*authCnt)++;
        strcpy(authRules[*authCnt].ruleType,"DUPLICATE");
        strncpy(authRules[*authCnt].inQueue,pName,MQ_Q_NAME_LENGTH);
        authRules[*authCnt].inQueue[MQ_Q_NAME_LENGTH]='\0';
        pName+=NL_ENT_LENGTH;
        strncpy(authRules[*authCnt].outQueue,pName,MQ_Q_NAME_LENGTH);
        authRules[*authCnt].outQueue[MQ_Q_NAME_LENGTH]='\0';
        pName+=NL_ENT_LENGTH;
        strncpy(authRules[*authCnt].ruleQmgr,pName,MQ_Q_MGR_NAME_LENGTH);
        authRules[*authCnt].ruleQmgr[MQ_Q_MGR_NAME_LENGTH]='\0';
        pName+=NL_ENT_LENGTH;
        memset(authRules[*authCnt].userId, '\0', sizeof(authRules[*authCnt].userId)); /* clear it  */
    }
    FREE(pInqStorage);
    return 0;
}
 
long getDivRulesFromNL(Exitrule authRules[], int *authCnt, MQHCONN hConn, Userparm * p) {
 
    char pNLName[MQ_NAMELIST_NAME_LENGTH+1];
    MQHOBJ hobjNL;
    MQLONG cc;
    MQLONG rc;
    int lInqStorage=0;
    int inqSize=0;
    char * pInqStorage;
    long count = 0;
    long ruleLimit=MQNC_MAX_NAMELIST_NAME_COUNT*2+MQNC_MAX_NAMELIST_NAME_COUNT/3;
 
    long selectors[nNLSelectors] = {
    MQCA_ALTERATION_DATE,
    MQCA_ALTERATION_TIME,
    MQIA_NAME_COUNT,
    MQCA_NAMES };
 
    /* We have two name lists to store divert rules, so iterate the
       process once for each of the name lists                      */
    for (int i=1; i<=2; ++i) {
        /* Issue MQOPEN to get name list handle */
        if (i==1) {
            strcpy(pNLName,EXIT_DIV_NL1);
        } else {
            strcpy(pNLName,EXIT_DIV_NL2);
        }
        lInqStorage=0;
        inqSize=0;
        count = 0;
        MQOD odNamelist = { MQOD_DEFAULT };
        strncpy(odNamelist.ObjectName, pNLName, sizeof(odNamelist.ObjectName));
        odNamelist.ObjectType = MQOT_NAMELIST;
        MQOPEN(hConn, &odNamelist, MQOO_INQUIRE + MQOO_FAIL_IF_QUIESCING,&hobjNL,
           &cc,&rc);
        TRACE(1, "MQOPEN for namelist %s cc %d rc %d %s\n", pNLName, cc, rc,
                 RITMQRC(rc));
        if (cc != 0) {
            CONSOLE(p, RITREFOPEN, pNLName, cc, rc, RITMQRC(rc));
            if (rc == MQRC_UNKNOWN_OBJECT_NAME)
                return 8; /* stop processing */
        }
 
        /* Obtain storage for the name list data */
        inqSize=1;
        lInqStorage=MQ_DATE_LENGTH + MQ_TIME_LENGTH +
              inqSize * lMQCHAR48;
        pInqStorage=(char *) malloc(lInqStorage);
        if (pInqStorage == 0){
            TRACE(0, "unable to allocate %i bytes of storage for %s\n",lInqStorage,pNLName);
               return 8;
        }
 
        /* Probably won't have enough storage allocated
        to hold all of the entries, so reallocate and try
        again if we receive MQRC_CHAR_ATTRS_TOO_SHORT. */
        for (int iLoop = 0; iLoop < 10; iLoop++) {
            MQINQ(hConn, hobjNL, nNLSelectors, /* selectors */
            selectors, 1, /* one int specified */
            &count, lInqStorage, pInqStorage, &cc, &rc);
            TRACE(1, "MQINQ for namelist %s cc %d rc %d %s\n", pNLName, cc, rc,
                     RITMQRC(rc));
            if (rc == 0)
                 break;
            else if (rc == MQRC_CHAR_ATTRS_TOO_SHORT) {
                TRACE(1,"cref: count > inqsize - so reallocate count %d old count %d \n",
                        count, inqSize);
                inqSize = count;
                FREE(pInqStorage);
                lInqStorage = MQ_DATE_LENGTH + MQ_TIME_LENGTH
                        + inqSize * lMQCHAR48;
                pInqStorage = (char *) malloc(lInqStorage);
                if (pInqStorage == 0) {
                    TRACE(0, "unable to allocate %i bytes of storage for %s\n",lInqStorage,pNLName);
                    return 8;
                }
            } else {
                 CONSOLE(p, RITREFINQ, pNLName, cc, rc, RITMQRC(rc));
                 FREE(pInqStorage);
                 return 8;
            }
        } /* for  MQINQ loop */
 
        /* Each rule is composed of 2 names. If the number of names is not
           evenly divisible by 2, there is a problem.   */
        long remainder;
        remainder = count % 2; /* integer remainer */
        if (remainder != 0) {
            FREE(pInqStorage);
            TRACE(1, "Number of elements not multiple of 2: %d\n", count);
            CONSOLE(p, RITREFBADNUM, pNLName, count); /*invalid count */
            return 8;
        }
 
        /* Now process the results. We receive the date and time follwed by
           the list of names. All are concatenated together in inqStorage.
           point past the date and time */
        char* pData = pInqStorage + MQ_DATE_LENGTH + MQ_TIME_LENGTH;
        char* pTime = pInqStorage + MQ_DATE_LENGTH;
        TRACE(1, "Namelist %s changed on %10.10s at %8.8s\n", pNLName,
                 pInqStorage, pTime);
        TRACE(1, "Namelist %s contains %d entries\n", pNLName, count);
        long entries = count;
        long numRules=entries/2;
        if (numRules>ruleLimit) {
            numRules=ruleLimit;
            TRACE(0, "Only %d rules allowed. Additional rules being ignored.\n",ruleLimit);
        }
        char* pName = pData;
        for (int i = 0; i < numRules; i++) { /* number of entries */
            (*authCnt)++;
            strcpy(authRules[*authCnt].ruleType,"DIVERT");
            strncpy(authRules[*authCnt].inQueue,pName,MQ_Q_NAME_LENGTH);
            authRules[*authCnt].inQueue[MQ_Q_NAME_LENGTH]='\0';
            pName+=NL_ENT_LENGTH;
            strncpy(authRules[*authCnt].outQueue,pName,MQ_Q_NAME_LENGTH);
            authRules[*authCnt].outQueue[MQ_Q_NAME_LENGTH]='\0';
            pName+=NL_ENT_LENGTH;
            memset(authRules[*authCnt].ruleQmgr, '\0', sizeof(authRules[*authCnt].ruleQmgr)); /* clear it  */
            memset(authRules[*authCnt].userId, '\0', sizeof(authRules[*authCnt].userId)); /* clear it  */
        }
        FREE(pInqStorage);
    }
    return 0;
}
 
int  verifyAuth(short userIdLen,char userId[],short classLen,char class[],short entityLen,char entity[],short attr,
    char qmgrProfPfx[],char qsgProfPfx[],char secClasPfx[],Userparm * p) {
 
    /* The following statements are for unit testing. This
       assumes that the profile being tested exists for
       QM01.                                                */
 
    /* stand alone qmgr, MQQUEUE profile exists             */
    /* strcpy(qsgProfPfx,"N/A");
       strcpy(qmgrProfPfx,"QM01"); */
    /* stand alone qmgr, MQQUEUE profile does not exist     */
    /* strcpy(qsgProfPfx,"N/A");
       strcpy(qmgrProfPfx,"QX01"); */
    /* qsg, only qsg level checks, MQQUEUE profile exists   */
    /* strcpy(qsgProfPfx,"QM01");
       strcpy(qmgrProfPfx,"N/A"); */
    /* qsg, only qsg level checks, MQQUEUE profile does
       not exist                                            */
    /* strcpy(qsgProfPfx,"QX01");
       strcpy(qmgrProfPfx,"N/A"); */
    /* qsg, both qmgr and qsg checks, MQQUEUE profile for
       qmgr exists                                          */
    /* strcpy(qsgProfPfx,"QX01");
       strcpy(qmgrProfPfx,"QM01"); */
    /* qsg, both qmgr and qsg checks, MQQUEUE profile for
       qmgr does not exist                                  */
    /* strcpy(qsgProfPfx,"QM01");
       strcpy(qmgrProfPfx,"QX01"); */
    /* qsg, both qmgr and qsg checks, MQQUEUE profile for
       qmgr does not exist, MQQUEUE profile for qsg does
       not exist                                            */
    /* strcpy(qsgProfPfx,"QX01");
       strcpy(qmgrProfPfx,"QX01");                          */
    /* Neither qmgr nor qsg                                 */
    /* strcpy(qsgProfPfx,"N/A");
       strcpy(qmgrProfPfx,"N/A"); */
 
    int rc;
    int qmgrRc;
    int qmgrGrpRc;
    int qsgRc;
    int numChecks=0;
    char profPfx[5];
    char hlqEntity[58];
    char gClass[9];
    short gClassLen=classLen+1;
    short traceLevel=TRACEP;
 
    /* Each of the following scenarios require a check of a
       single MQQUEUE profile, and if that fails, a check of
       a group profile:
 
       a) stand alone qmgr
       b) qmgr in qsg with only qmgr level security
       c) qmgr in qsg with only qsg level security
 
       The only difference between these scenarios is the
       profile prefix to be used.                              */
 
    if ((strcmp(qmgrProfPfx,"N/A")!=0) & (strcmp(qsgProfPfx,"N/A")==0)) {
        strcpy(profPfx,qmgrProfPfx);
        numChecks=1;
    }
    if ((strcmp(qmgrProfPfx,"N/A")==0) & (strcmp(qsgProfPfx,"N/A")!=0)) {
        strcpy(profPfx,qsgProfPfx);
        numChecks=1;
    }
 
    if (numChecks==1) {
        memset(hlqEntity, '\0', sizeof(hlqEntity)); /* clear it  */
        strcpy(hlqEntity,profPfx);
        strcat(hlqEntity,entity);
        TRACE(1, "Entity including hlq: %s\n", hlqEntity);
        TRACE(1, "Checking authority for: %s %s\n", profPfx,class);
        entityLen=entityLen+strlen(profPfx);
        rc=hrvmracr(&userIdLen,userId,&classLen,class,&entityLen,hlqEntity,&attr,&traceLevel);
        TRACE(1,"Auth check rc is %i\n",rc);
 
        /* If access is not granted via a "non-group" profile, */
        /* attempt another check using a group profile class.  */
        if (rc!=0) {
            strcpy(gClass,"G");
            strcat(gClass,class);
            TRACE(1, "Checking authority for: %s %s\n", profPfx,gClass);
            rc=hrvmracr(&userIdLen,userId,&gClassLen,gClass,&entityLen,hlqEntity,&attr,&traceLevel);
            TRACE(1,"Auth check rc is %i\n",rc);
            return rc;
        } else {
            return rc;
        }
    }
 
    /* The remaining scenario is for a qmgr in a qsg with
       both qsg security and qmgr security active. In this
       case, checks are made for the qmgr level profiles
       (both MQQUEUE and GMQQUEUE), and if no profiles are
       found, the same checks are done for the QSG level
       profiles. */
 
    if ((strcmp(qmgrProfPfx,"N/A")!=0) & (strcmp(qsgProfPfx,"N/A")!=0)) {
        /* first try at the qmgr level */
        strcpy(profPfx,qmgrProfPfx);
        memset(hlqEntity, '\0', sizeof(hlqEntity)); /* clear it  */
        strcpy(hlqEntity,profPfx);
        strcat(hlqEntity,entity);
        TRACE(1, "Entity including hlq: %s\n", hlqEntity);
        TRACE(1, "Checking authority for: %s %s\n", profPfx,class);
        entityLen=entityLen+strlen(profPfx);
        qmgrRc=hrvmracr(&userIdLen,userId,&classLen,class,&entityLen,hlqEntity,&attr,&traceLevel);
        TRACE(1,"Auth check rc is %i\n",qmgrRc);
 
        if (qmgrRc==0) {
            return qmgrRc;
        } else {
        /* If access is not granted via a "non-group" profile, */
        /* attempt another check using a group profile class.  */
            strcpy(gClass,"G");
            strcat(gClass,class);
            TRACE(1, "Checking authority for: %s %s\n", profPfx,gClass);
            qmgrGrpRc=hrvmracr(&userIdLen,userId,&gClassLen,gClass,&entityLen,hlqEntity,&attr,&traceLevel);
            TRACE(1,"Auth check rc is %i\n",qmgrGrpRc);
            if (qmgrGrpRc==0) return qmgrGrpRc;
        }
    }
 
    /* If the checks at the qmgr level indicated that no
       profile was found (RC=10 from hrvmracr), try the
       same checks at the QSG level.                     */
    if ((qmgrRc==10) & (qmgrGrpRc==10)) {
        /* now try at the qsg level */
        strcpy(profPfx,qsgProfPfx);
        memset(hlqEntity, '\0', sizeof(hlqEntity)); /* clear it  */
        strcpy(hlqEntity,profPfx);
        strcat(hlqEntity,entity);
        TRACE(1, "Entity including hlq: %s\n", hlqEntity);
        entityLen=entityLen+strlen(profPfx);
        TRACE(1, "Checking authority for: %s %s\n", profPfx,class);
        qsgRc=hrvmracr(&userIdLen,userId,&classLen,class,&entityLen,hlqEntity,&attr,&traceLevel);
        TRACE(1,"Auth check rc is %i\n",qsgRc);
 
        if (qsgRc==0) {
            return qsgRc;
        } else {
        /* If access is not granted via a "non-group" profile, */
        /* attempt another check using a group profile class.  */
            strcpy(gClass,"G");
            strcat(gClass,class);
            TRACE(1, "Checking authority for: %s %s\n", profPfx,gClass);
            qsgRc=hrvmracr(&userIdLen,userId,&gClassLen,gClass,&entityLen,hlqEntity,&attr,&traceLevel);
            TRACE(1,"Auth check rc is %i\n",qsgRc);
            if (qsgRc==0) return qsgRc;
        }
    }
 
    /* If we get to this point, neither qmgr nor qsg security
       is enabled. */
    TRACE(1,"verifyAuth has been called, but security is not enabled.\n");
    return 12;
}
 
long refresh(Userparm * p,MQHCONN hConn,Exitrule unauthRules[],int *unauthCnt,Exitrule authRules[],int *authCnt,
    char qmgrProfPfx[],char qsgProfPfx[],char secClasPfx[]) {
    long rc = duplicat(p,hConn,unauthRules,unauthCnt,authRules,authCnt,qmgrProfPfx,qsgProfPfx,secClasPfx);
    if(rc > 4){
        return rc;
    }
    return divertrf(p,hConn,unauthRules,unauthCnt,authRules,authCnt,qmgrProfPfx,qsgProfPfx,secClasPfx);
}
