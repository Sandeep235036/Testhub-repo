/***********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2001, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2019. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
***********************************************************************/
 
#pragma  linkage(RITMSG,fetchable)
#include <ritcom.h>
 
char * RITMSG(long msgid)
{
    
    
    char * p = "return from ritmsg\n";
    
    if ( msgid ==  RITPRODUCT) p="RIT100I Rational Integration Tester for z/OS.  Component 5725G79IT\n";
    /* hardcoded RIT001S load of message module RITMSG failed   */
    /* hardcoded RIT002I Abnormal end detected            */
    /* hardcoded RIT003I Clean up successful                    */
    /* hardcoded 'RIT004I Recovery routine entered'             */
    /* hardcoded 'RIT005S RIT Error recovery routine: RIT now inactive'        */
    else if ( msgid ==  RITMQFLEVEL)     p="RIT010I LPA module information %s\n";
/* parameter checking */    
    else if ( msgid ==  RITPARMNONE)     p="RIT100E Required parameter is missing QM(aaaa)\n";
    else if ( msgid ==  RITPARMBADQM)    p="RIT101E Invalid QM(value) specified. Where value should be a string of length 1-4 characters\n";
    else if ( msgid ==  RITPARMBADTRACE) p="RIT102E Invalid TRACE(value) specified. Value should be a number in range 0-9\n";
    else if ( msgid ==  RITPARMUNKNOWN)  p="RIT103E Unknown parameter %s, ignored\n";
    else if ( msgid ==  RITPARMMQ)       p="RIT104I Queue Manager:%4.4s\n";
    else if ( msgid ==  RITPARMTRACE)    p="RIT105I Trace:%d\n";
    else if ( msgid ==  RITWRONGMQ  )    p="RIT106E Unsupported level of MQ %d\n";
    else if ( msgid ==  RITBADETCON  )   p="RIT107E Return codes from ETCON %d %8.8x %8.8x %8.8x %8.8x\n";
    else if ( msgid ==  RITINQQMQR   )   p="RIT108E MQOPEN of QMGR for Inquire gave cc %d rc %d %s\n";
    else if ( msgid ==  RITDIAGNOSIS )   p="RIT109I RIT diagnosis set to %d\n";
 
 
    else if ( msgid == RITMQCONNERROR)   p="RIT110E MQCONN to %s cc %d rc %d %s\n";
    else if ( msgid == RITMQOPENERROR)   p="RIT111E MQOPEN for %s cc %d rc %d %s\n";
    else if ( msgid == RITMQGETERROR)    p="RIT112E MQGET from %s cc %d rc %d %s\n";
    else if ( msgid == RITMQQSGNAME)     p="RIT113I Queue Sharing Group: %4.4s\n";
    else if ( msgid == RITMQQSGERR)      p="RIT114E Error encountered while querying Queue Sharing Group name.\n";
    else if ( msgid == RITMQNOSHRQ)      p="RIT115I Queue sharing namelists not found. Shared queue support disabled.\n";
    else if ( msgid == RITMQNONL)        p="RIT116E Required namelists not found. Unable to continue.\n";
    else if ( msgid == RITMQDISSEC)      p="RIT117E Unable to obtain QMGR security settings. Unable to continue.\n";
    else if ( msgid == RITMQAUTHCHK)     p="RIT118I Queue authorization checks are %s\n";                           
 
    else if ( msgid == RITMQCONNHELP)    p="RIT120I You need to setup MQ RACF wizard for RIT.\n";
 
 
        /* RITSASM return codes */
    else if ( msgid == RITAPF)           p="RIT201E %s is not APF authorised\n";
    else if ( msgid == RITENQ)           p="RIT202E Unable to get lock - is there an instance running?\n";
    else if ( msgid == RITNOTFOUND)      p="RIT203E Unable to locate HRVMMQF in LPA\n"; /*  CSVQUERY rc = 8*/
    else if ( msgid == RITCSVQUERY)      p="RIT204E CSVQUERY return code %d locating RITMQF in LPA\n";
    else if ( msgid == RITBADSWAP)       p="RIT205E Unable to activate RIT return code %d trace %32.32s\n";
 
    else if ( msgid == RITBADSASM)       p="RIT204S Internal error function %d %8.8s code %d, trace %32.32s\n";
    else if ( msgid ==  RITBADRESGGRADD )p="RIT211E Return codes from RESMGR ADD return code %d trace %32.32s\n";
 
/* show the command entered command */    
    else if ( msgid ==   RITUSERCMD)  p="RIT330I Command:%s\n";
/* display command */    
    else if ( msgid ==  RITDISNONE)  p="RIT300I No queues being monitored:%s\n";
    else if ( msgid ==  RITDISH0  )  p="RIT301I Output from Display command\n";
    else if ( msgid ==  RITDISH1  )  p="Queue Name         %3$*1$.*2$s   successful errors\n";
    else if ( msgid ==  RITDISH2  )  p="  Target Queue Name%3$*1$.*2$s   successful errors\n";
    else if ( msgid ==  RITDISH3  )  p="    Target Queue Manager Name\n";                                                
    else if ( msgid ==  RITDISD1  )  p="%3$*1$.*2$s   %4$7d %5$6d\n";
    else if ( msgid ==  RITDISD2  )  p="  %3$*1$.*2$s %4$7d %5$6d\n";
    else if ( msgid ==  RITDISD3  )  p="    %3$*1$.*2$s\n";
    else if ( msgid ==  RITDISD4  )  p="  MQ Reason code %d, %s at %19.19s\n";
    else if ( msgid ==  RITDISD4I )  p="  Internal error %2.2x\n";
    else if ( msgid ==  RITDISD5  )  p="  Last successful put at %19.19s\n";
    else if ( msgid ==  RITDISD6  )  p="  MQ PMO %X at %19.19s\n";
    else if ( msgid ==  RITDISD7  )  p="  Original Application type %4.4Xn";
    else if ( msgid ==  RITDISD8  )  p="  Original Application name %28.28s\n";
    else if ( msgid ==  RITDISSTOR)  p="RIT307E Unable to allocate storage - display command failed, length %u\n";
    else if ( msgid ==  RITDISDNOMD) p="RIT311E MQMD missing from MQPUT/1 request\n";
    else if ( msgid ==  RITDISBADPMO) p="RIT312E Unsupported PMO used\n";
    else if ( msgid ==  RITDISSTORAGE ) p="RIT321E Problem allocating storage during intercept request\n";
    else if ( msgid ==  RITDISNONE2 ) p="RIT322I No records found matching request\n";
    else if ( msgid ==  RITACTIVE )   p="RIT331I RIT interception is active\n";
    else if ( msgid ==  RITINACTIVE ) p="RIT332W RIT interception is inactive\n";
    else if ( msgid ==  RITDISDUPL ) p="RIT350I Duplicate data on queues\n";
    else if ( msgid ==  RITDISDIVERT) p="RIT351I Divert data\n";
 
        /* refresh */
    else if ( msgid == RITREFOPEN)       p="RIT400S MQOPEN for namelist %s cc %d rc %d %s\n";
    else if ( msgid == RITREFINQ)        p="RIT401S MQINQ for Namelist %s cc %d rc %d %s\n";
    else if ( msgid == RITREFINQNO)      p="RIT402W No entries in name list %s\n";
    else if ( msgid == RITREFBADNUM)     p="RIT403E Namelist %s has invalid number of entries %d\n";
    else if ( msgid == RITREFOKDT)       p="RIT404I Refresh %s list successful using list from %10.10s at %8.8s\n";
    else if ( msgid == RITREFONOTDT)     p="RIT405E Refresh %s list unsuccessful rc %8.8x\n";
    else if ( msgid == RITREFBADQA)      p="RIT407E Refresh %s list unsuccessful rc %8.8x\n";
    else if ( msgid == RITBADBASE64)     p="RIT410E Unable to decode character %c in string %48.48s in namelist\n";
    else if ( msgid == RITBADDIVERTNL)   p="RIT411E Invalid records in divert namelist %.48s\n";
        /* operator command processing  */
        else if ( msgid == RITCMD)           p="RIT450E Internal error processing command %d %8.8x\n"; /* RC2, flags  */
        else if ( msgid == RITBADCMD)        p="RIT451E Unknown command %s\n";
    
        
    else p     = "";
    return p;
    
}
 
