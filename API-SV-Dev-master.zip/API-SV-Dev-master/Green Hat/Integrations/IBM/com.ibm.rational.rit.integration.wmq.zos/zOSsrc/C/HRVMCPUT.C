#pragma csect(code,"HRVMCPUT")
#pragma csect(static,"HRVMCPCS")
/***********************************************************************
* Licensed Materials - Property of IBM and/or HCL
* (c) Copyright IBM Corporation 2001, 2016. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2019. All Rights Reserved.
*
* Note to U.S. Government Users Restricted Rights:
* Use, duplication or disclosure restricted by GSA ADP Schedule
* Contract with IBM Corp.
***********************************************************************/
 
#include "ritcom.h"
#include "stdio.h"
 
void trimJCLParm( char* workStr );
void formatMQMsg( char* msgStr, MQLONG CC, MQLONG RC );
void printUsage();
int MAX_JCL_LRECL=80;
 
int main( int argc, char** argv )
{
    MQHCONN hConn = MQHC_DEF_HCONN;
    MQHOBJ hComQ;
    MQMD md = { MQMD_DEFAULT };
    MQOD odComQ = { MQOD_DEFAULT };
    MQPMO pmoComQ = { MQPMO_DEFAULT };
    MQLONG cc;
    MQLONG MQrc;
    char qMgr[MQ_Q_MGR_NAME_LENGTH+1];
    char qName[MQ_Q_NAME_LENGTH+1];
    int msgCnt = 1;
    char toQ[MQ_Q_NAME_LENGTH+1];
    char fromQ[MQ_Q_NAME_LENGTH+1];
    char cmdQ[MQ_Q_NAME_LENGTH+1]="                                                ";
    char func[4];
    char delim[2]=",";
    char *buffer;
    int lMsg = 159;
    int rc=0;
    FILE *sysin;
 
    memset( qMgr,  '\0', MQ_Q_MGR_NAME_LENGTH+1 );
    memset( qName, '\0', MQ_Q_NAME_LENGTH+1 );
 
    /* Obtain parameters frm the SYSIN DD statement */
    if ((sysin = fopen("DD:SYSIN","rb")) == NULL) {
        printf("Error: Unable to open SYSIN DD statement\n");
        printUsage();
        return 8;
    }
 
    int foundQM=0;
    int foundToQ=0;
    int foundFromQ=0;
    int foundFunc=0;
    int foundCmQ=0;
    int numRecordsRead=1;
    char pData[MAX_JCL_LRECL+1];
    while (fread(pData, 1, MAX_JCL_LRECL, sysin)>0) {
        pData[MAX_JCL_LRECL]='\0';
        trimJCLParm(pData);
        if (memcmp(pData, "QM(", 3) == 0) {
            memset( qMgr, ' ', MQ_Q_MGR_NAME_LENGTH );
            qMgr[MQ_Q_NAME_LENGTH]='\0';
            long lString = strlen(&pData[3]) - 1; /* ignore trailing ) */
            if (lString < 1 || lString > 4) {
                printf("Error. Queue Manager name must be between 1 and 4 characters.\n");
                printf("\n");
                printUsage();
                if (rc < 8) {
                    rc = 8;
                }
            } else {
                strncpy(qMgr,&pData[3], lString);
                foundQM=1;
            }
        } else if (memcmp(pData, "TO(", 3) == 0) {
            memset( toQ, ' ', MQ_Q_MGR_NAME_LENGTH );
            toQ[MQ_Q_NAME_LENGTH]='\0';
            long lString = strlen(&pData[3]) - 1; /* ignore trailing ) */
            if (lString < 1 || lString > 48) {
                printf("Error. You must specify a valid destination queue name.\n");
                printf("\n");
                printUsage();
                if (rc < 8) {
                    rc = 8;
                }
            } else {
                strncpy(toQ,&pData[3], lString);
                foundToQ=1;
            }
        } else if (memcmp(pData, "FROM(", 5) == 0) {
            memset( fromQ, ' ', MQ_Q_MGR_NAME_LENGTH );
            fromQ[MQ_Q_NAME_LENGTH]='\0';
            long lString = strlen(&pData[5]) - 1; /* ignore trailing ) */
            if (lString < 1 || lString > 48) {
                printf("Error. You must specify a valid source queue name.\n");
                printf("\n");
                printUsage();
                if (rc < 8) {
                    rc = 8;
                }
            } else {
                strncpy(fromQ,&pData[5], lString);
                foundFromQ=1;
            }
        } else if (memcmp(pData, "CMQ(", 4) == 0) {
            memset( cmdQ, ' ', MQ_Q_MGR_NAME_LENGTH );
            cmdQ[MQ_Q_NAME_LENGTH]='\0';
            long lString = strlen(&pData[4]) - 1; /* ignore trailing ) */
            if (lString < 1 || lString > 48) {
                printf("Error. You must specify either COM.GREENHAT.COMMAND.QUEUE\n");
                printf("       or COM.GREENHAT.COMMAND.QUEUE.xxxx, where xxxx is the QMGR name.\n");
                printf("\n");
                printUsage();
                if (rc < 8) {
                    rc = 8;
                }
            } else {
                strncpy(cmdQ,&pData[4], lString);
                foundCmQ=1;
            }
        } else if (memcmp(pData, "FUNC(", 5) == 0) {
            strcpy(func,"   ");
            if ((memcmp(pData+5, "DUP", 3) != 0)&(memcmp(pData+5, "DIV", 3) != 0)) {
                printf("Error. You must specify a valid function.\n");
                printf("\n");
                printUsage();
                if (rc < 8) {
                    rc = 8;
                }
            } else {
                strncpy(func, &pData[5], 3);
                foundFunc=1;
            }
        }
    }
    fclose(sysin);
 
    printf( "HRVMCPUT started with the following parameters :\n" );
    printf( "   QMGR        - %s\n", qMgr );
    printf( "   FROMQ       - %s\n", fromQ );
    printf( "   TOQ         - %s\n", toQ );
    printf( "   FUNC        - %s\n", func );
    printf( "   CMQ         - %s\n", cmdQ );
    printf( "\n");
 
    if (rc>=8) {
        printUsage;
        return 8;
    }
    if (foundQM+foundToQ+foundFromQ+foundFunc+foundCmQ != 5) {
        printUsage;
        return 8;
    }
 
    /* Allocate memory for message                                    */
    buffer = (char *) malloc(lMsg*sizeof(char));
    if( !buffer ) {
       printf( "Error allocating memory for message buffer\n" );
       printf( "\n" );
       return 8;
    }
 
    /* create message */
    if (strcmp(func,"DUP")==0) strcpy(buffer,"DUPLICATE");
    else strcpy(buffer,"DIVERT");
    strcat(buffer,delim);
    strcat(buffer,fromQ);
    strcat(buffer,delim);
    strcat(buffer,toQ);
    strcat(buffer,delim);
    strcat(buffer,qMgr);
 
    /* Connect to MQ, open the queue, and put the message */
    MQCONN( qMgr,&hConn,&cc,&MQrc);
    if(cc != MQCC_OK)
       {
       formatMQMsg( "MQCONN", cc, MQrc );
       return MQrc;
       }
 
    strncpy( odComQ.ObjectName, cmdQ, MQ_Q_NAME_LENGTH );
    MQOPEN(hConn,&odComQ,MQOO_OUTPUT +MQOO_FAIL_IF_QUIESCING,
            &hComQ,&cc,&MQrc);
    if(cc != MQCC_OK) {
        formatMQMsg( "MQOPEN", cc, MQrc );
        rc = MQrc;
        MQDISC(&hConn,&cc,&MQrc);
        return rc;
    }
    md.Persistence = MQPER_NOT_PERSISTENT;
    strncpy( md.Format, MQFMT_STRING, MQ_FORMAT_LENGTH );
    pmoComQ.Options = MQPMO_FAIL_IF_QUIESCING;
    strncpy( md.MsgId,         MQMI_NONE, MQ_MSG_ID_LENGTH );
    strncpy( md.CorrelId, MQCI_NONE, MQ_CORREL_ID_LENGTH );
 
    MQPUT( hConn,hComQ,&md,&pmoComQ,lMsg,buffer,
           &cc,&MQrc);
    formatMQMsg( "MQPUT", cc, MQrc );
    if(cc != MQCC_OK) {
        rc = MQrc;
        MQDISC(&hConn,&cc,&MQrc);
        return rc;
    }
 
    free( buffer );
 
    /*                                                                */
    /* Close the queue and then disconnect from the queue manager     */
    /*                                                                */
    MQCLOSE( hConn,&hComQ,MQCO_NONE,&cc,&MQrc);
    if(cc != MQCC_OK) {
       formatMQMsg( "MQCLOSE", cc, MQrc );
       rc = MQrc;
    }
 
    MQDISC( &hConn,&cc,&MQrc);
    if(cc != MQCC_OK) {
        formatMQMsg( "MQDISC", cc, MQrc );
        return MQrc;
    }
 
} /*end main*/
 
void trimJCLParm( char* workStr)
{
    int foundNonBlank=0;
    int finalChar = MAX_JCL_LRECL-1; /* Subtract 1 to get index
                                        of last character       */
    while (foundNonBlank == 0) {
        if (isblank(workStr[finalChar])) {
            workStr[finalChar]='\0';
            --finalChar;
        } else {
            foundNonBlank = 1;
        }
    }
}
 
/*********************************************************************/
/* Functions to display error messages                               */
/*********************************************************************/
void formatMQMsg( char* msgStr, MQLONG CC, MQLONG RC )
{
    printf( "\n%s\n", msgStr );
    printf( "Completion code : %09ld\n", CC );
    printf( "Return code     : %09ld\n", RC );
}
 
void printUsage() {
    printf("\n");
    printf("This program is used to verify the MQ Agent for z/OS\n");
    printf("installation. It requires the following parameters to\n");
    printf("be specified in the SYSIN DD statement. Each parameter\n");
    printf("should be specified on a separate line, and each should\n");
    printf("start in column 1\n");
    printf("\n");
    printf("  QM(xxxx)   - where xxxx is the queue manager name.\n");
    printf("  FUNC(xxxx) - where xxxx is either DUP or DIV.\n");
    printf("  FROM(xxxx) - where xxxx is the source queue\n");
    printf("  TO(xxxx)   - where xxxx is the destination queue\n");
    printf("  CMD(xxxx)  - where xxxx is either COM.GREENHAT.COMMAND.QUEUE or\n");
    printf("               COM.GREENHAT.COMMAND.QUEUE.yyyy where yyyy is the QMGR name.\n");
    printf("\n");
}
