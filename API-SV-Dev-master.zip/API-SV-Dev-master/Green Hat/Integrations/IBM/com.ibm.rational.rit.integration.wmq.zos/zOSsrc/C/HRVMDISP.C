/*********************************************************************
 * Licensed Materials - Property of IBM and/or HCL
 * (c) Copyright IBM Corporation 2013, 2016. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2017. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 ********************************************************************/
/* routine to display information about the intercept queues */
/* This routine locates the queue area info and displays     */
/* intercept queue, -> queue, -> QM, flags and last error    */
/*                                                           */

#pragma csect (CODE,"RITDISP")
#pragma csect (STATIC,"RITDISPS")

#include <ritcom.h>

#define TRACEP p -> debugLevel
#define FUNCTION "display"

/* routine to remove trailing blanks from the queue name */
/* so the display is neater                              */
char * QName(char * pIn, /* the input string char[48]*/
char * pOut) /* the output char[49]      */
{
    int zz;
    for (zz = 0; zz < 48; zz++) {
        if (pIn[zz] == ' ')
            break;
        pOut[zz] = pIn[zz];
    }
    pOut[zz] = 0; /*set trailing null             */
    return &pOut[0];
}

/*
 function to display queue info
 */

void display(Userparm * p, long displayRequest) {

    TRACE(2, "Into Display %d\n", displayRequest);
    long displayCount = 0;

    Pcdef * pGlobal;
    pGlobal = p->pGlobal;
    short lWTO;
    long displayHeading = 0;

    /* get our current time and format it */
    struct timeval tvTime;
    struct tm *tmTime;

    int iCount;

    gettimeofday(&tvTime, 0);
    tmTime = gmtime(&(tvTime.tv_sec));
#define countType 2
    printf("  \nTime: %d-%2.2d-%2.2d %2.2d:%2.2d:%2.2d.%6.6ld\n",
            tmTime->tm_year + 1900, tmTime->tm_mon + 1, tmTime->tm_mday,
            tmTime->tm_hour, tmTime->tm_min, tmTime->tm_sec, tvTime.tv_usec);

    QPrefix * pQP;
    if ((pGlobal -> RITFLAGS[0] & 0X80) == 0X80)
        CONSOLE(p, RITACTIVE);
    else
        CONSOLE(p, RITINACTIVE);
    for (int iType = 0; iType < countType; iType++) {
        if (iType == 0)
            pQP = (QPrefix *) (pGlobal->aDuplicateQueues);
        else
            pQP = (QPrefix *) (pGlobal->aDivertQueues);

        if (pQP == 0) {
            TRACE(3, "pQP is 0\n");
            CONSOLE(p, RITDISNONE2);
            continue; /* do the next type */
        }
        /* If we have no records -just say so and return        */
        long count = pQP -> cQueues;
        if (count == 0) {
            char * type[countType] = { "Duplicate", "Divert" };
            CONSOLE(p, RITDISNONE, type[iType]);
            /* No queues being monitored:Duplicate */
            continue;
        }

        /* take a local copy of the data so it doesnt change    */
        /*beneath us while we are processing the data           */
        /* small risk of it changing while we copy it           */
        QPrefix * pLocal;
        TRACE(1, "malloc length %d %d %d\n", pQP -> lQAREAprefix,
                pQP -> cQueues, pQP -> lQueueItem);
        pLocal = (QPrefix *) malloc(pQP -> lQAREAprefix);
        if (pLocal == 0) {
            TRACE(1, "malloc failed length %d %d %d\n", pQP -> lQAREAprefix,
                    pQP -> cQueues, pQP -> lQueueItem);
            CONSOLE(p, RITDISSTOR, pQP -> lQAREAprefix);
            return;
        }

        memcpy(pLocal, pQP, pQP -> lQAREAprefix);
        /* find the maximum length of the queues used, so the formating */
        /* looks good                                                   */
        long blankPos = 1;
        /* set following min length to allow for header spacing */
        long IblankPos = 1; /* input queue blank position */
        long OblankPos = 1; /* output queue blank position */
        long QMblankPos = 1; /* queue manager name blank position  */
        long numberQM = 0; /* how many queue managers to display */
        QArea * pQ = (QArea *) &(pLocal ->QueueRecord[0]);

        for (iCount = 0; iCount < count; iCount++) {
            int k = 0;
            if (displayRequest == dtAll /* display all */
            /* always display errors */
            || pQ->OUTRS != 0 || pQ->INTRC != 0 || pQ->OUTPMO != 0
            /* or queues which have processed messages  */
            || (displayRequest == dtUsed && pQ->INCount > 0)) {
                /* start at previous highest and go up until end or blank */
                /* so IblankPos is maximum length of input queue          */
                /* need to do 48-1 as string is 0  based                  */
                for (; IblankPos < 47; IblankPos++) {
                    if (pQ -> INQUEUE[IblankPos] == ' ')
                        break;
                }

                for (; OblankPos < 47; OblankPos++) {
                    if (pQ -> OUTQUEUE[OblankPos] == ' ')
                        break;
                }

                /* only calculate the length of the MQ we display*/
                if (pQ -> QFLags[0] & NotLocalQM != NotLocalQM)
                    for (; QMblankPos < 47; QMblankPos++) {
                        if (pQ -> OUTQM[QMblankPos] == ' ')
                            break;
                    }

                /* if we ignore local queue manager being us,*/
                /* so count the  non us                      */
                if (pQ -> QFLags[0] & NotLocalQM == NotLocalQM)
                    numberQM++;
                displayCount++;
            }
            pQ += 1; /* point to next queue area   */
        }

        TRACE(2, "Display Count %d\n", displayCount);
        if (displayCount == 0) {
            CONSOLE(p, RITDISNONE2);
            continue;
        }
        /* find the maximum of the 3 object types */
        blankPos = IblankPos;
        if (OblankPos > blankPos)
            blankPos = OblankPos;
        if (QMblankPos > blankPos)
            blankPos = QMblankPos;
        /* blankpos now contains length of the longest name */
        if (blankPos < 23)
            blankPos = 23; /* for headings */

        /* display the headings i required */
        if (displayHeading == 0)
            CONSOLE(p, RITDISH0);
        displayHeading++;

        if (iType == 0)
            CONSOLE(p, RITDISDUPL);
        else
            CONSOLE(p, RITDISDIVERT);

        long headerLength = blankPos - 22;
        CONSOLE(p, RITDISH1, headerLength, headerLength,
                "                               ");
        CONSOLE(p, RITDISH2, headerLength, headerLength,
                "                               ");
        if (numberQM > 0) /* if we need to display queue manager names */
            CONSOLE(p, RITDISH3); /* only display QM if different */

        pQ = (QArea *) &(pLocal ->QueueRecord[0]);
        for (iCount = 0; iCount < count; iCount++) {
            if (displayRequest == dtAll
            /* always display errors */
            || pQ->OUTRS != 0 || pQ->INTRC != 0 || pQ->OUTPMO != 0
            || pQ->ApplType != 0
            || (displayRequest == dtUsed && pQ->INCount > 0)) {
                /*in these console... the blankPos is the length of the string*/
                /*to using in a printf, so instead of %48.48s we use          */
                /*  %3$*1$.*2$s .. so we display the 3rd parm as an s         */
                /* *1 is the length *2 is the width   (both blankPos in size) */
                CONSOLE(p, RITDISD1, blankPos, blankPos, &pQ -> INQUEUE[0],
                        pQ->INCount, pQ->PutError);

                CONSOLE(p, RITDISD2, blankPos, blankPos, &pQ -> OUTQUEUE[0],
                        pQ->OutCount, pQ->OUTError);
                /*only display the queue manager if not local */
                if (pQ -> QFLags[0] & NotLocalQM == NotLocalQM)
                    CONSOLE(p, RITDISD3, blankPos, blankPos, pQ -> OUTQM);

                if (pQ->OUTRS != 0) /* out reason code    */
                {
                    /* 1 no utc, 2 utc, 3: utc+local */
                    char timeout[31];
                    STCKCONV(&pQ->Q_E_STCK, &timeout[0], 3);

                    CONSOLE(p, RITDISD4, pQ->OUTRS, RITMQRC(pQ->OUTRS), timeout);
                } /* OUTRS != 0 */
                if (pQ->OUTPMO != 0) /* out PMO    */
                {
                    /* 1 no utc, 2 utc, 3: utc+local */
                    char timeout[31];
                    STCKCONV(&pQ->Q_E_STCK, &timeout[0], 3);

                    CONSOLE(p, RITDISD6, pQ->OUTPMO, timeout);
                } /* OUTPMO != 0 */
                if (pQ->ApplType != 0) /* ApplType    */
                {
                    CONSOLE(p, RITDISD7, pQ->ApplType);
                    CONSOLE(p, RITDISD8, pQ->ApplName);
                } /* ApplType != 0 */
                if (pQ->INTRC != 0) /* internal problem   */
                {
                    /* 1 no utc, 2 utc, 3: utc+local */
                    char timeout[31];
                    STCKCONV(&pQ->INT_STCK, &timeout[0], 3);

                    CONSOLE(p, pQ->INTRC, timeout);
                } /* INTRC != 0 */

                if (pQ->OK_STCK != 0) /* last put time    */
                {
                    /* 1 no utc, 2 utc, 3: utc+local */
                    char timeout[31];
                    STCKCONV(&pQ->OK_STCK, &timeout[0], 3);

                    CONSOLE(p, RITDISD5, timeout);
                } /* pQ->OK_STCK != 0 */

                if ((pQ -> QFLags[0] & QMStorage) == QMStorage)
                    CONSOLE(p, RITDISSTORAGE);
            }
            pQ += 1; /* point to next queue area   */
        } /* iCount */
    } /* for each type */
    return;
}

#define PRINTX(a) printf("%8s %8.8x\n",#a,p->##a);
#define PRINTG(a) printf("%8s %8.8x\n",#a,pGlobal->##a);
void debug(Userparm * p) {

    /* get our current time and format it */
    struct timeval tvTime;
    struct tm *tmTime;
    Pcdef * pGlobal;
    pGlobal = p->pGlobal;

    int iCount;

    gettimeofday(&tvTime, 0);
    tmTime = gmtime(&(tvTime.tv_sec));

    printf("  \nTime: %d-%2.2d-%2.2d %2.2d:%2.2d:%2.2d.%6.6ld\n",
            tmTime->tm_year + 1900, tmTime->tm_mon + 1, tmTime->tm_mday,
            tmTime->tm_hour, tmTime->tm_min, tmTime->tm_sec, tvTime.tv_usec);
    if (p->dispFlags == 0) /* we display anchor stuff only once */
    {
        PRINTX(pGlobal);
        PRINTX(aModule);
        PRINTX(pWSAVRMVT);
        PRINTX(pWSAVRMFT);
        PRINTX(pWSAVSDWA);
        PRINTX(MYRC);
        PRINTX(FUNCRC);
        PRINTX(WOLDPRH2);
        PRINTX(WOLDINS);
        PRINTX(WNEWPRH2);
        PRINTX(WNEWINS);
        PRINTX(WQMSSCT);
        PRINTX(COMAREA);
        PRINTX(loadPoint);
        PRINTX(loadLength);
        PRINTX(loadAttr);
        PRINTX(csvqueryRC);
        PRINTX(MQLXRES);
        PRINTX(SCHED_RC0);
        PRINTX(SCHED_RC1);
        PRINTX(SCHED_RC2);
        PRINTX(SCHED_RC3);
        if (pGlobal == 0)
            return;
        printf("Global anchor 2\n");
        long len;
        len = (long) &pGlobal -> DETDESC[0] - (long) pGlobal;
        printHexS(pGlobal, 512, "  "); /* length is 512 min */
        PRINTG(LXCOUNT);
        PRINTG(LXVALUE);
        PRINTG(TKCOUNT);
        PRINTG(TKVALUE);
        PRINTG(ETCON_RC);
        PRINTG(ETCRE_RC);
        PRINTG(LXRES_RC);
        printf("QMGRASID %8.8x\n", pGlobal->QMGRASID);
        printf("RITFLAGS %8.8x\n", pGlobal-> RITFLAGS);
        printHexS(&pGlobal -> DETDESC, sizeof(pGlobal-> DETDESC), "  ");
        printHexS(&pGlobal -> DETCON, sizeof(pGlobal-> DETCON), "  ");
        printf("UnitTest %8.8s\n", pGlobal->UnitTest);
        printf("Diagnosis %d\n", pGlobal->Diagnosis);

        p->dispFlags = 1;
    }
    if (TRACEP > 8) {
#ifdef DOUNITTEST
        TRACE(3,"UNITTEST %8.8s.\n",p->UnitTest);
#endif
        printf("Lo, Hi\n");
        printHexS(pGlobal -> loCsect, 8, "  ");
        printf("MonQueue %48.48s\n", pGlobal-> MonQueue);
        printHexS(pGlobal-> MonQueue, 48, "  ");
    }
    TRACE(3, "Options  .%8.8x\n", pGlobal->OUTOPTIONS);
    TRACE(3, "TraceCOM .%32.32s.\n", pGlobal->TRACECOM);
    TRACE(3, "Bread    .%8.8s.\n", pGlobal->ComBreadCrumb);
    TRACE(3, "Jobname  %8.8s\n\n", pGlobal->JOBNAME);
    TRACE(3, "ApplType .%8.8x\n", pGlobal->RITApplType);
    TRACE(3, "ApplName  %s\n\n", pGlobal->RITApplName);
    return;
}
